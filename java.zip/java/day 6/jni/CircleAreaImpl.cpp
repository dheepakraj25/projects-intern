#include <jni.h>

#include "CircleArea.h"

extern "C" {

JNIEXPORT jdouble JNICALL Java_CircleArea_calculateArea(JNIEnv* env, jobject obj, jdouble radius) {
    	
	const double PI = 3.14159265358979323846;
    	return PI * radius * radius;
}

}
