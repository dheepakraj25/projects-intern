public class CircleArea {

    	public native double calculateArea(double radius);

    	static 
	{
        	System.loadLibrary("CircleAreaImpl");
    	}

    	public static void main(String[] args) 
	{
        	CircleArea circleArea = new CircleArea();
        	double radius = 5.0;
        	double area = circleArea.calculateArea(radius);
        	System.out.println("Area of the circle with radius " + radius + " is: " + area);
    	}
}
