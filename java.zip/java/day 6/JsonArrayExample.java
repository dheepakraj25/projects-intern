import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
 class JsonArrayExample{
    public static void main(String[] args) {
      
        JSONObject jsonObject = new JSONObject();

        
        JSONArray jsonArray = new JSONArray();
        jsonArray.put("Item 1");
        jsonArray.put("Item 2");
        jsonArray.put("Item 3");

      
        jsonObject.put("array", jsonArray);

     
        try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
             FileWriter fileWriter = new FileWriter("json_output.json")) {

           
            byteArrayOutputStream.write(jsonObject.toString().getBytes());

           
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());

            
            int data;
            while ((data = byteArrayInputStream.read()) != -1) {
                fileWriter.write(data);
            }

            System.out.println("JSON Object successfully written to file.");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
