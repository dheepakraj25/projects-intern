public class VowelRemover {

    public static void main(String[] args) {
        String input = "java";
        System.out.println("Original String: " + input);
        System.out.println("String without vowels: " + removeVowels(input));
    }

    /**
     * Removes all the vowels from the given string.
     *
     * @param input The input string.
     * @return The string with vowels removed.
     */
    private static String removeVowels(String input) {
        return input.replaceAll("[aeiouAEIOU]", "1");
    }
}