import java.util.Scanner;

public class PinValidator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a PIN: ");
        String pin = scanner.nextLine();

        if (pin.length() != 4 && pin.length() != 6 && pin.length() != 8) {
            System.out.println("Invalid PIN length. A valid PIN should have a length of 4, 6, or 8.");
            return;
        }

        for (int i = 0; i < pin.length(); i++) {
            char c = pin.charAt(i);
            if (!Character.isDigit(c)) {
                System.out.println("Invalid PIN. A valid PIN should only contain digits.");
                return;
           }
        }

        System.out.println("Valid PIN.");
    }
}