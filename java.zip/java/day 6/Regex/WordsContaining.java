/*Write a Java program that matches a word containing 'g', not at the start or end of the word*/
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WordsContaining {
    public static void main(String[] args) {
        String[] words = {"giraffe", "google", "go", "tag", "program", "beginning", "endgame", "game"};
        Pattern pattern = Pattern.compile("\\b\\w*g\\w*\\b");

        for (String word : words) {
            Matcher matcher = pattern.matcher(word);
            if (matcher.find()) {
                System.out.println(word + " contains 'g' not at the start or end.");
            }
        }
    }
}
