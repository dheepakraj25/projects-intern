/*7(L3). Write a Java program to remove leading zeros from a given IP address. Also vlaidate it.*/
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IpAddressValidator {

    public static void main(String[] args) {
        String ipAddressWithLeadingZeros = "010.000.000.000";
        System.out.println("Original IP Address: " + ipAddressWithLeadingZeros);
        System.out.println("IP Address without leading zeros: " + removeLeadingZeros(ipAddressWithLeadingZeros));
    }

  

  /*  private static String removeLeadingZeros(String ipAddress) {
      
        if (!isValidIpAddress(ipAddress)) {
            System.out.println("Invalid IP Address");
            return "";
        }

        String[] numbers = ipAddress.split("\\.");
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = numbers[i].replaceFirst("^0+(?!$)", "");
        }

        return String.join(".", numbers);
    }*/


    private static boolean isValidIpAddress(String ipAddress) {
        String regex = "^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(ipAddress);
        return matcher.matches();
    }
}