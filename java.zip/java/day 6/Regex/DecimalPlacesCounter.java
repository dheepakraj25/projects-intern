import java.math.BigDecimal;

public class DecimalPlacesCounter {

    public static void main(String[] args) {
        double number = 3.14159;
        int decimalPlaces = countDecimalPlaces(number);
        System.out.println("The number " + number + " has " + decimalPlaces + " decimal places.");
    }

    public static int countDecimalPlaces(double number) {
        BigDecimal decimalNumber = new BigDecimal(number);
        String stringNumber = decimalNumber.toPlainString();
        int indexOfDecimalPoint = stringNumber.indexOf(".");
        if (indexOfDecimalPoint == -1) {
            return 0;
        } else {
            return stringNumber.length() - indexOfDecimalPoint - 1;
        }
    }

}