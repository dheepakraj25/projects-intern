/*Write a Java program that matches a string that has a 'p' followed by anything, ending in 'q*/
 


import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MatchersEnding {
    public static void main(String[] args) {
        String[] strings = {"pq", "pqq", "ppq", "pabcq", "pqrstq", "pabq", "apq", "pqzq"};

       
        String regex = "p.*q";

        Pattern pattern = Pattern.compile(regex);

        for (String str : strings) {
            Matcher matcher = pattern.matcher(str);
            if (matcher.matches()) {
                System.out.println(str + " matches the pattern.");
            } else {
                System.out.println(str + " does not match the pattern.");
            }
        }
    }
}
