/*Write a Java program to find sequences of lowercase letters joined with an underscore*/
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FindSequences {

    public static void main(String[] args) {
        String input = "hello world_this_is_a_test";
        Pattern pattern = Pattern.compile("(_[a-z]+)+");
        Matcher matcher = pattern.matcher(input);

        while (matcher.find()) {
            System.out.println("Found sequence: " + matcher.group());
        }
    }
}