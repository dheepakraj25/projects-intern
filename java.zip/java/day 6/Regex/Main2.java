/*Write a Java program to match a string that contains only upper and lowercase letters, numbers, and underscores*/
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main2 {
    public static void main(String[] args) {
        String input = "Hello_World123";
        String pattern = "^[a-zA-Z0-9_]+$";

        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(input);

        if (m.matches()) {
            System.out.println("String matches the pattern.");
        } else {
            System.out.println("String does not match the pattern.");
        }
    }
}
