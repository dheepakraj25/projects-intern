/*Write a Java program that matches a string that has a p followed by zero or more q's.*/
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) {
        String input = "pqqqq";
        String regex = "pq*"; 

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);

        boolean matchFound = matcher.find();
        if (matchFound) {
            System.out.println("Match found: " + matcher.group());
        } else {
            System.out.println("No match found.");
        }
    }
}