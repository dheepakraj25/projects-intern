import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class AlphanumericChecker {

    public static void main(String[] args) {
        String inputString = "ThisIsAValidAlphanumericString123";
        boolean isAlphanumeric = isStringAlphanumeric(inputString);
        if (isAlphanumeric) {
            System.out.println("The string is alphanumeric.");
        } else {
            System.out.println("The string contains non-alphanumeric characters.");
        }
    }

    public static boolean isStringAlphanumeric(String input) {
        String regex = "^[a-zA-Z0-9]*$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(input);
        return matcher.matches();
    }
}