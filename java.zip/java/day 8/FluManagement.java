import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

class Person {
    public int age;
    public String name;
    public String bloodGroup;
    public String location;
    protected boolean isAlive;
}

class InvalidAgeException extends Exception {
    InvalidAgeException(String message) {
        super(message);
    }
}

class Patient extends Person {
    private static int counter = 0;
    private int id;
    public int getId() {
        return id;
    }

    HashMap<String, Boolean> symptomMap;
    private int affectedPercent;
    private LinkedList<String> treatments = new LinkedList<>();
    public boolean isCured;

    Patient(String name, int age, String bloodGroup, String location, String[] symptoms) {
        this.name = name;
        this.age = age;
        this.bloodGroup = bloodGroup;
        this.id = ++counter;
        this.location = location;
        this.affectedPercent = 100;
        this.symptomMap = new HashMap<>();
        for (String symptom : symptoms) {
            this.symptomMap.put(symptom, true);
        }
        this.isCured = false;
        this.isAlive = true;
    }

    public boolean hasSymptom(String symptom) {
        return this.symptomMap.containsKey(symptom);
    }

    public boolean hadTreatment(String treatment) {
        return this.treatments.contains(treatment);
    }

    public void addTreatment(String treatment) {
        if (!this.isAlive || this.isCured) return;

        if (treatment.equals("T1")) {
            affectedPercent -= 40;
            treatments.add(treatment);
        } else if (treatment.equals("T2")) {
            affectedPercent -= 50;
            treatments.add(treatment);
        } else {
            this.affectedPercent += 30;
            if (affectedPercent > 100) {
                this.isAlive = false;
            }
            treatments.add(treatment);
        }

        if (affectedPercent <= 0) {
            this.affectedPercent = 0;
            this.isCured = true;
        }
    }

    public String toFormattedString() {
        return String.format( id, name, age, bloodGroup, (hasSymptom("S1") ? "yes" : "no"), (hasSymptom("S2") ? "yes" : "no"), (hasSymptom("S3") ? "yes" : "no"), (hadTreatment("T1") ? "yes" : "no"), (hadTreatment("T2") ? "yes" : "no"), (hadTreatment("T3") ? "yes" : "no"));
    }

    public String toCsvString() {
        return id + ", " + name + ", " + age + ", " + bloodGroup + ",  " + hasSymptom("S1") + ", " + hasSymptom("S2") + ", " + hasSymptom("S3") + ", " + treatments.toString() + ", " + affectedPercent;
    }
}

class Analysis {
    public static LinkedList<Patient> getOverview(LinkedList<Patient> patients, int type) {
        LinkedList<Patient> result = new LinkedList<>();
        if (type == 1) {
            for (Patient patient : patients) {
                if (patient.isCured) result.add(patient);
            }
        } else if (type == 2) {
            for (Patient patient : patients) {
                if (!patient.isAlive) result.add(patient);
            }
        } else if (type == 3) {
            for (Patient patient : patients) {
                if (!patient.treatments.isEmpty()) result.add(patient);
            }
        } else if (type == 4) {
            for (Patient patient : patients) {
                if (patient.treatments.isEmpty()) result.add(patient);
            }
        }
        return result;
    }

    public static LinkedList<Patient> getByTreatment(LinkedList<Patient> patients, String... treatments) {
        LinkedList<Patient> result = new LinkedList<>();
        for (Patient patient : patients) {

            boolean isContainFlag = true;
            for (String treatment : treatments) {
                if (!patient.hadTreatment(treatment)) {
                    isContainFlag = false;
                    break;
                }
            }

            if (isContainFlag) {
                result.add(patient);
            }
        }
        return result;
    }

    public static LinkedList<Patient> getBySymptom(LinkedList<Patient> patients, String... symptoms) {
        LinkedList<Patient> result = new LinkedList<>();
        for (Patient patient : patients) {

            boolean isContainFlag = true;
            for (String symptom : symptoms) {
                if (!patient.hasSymptom(symptom)) {
                    isContainFlag = false;
                    break;
                }
            }

            if (isContainFlag) {
                result.add(patient);
            }
        }
        return result;
    }

    public static LinkedList<Patient> getByLocation(LinkedList<Patient> patients, String location) {
        LinkedList<Patient> result = new LinkedList<>();
        for (Patient patient : patients) {
            if (patient.location.equalsIgnoreCase(location)) {
                result.add(patient);
            }
        }
        return result;
    }

    public static int[] groupByAge(LinkedList<Patient> patients, int ageGap) throws InvalidAgeException {
        if (ageGap == 0) {
            throw new InvalidAgeException("Age Cannot Be Less Than 1");
        }

        int[] array = new int[(150 / ageGap)];
        java.util.Arrays.fill(array, 0);

        for (Patient patient : patients) {
            array[(patient.age + 1) / ageGap]++;
        }

        return array;
    }
}

class FluManagement {
    private LinkedList<Patient> patients;
    private LinkedList<String> locations;

    FluManagement() {
        this.patients = new LinkedList<>();
        this.locations = new LinkedList<>();
    }

    public static void main(String[] args) {
        FluManagement fluManagement = new FluManagement();
        Scanner scanner = new Scanner(System.in);

        int userInput = 0;
        while (userInput != 6) {
            createMenu("Flu Management", "[1] Add Patient", "[2] Remove Patient", "[3] Analysis", "[4] Export", "[5] Do Treatment", "[6] Exit");
            userInput = input(1, 6, scanner);

            switch (userInput) {
                case 1:
                    addPatient(fluManagement, scanner);
                    break;
                case 2:
                    removePatient(fluManagement, scanner);
                    break;
                case 3:
                    analysisMenu(fluManagement, scanner);
                    break;
                case 4:
                    exportPatients(fluManagement);
                    break;
                case 5:
                    doTreatment(fluManagement, scanner);
                    break;
                case 6:
                    System.out.println("Exiting program...");
                    break;
                default:
                    System.out.println("Invalid input. Please enter a number between 1 and 6.");
                    break;
            }
        }
        scanner.close();
    }

        private static void addPatient(FluManagement fluManagement, Scanner scanner) {
        System.out.println("Enter Patient Name:");
        String name = scanner.nextLine();

        System.out.println("Enter Patient Age:");
        int age = Integer.parseInt(scanner.nextLine());

        System.out.println("Enter Blood Group:");
        String bloodGroup = scanner.nextLine();

        System.out.println("Enter Location:");
        String location = scanner.nextLine().toLowerCase();
        fluManagement.locations.add(location);

        System.out.println("Enter Number Of Symptoms:");
        int symptomCount = Integer.parseInt(scanner.nextLine());
        String[] symptoms = new String[symptomCount];

        for (int i = 0; i < symptomCount; i++) {
            System.out.println("Enter Symptom " + (i + 1) + ":");
            symptoms[i] = scanner.nextLine();
        }

        Patient patient = new Patient(name, age, bloodGroup, location, symptoms);
        fluManagement.patients.add(patient);

        System.out.println("Patient Created Successfully\n" + patient);
    }

    private static void removePatient(FluManagement fluManagement, Scanner scanner) {
        System.out.println("Enter Patient ID:");
        int id = Integer.parseInt(scanner.nextLine());

        for (Patient patient : fluManagement.patients) {
            if (patient.getId() == id) {
                fluManagement.patients.remove(patient);
                System.out.println("Patient removed successfully.");
                return;
            }
        }

        System.out.println("Patient with ID " + id + " not found.");
    }

    private static void analysisMenu(FluManagement fluManagement, Scanner scanner) {
        int userInput = 0;

        while (userInput != 6) {
            createMenu("Analysis", "[1] Group By Symptom", "[2] Group By Age", "[3] Group By Location", "[4] Treatment", "[5] Overview", "[6] Back");
            userInput = input(1, 6, scanner);

            switch (userInput) {
                case 1:
                    groupBySymptom(fluManagement);
                    break;
                case 2:
                    groupByAge(fluManagement);
                    break;
                case 3:
                    groupByLocation(fluManagement);
                    break;
                case 4:
                    groupByTreatment(fluManagement);
                    break;
                case 5:
                    overview(fluManagement);
                    break;
                case 6:
                    return;
            }
        }
    }

    private static void groupBySymptom(FluManagement fluManagement) {
        int symptom1Count = 0, symptom2Count = 0, symptom3Count = 0;
        int s1s2Count = 0, s1s3Count = 0, s2s3Count = 0, s1s2s3Count = 0;

        for (Patient patient : fluManagement.patients) {
            if (patient.hasSymptom("S1")) symptom1Count++;
            if (patient.hasSymptom("S2")) symptom2Count++;
            if (patient.hasSymptom("S3")) symptom3Count++;
            if (patient.hasSymptom("S1") && patient.hasSymptom("S2")) s1s2Count++;
            if (patient.hasSymptom("S1") && patient.hasSymptom("S3")) s1s3Count++;
            if (patient.hasSymptom("S2") && patient.hasSymptom("S3")) s2s3Count++;
            if (patient.hasSymptom("S1") && patient.hasSymptom("S2") && patient.hasSymptom("S3")) s1s2s3Count++;
        }

        System.out.println("Symptom1 : " + symptom1Count);
        System.out.println("Symptom2 : " + symptom2Count);
        System.out.println("Symptom3 : " + symptom3Count);
        System.out.println("S1 S2    : " + s1s2Count);
        System.out.println("S1 S3    : " + s1s3Count);
        System.out.println("S2 S3    : " + s2s3Count);
        System.out.println("S1 S2 S3 : " + s1s2s3Count);
        System.out.println("Total Patient: " + fluManagement.patients.size());
    }

    private static void groupByAge(FluManagement fluManagement) {
        int[] array = new int[6];
        try {
            array = Analysis.groupByAge(fluManagement.patients, 10);
        } catch (InvalidAgeException e) {
            e.printStackTrace();
        }

        for (int i = 0; i < array.length; i++) {
            System.out.println("Age [" + i * 10 + " - " + ((i + 1) * 10) + "] : " + array[i]);
        }
    }

    private static void groupByLocation(FluManagement fluManagement) {
        for (String location : fluManagement.locations) {
            System.out.println(location + ": " + Analysis.getByLocation(fluManagement.patients, location).size());
        }
    }

    private static void groupByTreatment(FluManagement fluManagement) {
        int t1Count = 0, t2Count = 0, t3Count = 0;
        int t1t2Count = 0, t1t3Count = 0, t2t3Count = 0, t1t2t3Count = 0;

        for (Patient patient : fluManagement.patients) {
            if (patient.hadTreatment("T1")) t1Count++;
            if (patient.hadTreatment("T2")) t2Count++;
            if (patient.hadTreatment("T3")) t3Count++;
            if (patient.hadTreatment("T1") && patient.hadTreatment("T2")) t1t2Count++;
            if (patient.hadTreatment("T1") && patient.hadTreatment("T3")) t1t3Count++;
            if (patient.hadTreatment("T2") && patient.hadTreatment("T3")) t2t3Count++;
            if (patient.hadTreatment("T1") && patient.hadTreatment("T2") && patient.hadTreatment("T3")) t1t2t3Count++;
        }

        System.out.println("Treatment1 : " + t1Count);
        System.out.println("Treatment2 : " + t2Count);
        System.out.println("Treatment3 : " + t3Count);
        System.out.println("T1 T2    : " + t1t2Count);
        System.out.println("T1 T3    : " + t1t3Count);
        System.out.println("T2 T3    : " + t2t3Count);
        System.out.println("T1 T2 T3 : " + t1t2t3Count);
        System.out.println("Total Patient: " + fluManagement.patients.size());
    }

    private static void overview(FluManagement fluManagement) {
        System.out.println("Flu Cured Patients:");
        printPatients(Analysis.getOverview(fluManagement.patients, 1));

        System.out.println("Flu Treatment Patients:");
        printPatients(Analysis.getOverview(fluManagement.patients, 3));

                System.out.println("Flu Non-Treated Patients:");
        printPatients(Analysis.getOverview(fluManagement.patients, 4));

        System.out.println("Deceased Patients:");
        printPatients(Analysis.getOverview(fluManagement.patients, 2));
    }

    private static void printPatients(LinkedList<Patient> patients) {
        if (patients.isEmpty()) {
            System.out.println("No patients found.");
        } else {
            for (Patient patient : patients) {
                System.out.println(patient.toFormattedString());
            }
        }
    }

    private static void exportPatients(FluManagement fluManagement) {
        try {
            FileWriter csvWriter = new FileWriter("patients.csv");
            csvWriter.append("ID, Name, Age, Blood Group, S1, S2, S3, Treatments, Affected Percent\n");

            for (Patient patient : fluManagement.patients) {
                csvWriter.append(patient.toCsvString() + "\n");
            }

            csvWriter.flush();
            csvWriter.close();
            System.out.println("Patients exported to patients.csv");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void doTreatment(FluManagement fluManagement, Scanner scanner) {
        System.out.println("Enter Patient ID:");
        int id = Integer.parseInt(scanner.nextLine());

        Patient patient = null;
        for (Patient p : fluManagement.patients) {
            if (p.getId() == id) {
                patient = p;
                break;
            }
        }

        if (patient == null) {
            System.out.println("Patient not found.");
            return;
        }

        if (patient.isCured) {
            System.out.println("Patient already cured.");
            return;
        }

        System.out.println("Available treatments: [T1, T2, T3]");
        System.out.println("Enter treatment:");
        String treatment = scanner.nextLine().toUpperCase();

        if (treatment.equals("T1") || treatment.equals("T2") || treatment.equals("T3")) {
            patient.addTreatment(treatment);
            System.out.println("Treatment applied successfully.");
        } else {
            System.out.println("Invalid treatment.");
        }
    }

    private static void createMenu(String title, String... options) {
        System.out.println("\n" + title);
        for (String option : options) {
            System.out.println(option);
        }
        System.out.println("Please enter your choice:");
    }

    private static int input(int min, int max, Scanner scanner) {
        int input;
        while (true) {
            try {
                input = Integer.parseInt(scanner.nextLine());
                if (input < min || input > max) {
                    throw new NumberFormatException();
                }
                break;
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number between " + min + " and " + max + ".");
            }
        }
        return input;
    }
}


