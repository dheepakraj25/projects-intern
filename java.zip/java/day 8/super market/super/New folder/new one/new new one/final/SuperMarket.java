import java.io.*;
import java.util.*;

class Employee implements Serializable {
    int id;
    String name;
    String phoneNo;

    public Employee(int id, String name, String phoneNo) {
        this.id = id;
        this.name = name;
        this.phoneNo = phoneNo;
    }

    public String toString() {
        return "Employee[id=" + id + ", name=" + name + ", phoneNo=" + phoneNo + "]";
    }
}

class ShoppingCart implements Serializable {
    ArrayList<Product> products;

    public ShoppingCart() {
        this.products = new ArrayList<>();
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public void removeProduct(Product product) {
        products.remove(product);
    }

    public void clearCart() {
        products.clear();
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public double calculateTotal() {
        double total = 0;
        for (Product product : products) {
            total += product.rate;
        }
        return total;
    }

    public void viewCart() {
        if (products.isEmpty()) {
            System.out.println("Your shopping cart is empty.");
        } else {
            System.out.println("Shopping Cart:");
            for (Product product : products) {
                System.out.println(product.toString());
            }
            System.out.println("Total: $" + calculateTotal());
        }
    }
}

class Customer implements Serializable {
    int id;
    String name;
    String phoneNumber;
    ShoppingCart shoppingCart;
    ArrayList<Bill> bills;

    public Customer(int id, String name, String phoneNumber) {
        this.id = id;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.shoppingCart = new ShoppingCart();
        this.bills = new ArrayList<>();
    }

    public String toString() {
        return "Customer[id=" + id + ", name=" + name + ", phoneNumber=" + phoneNumber + "]";
    }

    public void addToCart(Product product) {
        shoppingCart.addProduct(product);
    }

    public void removeFromCart(Product product) {
        shoppingCart.removeProduct(product);
    }

    public void viewCart() {
        shoppingCart.viewCart();
    }

    public int getCartTotalItems() {
        return shoppingCart.getProducts().size();
    }

    public double getCartTotalBill() {
        return shoppingCart.calculateTotal();
    }
}

class Product implements Serializable {
    String name;
    int id;
    double rate;
    int stock;

    public Product(String name, int id, double rate, int stock) {
        this.name = name;
        this.id = id;
        this.rate = rate;
        this.stock = stock;
    }

    public String toString() {
        return "Product[name=" + name + ", id=" + id + ", rate=" + rate + ", stock=" + stock + "]";
    }
}

class Bill implements Serializable {
    int billId;
    Customer customer;
    ArrayList<Product> products;
    double totalBill;
    String paymentMode;

    public Bill(int billId, Customer customer, ArrayList<Product> products, String paymentMode) {
        this.billId = billId;
        this.customer = customer;
        this.products = products;
        this.paymentMode = paymentMode;
        this.totalBill = calculateTotalBill();
    }

    public double calculateTotalBill() {
        double total = 0;
        for (Product product : products) {
            total += product.rate; // Calculate total based on product rates only
        }
        return total;
    }

    public String toString() {
        String productString = "";
        for (Product product : products) {
            productString += product.toString() + "\n"; //(Quantity: " + product.stock + ")
        }
        return "Bill[billId=" + billId + ", customer=" + customer.toString() + ", products=\n" +  productString+ ", totalBill=" + totalBill + ", paymentMode=" + paymentMode + "]";
    }
}

class SuperMarket {
    ArrayList<Employee> employees;     
    ArrayList<Customer> customers;
    ArrayList<Product> products;

    public SuperMarket() {
        employees = new ArrayList<>();
        customers = new ArrayList<>();
        products = new ArrayList<>();
    }

    public void addEmployee(Employee emp) {
        employees.add(emp);
    }

    public void addCustomer(Customer cust) {
        customers.add(cust);
    }

    public void addProduct(Product prod) {
        products.add(prod);
    }

    public Employee findEmployeeById(int id) {
        for (Employee emp : employees) {
            if (emp.id == id) {
                return emp;
            }
        }
        return null;
    }

    public Customer findCustomerById(int id) {
        for (Customer cust : customers) {
            if (cust.id == id) {
                return cust;
            }
        }
        return null;
    }

    public Product findProductById(int id) {
        for (Product prod : products) {
            if (prod.id == id) {
                return prod;
            }
        }
        return null;
    }

    public void addToCart(int customerId, int productId, int quantity) {
        Customer customer = findCustomerById(customerId);
        Product product = findProductById(productId);

        if (customer != null && product != null) {
            if (product.stock >= quantity) { // Check if there's enough stock
                for (int i = 0; i < quantity; i++) {
                    customer.addToCart(product);
                    product.stock--; // Decrement product stock for each item added to the cart
                }
                System.out.println("Product added to cart successfully!");
            } else {
                System.out.println("Sorry, there is not enough stock for the requested quantity.");
            }
        } else {
            System.out.println("Customer or product not found.");
        }
    }

    public void removeFromCart(int customerId, int productId, int quantity) {
        Customer customer = findCustomerById(customerId);
        Product product = findProductById(productId);

        if (customer != null && product != null) {
            if (quantity > 0) {
                for (int i = 0; i < quantity; i++) {
                    customer.removeFromCart(product);
                    product.stock++; // Increment product stock for each item removed from the cart
                }
                System.out.println("Product(s) removed from cart successfully!");
            } else {
                System.out.println("Invalid quantity. Please enter a valid quantity greater than 0.");
            }
        } else {
            System.out.println("Customer or product not found.");
        }
    }

    public void viewCart(int customerId) {
        Customer customer = findCustomerById(customerId);
        if (customer != null) {
            ShoppingCart cart = customer.shoppingCart;
            if (cart != null && !cart.products.isEmpty()) {
                int totalItems = 0;
                System.out.println("Shopping Cart:");
                for (Product product : cart.products) {
                    System.out.println(product.toString());
                    totalItems++;
                }
                System.out.println("Total Items in Cart: " + totalItems);
                System.out.println("Total: $" + customer.getCartTotalBill()); // Printing total bill from customer's cart
            } else {
                System.out.println("Your shopping cart is empty.");
            }
        } else {
            System.out.println("Customer not found.");
        }
    }

       public void createBill(int employeeId, int customerId, String paymentMode) {
        Employee emp = findEmployeeById(employeeId);
        Customer cust = findCustomerById(customerId);

        if (emp != null && cust != null) {
            ShoppingCart cart = cust.shoppingCart;
            if (!cart.products.isEmpty()) {
                int billId = cust.bills.size() + 1;
                Bill bill = new Bill(billId, cust, cart.products, paymentMode);
                cust.bills.add(bill);
                cust.shoppingCart.clearCart();

                // Update product stock
                for (Product product : cart.products) {
                    Product supermarketProduct = findProductById(product.id);
                    if (supermarketProduct != null) {
                        supermarketProduct.stock -= product.stock; // Update product stock based on quantity in cart
                    }
                }

                System.out.println("Bill created successfully!");
            } else {
                System.out.println("Shopping cart is empty. No bill created.");
            }
        } else {
            System.out.println("Employee or customer not found!");
        }
    }

    public void printBills(int customerId) {
        Customer customer = findCustomerById(customerId);
        if (customer != null) {
            System.out.println("Bills for customer: " + customer.name);
            for (Bill bill : customer.bills) {
                System.out.println(bill.toString());
                System.out.println("Products:");
                for (Product product : bill.products) {
                    System.out.println(product.toString());
                }
                System.out.println();
            }
        } else {
            System.out.println("Customer not found!");
        }
    }

    public static void main(String[] args) {
        SuperMarket sm = new SuperMarket();
        Scanner scanner = new Scanner(System.in);
        int choice;

        // Load employees, customers, and products from files
        sm.employees = DataManager.loadEmployees("employees.ser");
        sm.customers = DataManager.loadCustomers("customers.ser");
        sm.products = DataManager.loadProducts("products.ser");

        do {
            System.out.println("\n1. Add employee");
            System.out.println("2. Add customer");
            System.out.println("3. Add product");
            System.out.println("4. Add product to cart");
            System.out.println("5. Remove product from cart");
            System.out.println("6. View cart");
            System.out.println("7. Create bill");
            System.out.println("8. Print bills");
            System.out.println("9. Quit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter employee ID: ");
                    int empId = scanner.nextInt();
                    System.out.print("Enter employee name: ");
                    String empName = scanner.next();
                    System.out.print("Enter employee phone number: ");
                    String empPhoneNo = scanner.next();
                    Employee employee = new Employee(empId, empName, empPhoneNo);
                    sm.addEmployee(employee);
                    DataManager.saveEmployees(sm.employees, "employees.ser");
                    System.out.println("Employee added successfully!");
                    break;
                case 2:
                    System.out.print("Enter customer ID: ");
                    int custId = scanner.nextInt();
                    System.out.print("Enter customer name: ");
                    String custName = scanner.next();
                    System.out.print("Enter customer phone number: ");
                    String custPhoneNumber = scanner.next();
                    Customer customer = new Customer(custId, custName, custPhoneNumber);
                    sm.addCustomer(customer);
                    DataManager.saveCustomers(sm.customers, "customers.ser");
                    System.out.println("Customer added successfully!");
                    break;
                case 3:
                    System.out.print("Enter product name: ");
                    String prodName = scanner.next();
                    System.out.print("Enter product ID: ");
                    int prodId = scanner.nextInt();
                    System.out.print("Enter product rate: ");
                    double prodRate = scanner.nextDouble();
                    System.out.print("Enter product stock: ");
                    int prodStock = scanner.nextInt();
                    Product product = new Product(prodName, prodId, prodRate, prodStock);
                    sm.addProduct(product);
                    DataManager.saveProducts(sm.products, "products.ser");
                    System.out.println("Product added successfully!");
                    break;
                case 4:
                    System.out.print("Enter customer ID: ");
                    int customerId = scanner.nextInt();
                    System.out.print("Enter product ID: ");
                    int productId = scanner.nextInt();
                    System.out.print("Enter quantity: ");
                    int quantity = scanner.nextInt();
                    sm.addToCart(customerId, productId, quantity);
                    break;
                case 5:
                    System.out.print("Enter customer ID: ");
                    int custIdToRemove = scanner.nextInt();
                    System.out.print("Enter product ID to remove: ");
                    int prodIdToRemove = scanner.nextInt();
                    System.out.print("Enter quantity to remove: ");
                    int quantityToRemove = scanner.nextInt();
                    sm.removeFromCart(custIdToRemove, prodIdToRemove, quantityToRemove);
                    break;
                case 6:
                    System.out.print("Enter customer ID to view cart: ");
                    int customerIdToView = scanner.nextInt();
                    sm.viewCart(customerIdToView);
                    break;
                case 7:
                    System.out.print("Enter employee ID: ");
                    int employeeId = scanner.nextInt();
                    System.out.print("Enter customer ID: ");
                    int customerIdForBill = scanner.nextInt();
                    System.out.print("Enter payment mode: ");
                    String paymentMode = scanner.next();
                    sm.createBill(employeeId, customerIdForBill, paymentMode);
                    break;
                case 8:
                    System.out.print("Enter customer ID to print bills: ");
                    int customerIdForBills = scanner.nextInt();
                    sm.printBills(customerIdForBills);
                    break;
                case 9:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 9);
    }
}

class DataManager {
    // Code to save and load employees, customers, and products
    public static void saveEmployees(ArrayList<Employee> employees, String fileName) {
        try {
            FileOutputStream fos = new FileOutputStream(fileName);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            for (Employee emp : employees) {
                oos.writeObject(emp);
            }
            oos.close();
            System.out.println("Employees saved successfully!");
        } catch (IOException e) {
            System.out.println("Error in saving employees: " + e.getMessage());
        }
    }

    public static ArrayList<Employee> loadEmployees(String fileName) {
        ArrayList<Employee> employees = new ArrayList<>();
        try {
            FileInputStream fis = new FileInputStream(fileName);
            ObjectInputStream ois = new ObjectInputStream(fis);
            while (true) {
                try {
                    Employee emp = (Employee) ois.readObject();
                    employees.add(emp);
                } catch (EOFException e) {
                    break;
                }
            }
            ois.close();
            System.out.println("Employees loaded successfully!");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error in loading employees: " + e.getMessage());
        }
        return employees;
    }

    public static void saveCustomers(ArrayList<Customer> customers, String fileName) {
        try {
            FileOutputStream fos = new FileOutputStream(fileName);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            for (Customer cust : customers) {
                oos.writeObject(cust);
            }
            oos.close();
                        System.out.println("Customers saved successfully!");
        } catch (IOException e) {
            System.out.println("Error in saving customers: " + e.getMessage());
        }
    }

    public static ArrayList<Customer> loadCustomers(String fileName) {
        ArrayList<Customer> customers = new ArrayList<>();
        try {
            FileInputStream fis = new FileInputStream(fileName);
            ObjectInputStream ois = new ObjectInputStream(fis);
            while (true) {
                try {
                    Customer cust = (Customer) ois.readObject();
                    customers.add(cust);
                } catch (EOFException e) {
                    break;
                }
            }
            ois.close();
            System.out.println("Customers loaded successfully!");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error in loading customers: " + e.getMessage());
        }
        return customers;
    }

    public static void saveProducts(ArrayList<Product> products, String fileName) {
        try {
            FileOutputStream fos = new FileOutputStream(fileName);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            for (Product prod : products) {
                oos.writeObject(prod);
            }
            oos.close();
            System.out.println("Products saved successfully!");
        } catch (IOException e) {
            System.out.println("Error in saving products: " + e.getMessage());
        }
    }

    public static ArrayList<Product> loadProducts(String fileName) {
        ArrayList<Product> products = new ArrayList<>();
        try {
            FileInputStream fis = new FileInputStream(fileName);
            ObjectInputStream ois = new ObjectInputStream(fis);
            while (true) {
                try {
                    Product prod = (Product) ois.readObject();
                    products.add(prod);
                } catch (EOFException e) {
                    break;
                }
            }
            ois.close();
            System.out.println("Products loaded successfully!");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error in loading products: " + e.getMessage());
        }
        return products;
    }
}

