import java.io.*;
import java.util.*;

class Employee implements Serializable {
    int id;
    String name;
    String phoneNo;

    public Employee(int id, String name, String phoneNo) {
        this.id = id;
        this.name = name;
        this.phoneNo = phoneNo;
    }

    public String toString() {
        return "Employee[id=" + id + ", name=" + name + ", phoneNo=" + phoneNo + "]";
    }
}

class Customer implements Serializable {
    int id;
    String name;
    String phoneNumber;
    ArrayList<Bill> bills;

    public Customer(int id, String name, String phoneNumber) {
        this.id = id;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.bills = new ArrayList<Bill>();
    }

    public void addBill(Bill bill) {
        bills.add(bill);
    }

    public String toString() {
        return "Customer[id=" + id + ", name=" + name + ", phoneNumber=" + phoneNumber + "]";
    }
}

class Product implements Serializable {
    String name;
    int id;
    double rate;
    int stock;

    public Product(String name, int id, double rate, int stock) {
        this.name = name;
        this.id = id;
        this.rate = rate;
        this.stock = stock;
    }

    public String toString() {
        return "Product[name=" + name + ", id=" + id + ", rate=" + rate + ", stock=" + stock + "]";
    }
}

class Bill implements Serializable {
    int billId;
    Customer customer;
    ArrayList<Product> products;
    double totalBill;
    String paymentMode;

    public Bill(int billId, Customer customer, ArrayList<Product> products, String paymentMode) {
        this.billId = billId;
        this.customer = customer;
        this.products = products;
        this.paymentMode = paymentMode;
        this.totalBill = calculateTotalBill();
    }

    public double calculateTotalBill() {
        double total = 0;
        for (Product product : products) {
            total += product.rate * product.stock;
        }
        return total;
    }
    public String producNames(products)
	{
		System.out.println(products);
	}

    public String toString() {
        String productString = "";
        for (Product product : products) {
            productString += product.toString() + "\n";
        }
        return "Bill[billId=" + billId + ", customer=" + customer.toString() + ", products=" + productString + ", totalBill=" + totalBill + ", paymentMode=" + paymentMode + "]";
    }
}

class SuperMarket {
    ArrayList<Employee> employees;
    ArrayList<Customer> customers;
    ArrayList<Product> products;

    public SuperMarket() {
        employees = new ArrayList<Employee>();
        customers = new ArrayList<Customer>();
        products = new ArrayList<Product>();
    }

    public void addEmployee(Employee emp) {
        employees.add(emp);
    }

    public void addCustomer(Customer cust) {
        customers.add(cust);
    }

    public void addProduct(Product prod) {
        products.add(prod);
    }

    public Employee findEmployeeById(int id) {
        for (Employee emp : employees) {
            if (emp.id == id) {
                return emp;
            }
        }
        return null;
    }

    public Customer findCustomerById(int id) {
        for (Customer cust : customers) {
            if (cust.id == id) {
                return cust;
            }
        }
        return null;
    }

    public Product findProductById(int id) {
        for (Product prod : products) {
            if (prod.id == id) {
                return prod;
            }
        }
        return null;
    }

    public void createBill(int employeeId, int customerId, ArrayList<Product> products, String paymentMode) {
        Employee emp = findEmployeeById(employeeId);
        Customer cust = findCustomerById(customerId);
        if (emp != null && cust != null) {
            int billId = cust.bills.size() + 1;
            Bill bill = new Bill(billId, cust, products, paymentMode);
            cust.addBill(bill);
            System.out.println("Bill created successfully!");
        } else {
            System.out.println("Employee or customer not found!");
        }
    }

   public void printBills(int customerId) {
         Customer customer = findCustomerById(customerId);
          if (customer != null) {
          System.out.println("Bills for customer: " + customer.name);
          for (Bill bill : customer.bills) {
            System.out.println(bill.toString());
		System.out.println("products");
	    System.out.println(bill.products);
         }
          System.out.println();
       } else {
          System.out.println("Customer not found!");
      }
   }


    public static void main(String[] args) {
        SuperMarket sm = new SuperMarket();
        Scanner scanner = new Scanner(System.in);
        int choice;

        // Load employees, customers, and products from files
        sm.employees = DataManager.loadEmployees("employees.ser");
        sm.customers = DataManager.loadCustomers("customers.ser");
        sm.products = DataManager.loadProducts("products.ser");

        do {
            System.out.println("\n1. Add employee");
            System.out.println("2. Add customer");
            System.out.println("3. Add product");
            System.out.println("4. Create bill");
            System.out.println("5. Print bills");
            System.out.println("6. Quit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter employee ID: ");
                    int id = scanner.nextInt();
                    System.out.print("Enter employee name: ");
                    String name = scanner.next();
                    System.out.print("Enter employee phone number: ");
                    String phoneNo = scanner.next();
                    Employee emp = new Employee(id, name, phoneNo);
                    sm.addEmployee(emp);
                    DataManager.saveEmployees(sm.employees, "employees.ser");
                    System.out.println("Employee added successfully!");
                    break;
                case 2:
                    System.out.print("Enter customer ID: ");
                    int custId = scanner.nextInt();
                    System.out.print("Enter customer name: ");
                    String custName = scanner.next();
                    System.out.print("Enter customer phone number: ");
                    String custPhoneNumber = scanner.next();
                    Customer customer = new Customer(custId, custName, custPhoneNumber);
                    sm.addCustomer(customer);
                    DataManager.saveCustomers(sm.customers, "customers.ser");
                    System.out.println("Customer added successfully!");
                    break;
                case 3:
                    System.out.print("Enter product name: ");
                    String prodName = scanner.next();
                    System.out.print("Enter product ID: ");
                    int prodId = scanner.nextInt();
                    System.out.print("Enter product rate: ");
                    double prodRate = scanner.nextDouble();
                    System.out.print("Enter product stock: ");
                    int prodStock = scanner.nextInt();
                    Product product = new Product(prodName, prodId, prodRate, prodStock);
                    sm.addProduct(product);
                    DataManager.saveProducts(sm.products, "products.ser");
                    System.out.println("Product added successfully!");
                    break;
                case 4:
                    System.out.print("Enter employee ID: ");
                    int employeeId = scanner.nextInt();
                    Employee employee = sm.findEmployeeById(employeeId);
                    if (employee == null) {
                        System.out.println("Employee not found.");
                        break;
                    }
                    System.out.print("Enter customer ID: ");
                    int customerId1 = scanner.nextInt();
                    Customer customer1 = sm.findCustomerById(customerId1);
		                        if (customer1 == null) {
                        System.out.println("Customer not found.");
                        break;
                    }
                    ArrayList<Product> products = new ArrayList<Product>();
                    System.out.println("Enter product ID and quantity (type 'q' to quit):");
                    while (true) {
                        System.out.print("Enter product ID: ");
                        String input = scanner.next();
                        if (input.equals("q")) {
                            break;
                        }
                        int prodId1 = Integer.parseInt(input);
                        Product prod1 = sm.findProductById(prodId1);
                        if (prod1 == null) {
                            System.out.println("Product not found.");
                            continue;
                        }
                        System.out.print("Enter quantity: ");
                        int quantity = scanner.nextInt();
                        if (quantity > prod1.stock) {
                            System.out.println("Insufficient stock.");
                            continue;
                        }
                        prod1.stock -= quantity;
                        products.add(new Product(prod1.name, prod1.id, prod1.rate, quantity));
                        System.out.print("Add more products? (y/n): ");
                        char ch = scanner.next().charAt(0);
                        if (ch == 'n') {
                            break;
                        }
                    }
                    System.out.print("Enter payment mode: ");
                    String paymentMode = scanner.next();
                    sm.createBill(employeeId, customerId1, products, paymentMode);
                    break;
                case 5:
            	         System.out.print("Enter customer ID to print bills: ");
   		       	 int customerId = scanner.nextInt();
    			 sm.printBills(customerId);
   			 break;

                case 6:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        } while (choice != 6);
        scanner.close();
    }
}

class DataManager {
   
    public static void saveEmployees(ArrayList<Employee> employees, String fileName) {
        try {
            FileOutputStream fos = new FileOutputStream(fileName);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            for (Employee emp : employees) {
                oos.writeObject(emp);
            }
            oos.close();
            System.out.println("Employees saved successfully!");
        } catch (IOException e) {
            System.out.println("Error in saving employees: " + e.getMessage());
        }
    }

    
    public static ArrayList<Employee> loadEmployees(String fileName) {
        ArrayList<Employee> employees = new ArrayList<>();
        try {
            FileInputStream fis = new FileInputStream(fileName);
            ObjectInputStream ois = new ObjectInputStream(fis);
            while (true) {
                try {
                    Employee emp = (Employee) ois.readObject();
                    employees.add(emp);
                } catch (EOFException e) {
                    break;
                }
            }
            ois.close();
            System.out.println("Employees loaded successfully!");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error in loading employees: " + e.getMessage());
        }
        return employees;
    }

    
    public static void saveCustomers(ArrayList<Customer> customers, String fileName) {
        try {
            FileOutputStream fos = new FileOutputStream(fileName);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            for (Customer cust : customers) {
                oos.writeObject(cust);
            }
            oos.close();
            System.out.println("Customers saved successfully!");
        } catch (IOException e) {
            System.out.println("Error in saving customers: " + e.getMessage());
        }
    }

    public static ArrayList<Customer> loadCustomers(String fileName) {
        ArrayList<Customer> customers = new ArrayList<>();
        try {
            FileInputStream fis = new FileInputStream(fileName);
            ObjectInputStream ois = new ObjectInputStream(fis);
            while (true) {
                try {
                    Customer cust = (Customer) ois.readObject();
                    customers.add(cust);
                } catch (EOFException e) {
                    break;
                }
            }
            ois.close();
            System.out.println("Customers loaded successfully!");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error in loading customers: " + e.getMessage());
        }
        return customers;
    }

    
    public static void saveProducts(ArrayList<Product> products, String fileName) {
        try {
            FileOutputStream fos = new FileOutputStream(fileName);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            for (Product prod : products) {
                oos.writeObject(prod);
            }
            oos.close();
            System.out.println("Products saved successfully!");
        } catch (IOException e) {
            System.out.println("Error in saving products: " + e.getMessage());
        }
    }

    public static ArrayList<Product> loadProducts(String fileName) {
        ArrayList<Product> products = new ArrayList<>();
        try {
            FileInputStream fis = new FileInputStream(fileName);
            ObjectInputStream ois = new ObjectInputStream(fis);
            while (true) {
                try {
                    Product prod = (Product) ois.readObject();
                    products.add(prod);
                } catch (EOFException e) {
                    break;
                }
            }
            ois.close();
            System.out.println("Products loaded successfully!");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error in loading products: " + e.getMessage());
        }
        return products;
    }
}

                   
