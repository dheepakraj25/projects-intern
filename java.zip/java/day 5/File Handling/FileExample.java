/*Write a program to create a text file in the path c:\java\abc.txt and check whether that file is exists.
 Using the command exists(), isDirectory(), isFile(), getName() and getAbsolutePath().*/
import java.io.File;

public class FileExample {
    public static void main(String[] args) {
      
        File file = new File("c:abc.txt");

        if (file.exists()) {
            System.out.println("The file exists.");

            if (file.isDirectory()) {
                System.out.println("The file is a directory.");
            } else {
                System.out.println("The file is not a directory.");
            }

         
            if (file.isFile()) {
                System.out.println("The file is a regular file.");
            }

            System.out.println("File name: " + file.getName());
            System.out.println("Absolute path: " + file.getAbsolutePath());
        } else {
            System.out.println("The file does not exist.");
        }
    }
}