/*Write a program to rename the given file, after renaming the file delete the renamed file. (Accept the file name using command line arguments.)*/
import java.io.File;

public class FileRenameAndDelete {

    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Usage: java FileRenameAndDelete <filename>");
            System.exit(1);
        }

        String filename = args[0];
        File file = new File(filename);

        if (!file.exists() || file.isDirectory()) {
            System.err.println("Error: File does not exist or is a directory.");
            System.exit(2);
        }

        String newFilename = filename + ".old";
        File newFile = new File(newFilename);

        if (file.renameTo(newFile)) {
            System.out.println("File renamed successfully to " + newFilename);
            if (newFile.delete()) {
                System.out.println("File deleted successfully");
            } else {
                System.err.println("Error: Unable to delete the renamed file.");
            }
        } else {
            System.err.println("Error: Unable to rename the file.");
        }
    }
}