/*Write a program to create a file and write data into it using the methods OutputStream class*/
import java.io.FileOutputStream;
import java.io.IOException;

public class FileWriterExample {

    public static void main(String[] args) {
       
        String filePath = "example.txt";

        try {
           
            FileOutputStream outputStream = new FileOutputStream(filePath);

           
            String data = "This is some sample data.";

           
            byte[] dataBytes = data.getBytes();

         
            outputStream.write(dataBytes);

           
            outputStream.close();

            System.out.println("Data has been written to the file: " + filePath);

        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
    }
}