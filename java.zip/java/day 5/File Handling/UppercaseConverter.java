/*Write a program to accept a specified number of characters as input and converts them into uppercase characters*/
import java.util.Scanner;

public class UppercaseConverter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of characters: ");
        int numCharacters = scanner.nextInt();
        System.out.println("Enter the characters: ");
        String input = scanner.next();
        String uppercaseInput = input.toUpperCase();
        System.out.println("The uppercase characters are: " + uppercaseInput);
    }
}