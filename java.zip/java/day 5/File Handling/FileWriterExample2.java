import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

public class FileWriterExample2 {

    public static void main(String[] args) {
        String userInput;
        String fileName = "user_input.txt";

        
        System.out.println("Please enter some text:");
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        try {
            userInput = reader.readLine();
        } catch (IOException e) {
            System.err.println("Error reading from input: " + e.getMessage());
            return;
        }

        
        FileWriter writer = null;
        try {
            writer = new FileWriter(fileName);
            writer.write(userInput);
            System.out.println("Successfully written to the file: " + fileName);
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        } finally {
            try {
                if (writer != null) {
                    writer.close();
                }
            } catch (IOException e) {
                System.err.println("Error closing writer: " + e.getMessage());
            }
        }
    }
}