/*Write a program to show how to read and write a file.*/
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class WriteFileExample {
    public static void main(String[] args) {
        String filePath = "example.txt";
        String contents = "Hello, world!";

        try {
            Files.write(Paths.get(filePath), contents.getBytes());
            System.out.println("File written successfully.");
        } catch (IOException e) {
            System.err.println("Error writing file: " + e.getMessage());
}
    }
}