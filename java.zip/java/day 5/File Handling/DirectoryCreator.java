/*Write a program to create a directory and check whether the directory is created*/
import java.io.File;
import java.io.IOException;

public class DirectoryCreator {

    public static void main(String[] args) {
        
        String directoryName = "myNewDirectory";
        String directoryPath = "./" + directoryName;

        File newDirectory = new File(directoryPath);

        try {
            boolean success = newDirectory.mkdir();
            if (success) {
                System.out.println("Directory " + directoryName + " created successfully!");
            } else {
                System.out.println("Directory " + directoryName + " could not be created.");
            }
        } catch (SecurityException se) {
            System.out.println("Security exception occurred while creating directory " + directoryName);
        }

        if (newDirectory.exists()) {
            System.out.println("Directory " + directoryName + " exists.");
        } else {
            System.out.println("Directory " + directoryName + " does not exist.");
        }
    }
}