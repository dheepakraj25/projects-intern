// Define a class that implements the Runnable interface
class MyRunnable implements Runnable {
    
    public void run() {
        try {
            // Sleep for 500 milliseconds
            Thread.sleep(500);
            
            System.out.println("MyRunnable is running!");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}


public class ThreadExample {
    public static void main(String[] args) {
      
        MyRunnable myRunnable = new MyRunnable();

        Thread thread1 = new Thread(myRunnable);

        
        thread1.start();

       
        Thread thread2 = new Thread(myRunnable);
        thread2.start();

     
        System.out.println("Main thread is running!");
    }
}