import java.util.LinkedList;

public class ProducerConsumerExample {
    
	public static void main(String[] args) 
	{

        	LinkedList<Integer> buffer = new LinkedList<>();
        	int capacity = 5; 

        	Thread producerThread = new Thread(new Producer(buffer, capacity), "Producer");
        	Thread consumerThread = new Thread(new Consumer(buffer), "Consumer");

	        producerThread.start();
        	consumerThread.start();
    	}
}

class Producer implements Runnable {
    	
	private final LinkedList<Integer> buffer;
    	private final int capacity;
    	private int item = 0;

    	public Producer(LinkedList<Integer> buffer, int capacity) 
	{
        	this.buffer = buffer;
        	this.capacity = capacity;
    	}

    	@Override
    	public void run() 
	{
        	while (true) 
		{
            		try 
			{
                		produce(item++);
                		Thread.sleep(1000);
	            	} 
			catch (InterruptedException e) 
			{
                		e.printStackTrace();
            		}
        	}
    	}

    	private void produce(int item) throws InterruptedException 
	{
        	synchronized (buffer) 
		{
            		while (buffer.size() == capacity) 
			{
                		System.out.println("Buffer is full. Producer is waiting...");
                		buffer.wait(); // Wait for consumer to consume items
            		}
            	buffer.add(item);
            	System.out.println("Produced: " + item);
            	buffer.notify(); // Notify consumer that an item is produced
        	}
    	}
}

class Consumer implements Runnable {
    	private final LinkedList<Integer> buffer;

    	public Consumer(LinkedList<Integer> buffer) 
	{
        	this.buffer = buffer;
    	}

    	@Override
    	public void run() 
	{
        	while (true) 
		{
           	 	try 
			{
                		consume();
                		Thread.sleep(2000);
		        } 
			catch (InterruptedException e) 
			{
                		e.printStackTrace();
            		}
        	}
    	}

    	private void consume() throws InterruptedException 
	{
        	synchronized (buffer) 
		{
            		while (buffer.isEmpty()) 
			{
                		System.out.println("Buffer is empty. Consumer is waiting...");
                		buffer.wait();
	            	}
            		int consumedItem = buffer.remove();
            		System.out.println("Consumed: " + consumedItem);
            		buffer.notify(); // Notify producer that an item is consumed
        	}
    	}
}
