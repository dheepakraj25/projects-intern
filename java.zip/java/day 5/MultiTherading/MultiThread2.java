class MyClass implements Runnable {
    private String name;

    public MyClass(String name) {
        this.name = name;
    }

    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println(name + " is running: " + i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

public class MultiThread2 {
    public static void main(String[] args) {
        MyClass myClass1 = new MyClass("Thread 1");
        MyClass myClass2 = new MyClass("Thread 2");

        Thread thread1 = new Thread(myClass1);
        Thread thread2 = new Thread(myClass2);

        thread1.start();
        thread2.start();
    }
}