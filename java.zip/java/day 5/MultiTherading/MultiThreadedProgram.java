class JavaThread extends Thread {
    public void run() {
        System.out.println("Java is hot, aromatic, and invigorating");
    }
}

public class MultiThreadedProgram {
    public static void main(String[] args) {
        JavaThread thread1 = new JavaThread();
        JavaThread thread2 = new JavaThread();

        thread1.start();
        thread2.start();
    }
}