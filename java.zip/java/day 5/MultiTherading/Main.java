class MyThread1 extends Thread {
    public MyThread1() {
        super("MyThread1"); 
        start(); 
    }

    public void run() {
        for (int i = 0; i < 10; i++) {
            System.out.println("MyThread1: " + i);
        }
    }
}

class MyThread2 extends Thread {
    public MyThread2() {
        super("MyThread2"); 
        start(); 
    }

    public void run() {
        for (int i = 0; i < 10; i++) {
            System.out.println("MyThread2: " + i);
        }
    }
}

public class Main {
    public static void main(String[] args) {
        MyThread1 thread1 = new MyThread1();
        MyThread2 thread2 = new MyThread2();

       
        while (thread1.isAlive() || thread2.isAlive()) {
            System.out.println("Main thread is waiting...");
        }

        System.out.println("Main thread is done.");
    }
}