class MyThread extends Thread {
    
    public MyThread() {
        
        super("MyThread");
        
        start();
    }

    
    public void run() {
        
        for (int i = 0; i < 10; i++) {
            System.out.println("MyThread: " + i);
        }
    }

    public static void main(String[] args) {
        
        MyThread myThread = new MyThread();

     
        System.out.println("Main thread: " + Thread.currentThread().getName());

       
        for (int i = 0; i < 10; i++) {
            System.out.println("Main thread: " + i);
        }
    }
}