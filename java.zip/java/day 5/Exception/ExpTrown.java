/*Write a program to illustrate how to throw an exception.*/
public class ExpTrown {
    public static void main(String[] args) {
        try {
            divideByZero();
        } catch (ArithmeticException e) {
            System.out.println("Caught an ArithmeticException: Division by zero is not allowed.");
        }
    }

    public static void divideByZero() {
        int numerator = 10;
        int denominator = 0;

        if (denominator == 0) {
            throw new ArithmeticException("Attempted division by zero.");
        }

        int result = numerator / denominator;
        System.out.println("Result of division: " + result);
    }
}
