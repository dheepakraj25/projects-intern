/*Write a program to illustrate sub class exception precedence over base class.*/
class SuperClass {
    void method() throws  Exception {
        throw new Exception("SuperClass Exception");
    }
}

class SubClass extends SuperClass {
    
    @Override
    void method() throws NullPointerException {
        throw new NullPointerException("SubClass Exception");
    }
}

 class Main {
    public static void main(String[] args) {
        SuperClass obj = new SubClass();

        try {
            String str = null;
             System.out.println(str.length());
            obj.method();
        } catch (NullPointerException e) {
            System.out.println("Caught NullPointerException: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Caught Exception: " + e.getMessage());
        }
    }
}
