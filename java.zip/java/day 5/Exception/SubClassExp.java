
class BaseClassException extends Exception {
    public BaseClassException(String message) {
        super(message);
    }
}

class SubClassException extends RuntimeException {
    public SubClassException(String message) {
        super(message);
}
}
 class SubClassExceptionPrecedence {
    public static void myMethod() throws BaseClassException {
        throw new SubClassException("This is a sub class exception");
    }

    public static void main(String[] args) {
        try {
            myMethod();
        } catch (BaseClassException e) {
            System.out.println("Caught base class exception: " + e.getMessage());
        }
    }
}