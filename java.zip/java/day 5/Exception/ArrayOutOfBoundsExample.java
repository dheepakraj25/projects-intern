public class ArrayOutOfBoundsExample {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};

        try {
             int IndexOutOFRange = numbers[10]
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array index is out of bounds!");
            System.out.println("Error message: " + e.getMessage());
            System.out.println("Stack trace:");
            System.out.println(Arrays.toString(e.getStackTrace()));
        }
    }

    public static void IndexOutOFRange(int[] numbers, int index) throws ArrayIndexOutOfBoundsException {
        if (index >= numbers.length) {
            throw new ArrayIndexOutOfBoundsException("Array index is out of bounds!");
        }
        System.out.println("Number at index " + index + ": " + numbers[index]);
    }
}
