/*Write a program to describe the usage of throws clause*/
import java.io.FileNotFoundException;
import java.io.FileReader;

public class ThrowsExample {

    
    public static void readFile(String filename) throws FileNotFoundException {
        FileReader fileReader = new FileReader(filename); 
    }

    
    public static void main(String[] args) {
        String filename = "non_existent_file.txt";

        try {
           
            readFile(filename);
            System.out.println("File reading completed.");
        } catch (FileNotFoundException e) {
            System.err.println("File not found: " + filename);
          
        }
    }
}
