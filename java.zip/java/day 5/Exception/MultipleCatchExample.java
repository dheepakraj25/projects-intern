/*Write a program to illustrate how to use multiple catch statements.*/
import java.util.Scanner;

public class MultipleCatchExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        try {
            System.out.print("Enter a number: ");
            int num = Integer.parseInt(scanner.nextLine());

            int result = 100 / num;

           
            int[] arr = {1, 2, 3};
            System.out.println("Array element at index " + num + " is: " + arr[num]);
        } catch (ArithmeticException e) {
            System.out.println("ArithmeticException caught: " + e.getMessage());
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("ArrayIndexOutOfBoundsException caught: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("NumberFormatException caught: Please enter a valid number.");
        } finally {
            scanner.close();
            System.out.println("Scanner closed.");
        }
    }
}
