//Write a program to illustrate how to throw an ArrayOutOfBoundException
public class ArrayOutOfBoundsExample {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};

        try {
            int indexOutOfBounds = 6;
            if (indexOutOfBounds >= numbers.length) {
                throw new ArrayIndexOutOfBoundsException("Array index is out of bounds!");
            }
            System.out.println("Number at index " + indexOutOfBounds + ": " + numbers[indexOutOfBounds]);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array index is out of bounds!");
            System.out.println("Error message: " + e.getMessage());
          
          
        }
    }
}