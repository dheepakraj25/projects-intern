//  Write a Java program to validate a personal identification number (PIN). Assume the length of a PIN number is 4, 6 or 8.

import java.util.Scanner;
import java.util.regex.*;

class PIN {
    private static boolean isValidPin(String input) {
        Pattern pattern = Pattern.compile("^\\d{4}$|^\\d{6}$|^\\d{8}$");
        Matcher matcher = pattern.matcher(input);

        return matcher.matches();
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter The Pin: ");
        String validateString = scanner.nextLine();

        if(isValidPin(validateString)) System.out.println(validateString+" Is A Valid Pin!");
        else System.out.println(validateString+" is Not A Valid Pin");

        scanner.close();
    }

}