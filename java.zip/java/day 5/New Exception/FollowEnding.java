// 4(L2).Write a Java program that matches a string that has a 'p' followed by anything, ending in 'q'.

import java.util.Scanner;
import java.util.regex.*;

class FollowEnding  {
    private static boolean isValidCharacterSet(String input) {
        Pattern pattern = Pattern.compile("p.*q");
        Matcher matcher = pattern.matcher(input);

        return matcher.matches();
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter A String: ");
        String validateString = scanner.nextLine();

        System.out.println(validateString+" "+isValidCharacterSet(validateString));

        scanner.close();
    }

}