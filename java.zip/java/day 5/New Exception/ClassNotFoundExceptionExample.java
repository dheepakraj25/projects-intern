//Write a program to illustrate how to throw a ClassNotFoundException.

import java.lang.ClassNotFoundException;

public class ClassNotFoundExceptionExample {

    public static void main(String[] args) {
                  String className = "non_existent_class";
        try {
           
            throw new ClassNotFoundException("The class " + className + " does not exist.");
        } catch (ClassNotFoundException e) {
            System.out.println("A ClassNotFoundException occurred: " + e.getMessage());
           
        }
    }
}





























                                                                                                                                             //class reference not be find