// Write a program to create a file and write data into it using the methods OutputStream class.

import java.io.*;
import java.util.Scanner;
 
public class OutputStreamDemo {
    public static void main(String[] args) throws IOException{
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter The File Name:");
        String filePath = scanner.nextLine();

        System.out.println("Enter The Content:");
        String content = scanner.nextLine();

        FileOutputStream outputStream = new FileOutputStream(filePath);

        byte[] bytes = content.getBytes();
        outputStream.write(bytes);
        outputStream.close();

        System.out.println("Content Writtern Successfully");
        scanner.close();
    }
     
}
