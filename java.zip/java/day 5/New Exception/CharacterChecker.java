//Write a Java program to check whether a string contains only a certain set of characters (in this case a-z, A-Z and 0-9)
import java.util.Scanner;
import java.util.regex.*;


public class CharacterChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter a string  characters:");
        String input = scanner.nextLine();
        
        checkAlphanumeric(input);
        
        scanner.close();
    }
    
    public static void checkAlphanumeric(String str) {
        Pattern pattern = Pattern.compile("^[a-zA-Z0-9]+$");
        Matcher matcher = pattern.matcher(str);
        
        if (matcher.matches()) {
            System.out.println("The string contains only characters.");
        } else {
            System.out.println("The string contains special characters.");
        }
    }
}


