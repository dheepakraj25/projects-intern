//  Write a program to illustrate creation of threads using runnable class.(start method start each of the newly created thread.
// Inside the run method there is sleep() for suspend the thread for 500 milliseconds)

class RunnableThread implements Runnable {
     String threadName;
     public RunnableThread(String threadName) {
        this.threadName = threadName;
    } 

    @Override
    public void run() {
        try {
            for(int i = 0; i < 5; i++){
                System.out.println(threadName+" "+i);
                Thread.sleep(500);
            }
            System.out.println(threadName+" Completed!");
        } catch (InterruptedException exception) {
            System.out.println(threadName+" "+exception.getMessage());
        }
    }
}

class RunnableClass {
    public static void main(String[] args) {

        RunnableThread runnableThread1 = new RunnableThread("Thread 1");
        RunnableThread runnableThread2 = new RunnableThread("Thread 2");
        
        Thread thread1 = new Thread(runnableThread1);
        Thread thread2 = new Thread(runnableThread2);
        
        thread1.start();
        thread2.start();
    }
}
