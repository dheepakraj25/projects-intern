//(L2)Write a program to illustrate sub class exception precedence over base class
class BaseException extends Exception {
    public BaseException(String message) {
        super(message);
    }
}

class SubException extends BaseException {
    public SubException(String message) {
        super(message);
    }
}

public class SubClassExceptionPrecedence {
    public static void main(String[] args) {
        try {
            throw new SubException("Subclass exception thrown");
        } catch (BaseException e) {
            System.err.println("Caught base exception: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Caught exception: " + e.getMessage());
        }
    }
}