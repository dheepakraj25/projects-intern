//  Write a program to get the reference to the current thread by calling currentThread() method.

class CallingCurrentThread {
    public static void main(String[] args) {
        Thread currentThread = Thread.currentThread();

        System.out.println("Current Thread ID: "+currentThread.threadId());
        System.out.println("Current Thread Name: "+currentThread.getName());
        System.out.println("Current Thread Priority: "+currentThread.getPriority());
        System.out.println("Is Current Thread Daemon: "+currentThread.isDaemon());
        System.out.println("Is Current Thread Alive: "+currentThread.isAlive());
    }
} 
