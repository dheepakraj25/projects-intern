//Write a program to get the input from the user and store it into file. Using Reader and Writer file.


import java.io.*;
import java.util.Scanner; 

public class ReaderWriterstore {
    public static void main(String[] args) throws IOException{
        Scanner scanner = new Scanner(System.in);
        
        Writer writer = new FileWriter("ReaderWriterstore.txt");  

        System.out.println("Enter The String To Be Writtern:");
        String content = scanner.nextLine();
        writer.write(content);
        writer.close();
        
        Reader reader = new FileReader("ReaderWriterstore.txt");
        String readContent = "";

        int data = reader.read();  
        while (data != -1) {  
            readContent += (char) data;  
            data = reader.read();  
        }
        
        System.out.println("Content In The File:\n"+readContent);
        reader.close();

        scanner.close();
    }
}
