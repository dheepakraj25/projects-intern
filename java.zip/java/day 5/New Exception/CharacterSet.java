// .Write a Java program that matches a string that has a p followed by zero or more q's.


import java.util.Scanner;

import java.util.regex.*;

class CharacterSet {
    private static boolean isValidCharacterSet(String input) {
        Pattern pattern = Pattern.compile("pq*");
        Matcher matcher = pattern.matcher(input);

        return matcher.matches();
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter A String: ");
        String validateString = scanner.nextLine();

        System.out.println(validateString+" "+isValidCharacterSet(validateString));

        scanner.close();
    }

}

