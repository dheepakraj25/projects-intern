// Write a Java program to remove leading zeros from a given IP address.
import java.util.*;
import java.util.regex.*;

public class IPAdders {
    public static void main(String[] args) {
        System.out.print("Enter the IP address: ");

        Scanner sc = new Scanner(System.in);
        String ipAddress = sc.nextLine();

        if (Pattern.matches("((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|0[0-9][0-9])\\.){3}((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|0[0-9][0-9]))", ipAddress)) {
            String cleanedIpAddress = ipAddress.replaceAll("\\.0+", ".");
            System.out.println(cleanedIpAddress);
        } else {
            System.out.println("Given input does not follow the IP address format");
        }
    }
}
