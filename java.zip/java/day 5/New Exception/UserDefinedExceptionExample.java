/*Write a program for creation of user defined exception.*/
class MyException extends Exception {
    public MyException(String message) {
        //super(message);
    }
}

public class UserDefinedExceptionExample {
    public static void main(String[] args) {
        try {
           
            int age = 17;
            if (age < 18) {
                throw new MyException("You must be 18 or older to access this content.");
            } else {
                System.out.println("Access granted!");
            }
        } catch (MyException e) {
            
            System.out.println("Exception Caught: " + e.getMessage());
        }
    }
}
