// Write a Java program to match a string that contains only upper and lowercase letters, numbers, and underscores.

import java.util.Scanner;
import java.util.regex.*;

class UpperLowercase {
    private static boolean isValidCharacterSet(String input) {
        Pattern pattern = Pattern.compile("^[a-zA-Z0-9_]+$");
        Matcher matcher = pattern.matcher(input);

        return matcher.matches();
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter A String: ");
        String validateString = scanner.nextLine();

        System.out.println(validateString+" "+isValidCharacterSet(validateString));

        scanner.close();
    }

}
