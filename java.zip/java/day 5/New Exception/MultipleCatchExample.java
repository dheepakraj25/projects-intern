//(L1)Write a program to illustrate how to use multiple catch statements.
import java.util.Scanner;
import java.util.*;

public class MultipleCatchExample {
    public static void main(String[] args) {
      

        try {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the numerator:");
        int numerator = scanner.nextInt();

        System.out.println("Enter the denominator:");
        int denominator = scanner.nextInt();
            int result = divide(numerator, denominator);
            System.out.println("Result of division: " + result);}
       catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
         
        } catch  (InputMismatchException e){
            System.out.println("Error: Invalid input, You given a input as character");             
        } catch (ArithmeticException e) {
            System.out.println("Error: Cannot divide by zero");
        } catch (NumberFormatException e) {
            System.out.println("Error: Invalid input, please enter valid integers");
        } //catch (Exception e) {
            //System.out.println("An unexpected error occurred: " + e.getMessage());
        } 
    }

    public static int divide(int numerator, int denominator) {
        return numerator / denominator;
    }
}
