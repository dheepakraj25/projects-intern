// 1(L1).Write a Java program to check whether a string contains only a certain set of characters (in this case a-z, A-Z and 0-9).


import java.util.regex.*;
import java.util.Scanner;


class SetOfCharacters  {
    private static boolean isValidCharacterSet(String input) {
        Pattern pattern = Pattern.compile("^[a-zA-Z0-9]+$");
        Matcher matcher = pattern.matcher(input);

        return matcher.matches();
    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter A String: ");
        String validateString = scanner.nextLine();

        System.out.println(validateString+" "+isValidCharacterSet(validateString));

        scanner.close();

    }

}

