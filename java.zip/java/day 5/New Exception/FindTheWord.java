// 8(L2)Write a Java program to find the word Python in a given string, if the word Python present in the string return Java otherwise
// return C++. Ignore case-sensitive.

import java.util.Scanner;
import java.util.regex.*;

class FindTheWord {

    private static String isContainsPython(String input) {
        Pattern pattern = Pattern.compile("\\bPython\\b", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(input);

        return matcher.find() ? "Java" : "C++";
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter A String: ");
        String validateString = scanner.nextLine();

        System.out.println("\""+validateString+"\" "+isContainsPython(validateString));
        scanner.close();
    }

}
