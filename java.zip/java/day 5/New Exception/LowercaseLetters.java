// 3(L2).Write a Java program to find sequences of lowercase letters joined with an underscore.

import java.util.Scanner;
import java.util.regex.*;

class LowercaseLetters {
    private static boolean isValidCharacterSet(String input) {
        Pattern pattern = Pattern.compile("[a-z]+_[a-z]+");
        Matcher matcher = pattern.matcher(input);

        return matcher.matches();
    }
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter A String: ");
        String validateString = scanner.nextLine();

        System.out.println(validateString+" "+isValidCharacterSet(validateString));

        scanner.close();
    }

}