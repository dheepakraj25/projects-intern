// Create a multithreaded program by creating a subclass of Thread and then creating, initializing, and staring two Thread objects 
// from your class. The threads will execute concurrently and display Java is hot, aromatic, and invigorating to the console window.

class CustomThread extends Thread {
    public CustomThread(String threadName) {
        super(threadName);
    }

    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName()+": Java is hot, aromatic, and invigorating");
    }
}

class CreateAMultithreaded {
    public static void main(String[] args) {
        CustomThread thread1 = new CustomThread("Thread 1");
        CustomThread thread2 = new CustomThread("Thread 2");

        thread1.start();
        thread2.start();
    } 
}
