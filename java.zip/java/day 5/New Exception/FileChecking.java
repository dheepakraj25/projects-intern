//Write a program to create a text file in the path c:\java\abc.txt and check whether that file is exists. Using the command exists(), isDirectory(), isFile(), getName() and getAbsolutePath().

import java.io.*;
public class FileChecking {
    public static void main(String[] args) {
        String filePath = "c:\\java\\abc.txt";        
        try {           
            File file = new File(filePath);                                                                // Create a File object
            
            boolean fileCreated = file.createNewFile();
            if (fileCreated) {
                System.out.println("File created successfully.");
            } else {
                System.out.println("File already exists.");
            }
           
            if (file.exists()) {
                System.out.println("File exists.");     
                
                if (file.isDirectory()) {
                    System.out.println("It's a directory.");
                } else {
                    System.out.println("It's not a directory.");
                }
                
                if (file.isFile()) {
                    System.out.println("It's a regular file.");
                } else {
                    System.out.println("It's not a regular file.");
                }
                
                
                System.out.println("File Name: " + file.getName());
                System.out.println("Absolute Path: " + file.getAbsolutePath());
            } else {
                System.out.println("File does not exist.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
