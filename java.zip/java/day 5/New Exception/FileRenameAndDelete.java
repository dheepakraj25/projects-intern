//Write a program to rename the given file, after renaming the file delete the renamed file. (Accept the file name using command line arguments.)


import java.io.*;
import java.util.*;

public class FileRenameAndDelete {
    public static void main(String[] args) {
        String fileName = args[0];
        File file = new File(fileName);

        if (!file.exists()) {
            System.out.println("File does not exist.");
            return;
        }

        Scanner sc = new Scanner(System.in);
        System.out.println("enter the new file name:");
        String newName = sc.nextLine();
        File renamedFile = new File(newName);
        
        file.renameTo(renamedFile); 
        System.out.println(fileName + " is renamed to " + newName);
        
        renamedFile.delete();
        System.out.println("Renamed file deleted");
    }
}

