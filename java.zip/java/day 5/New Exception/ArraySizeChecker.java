//(L1)Write a program using try and catch block where check whether the given array size is negative or not.
import java.util.Scanner;

public class ArraySizeChecker {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the array size: ");
        int arraySize = scanner.nextInt();

        try {
           
            if (arraySize < 0) {
              throw new Exception("Array size cannot be negative.");

            }
  
          
            System.out.println("Array created successfully with size " + arraySize);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}