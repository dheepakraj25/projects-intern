//Write a program to illustrate how to throw a NumberFormatException
import java.util.InputMismatchException;
import java.util.Scanner;

public class NumberFormatExceptionExample {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a number: ");
        try {
            int number = Integer.parseInt(scanner.nextLine());
            System.out.println("You entered: " + number);
        } catch (NumberFormatException e) {
           
            System.out.println("That's not a valid number! Please try again.");
            
            throw new NumberFormatException("The input was not a valid number.");
        }
    }
}