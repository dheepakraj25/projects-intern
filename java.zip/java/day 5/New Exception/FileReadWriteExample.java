//Write a program to show how to read and write a file
import java.io.*;

public class FileReadWriteExample {
    public static void main(String[] args) throws IOException {
       
        
        String outputFile = "output.txt";

        
        try {
            FileWriter writer = new FileWriter(outputFile);
            writer.write("Hello, Welcome to ZOHO Intern 2024!\n");
            writer.close();
            System.out.println("Successfully written to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred .");
            e.printStackTrace();
        }

        try {
            FileReader reader = new FileReader(outputFile);
            int character;
            while ((character = reader.read()) != -1) {
                System.out.print((char) character);
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("An error occurred .");
            e.printStackTrace();
        }
    }
}
