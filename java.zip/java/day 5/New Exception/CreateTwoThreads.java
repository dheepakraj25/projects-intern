// Write a program to create two threads. In this class we have one constructor used to start the thread and run it.
// Check whether these two threads are run are not.

class ThreadClass extends Thread {
    public ThreadClass(String threadName) {
        super(threadName);
        start();
    }

    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println(Thread.currentThread().getName() + ": " + i);

            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } 
    }
}



class CreateTwoThreads {
    public static void main(String[] args) {
        ThreadClass thread1 = new ThreadClass("Thread 1");
        ThreadClass thread2 = new ThreadClass("Thread 2");

        System.out.println("Is Thread 1 run or not? " + thread1.isAlive());
        System.out.println("Is Thread 2 run or not? " + thread2.isAlive());
    }
}
