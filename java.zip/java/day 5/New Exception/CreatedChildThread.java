//Write a program to create a class MyThread in this class a constructor, call the base class constructor, using super and starts the thread.
// The run method of the class starts after this. It can be observed that both the main thread and created child thread are executed concurrently.

class MyThread extends Thread {
    public MyThread() {
        super("Child Thread");
        start();
    }
 
    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println(Thread.currentThread().getName()+": "+i);

            try {
                Thread.sleep(300);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }
    }
}

class CreatedChildThread {
    public static void main(String[] args) {
        MyThread myThread = new MyThread();
        

        for (int i = 0; i < 5; i++) {
            System.out.println("Main Thread: " + i);

            try {
                Thread.sleep(300);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }
    }
}
