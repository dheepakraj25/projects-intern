//Write a program to accept a specified number of characters as input and converts them into uppercase characters.
import java.io.FileWriter;
import java.io.IOError;
import java.io.IOException;
import java.util.Scanner;

public class UppercaseCharacters { 
    public static void main(String[] args) throws IOException{
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter No Of Characters: ");
        int numChars = scanner.nextInt();

        System.out.print("Enter Chars: ");
        char[] chars = new char[numChars];
        for (int i = 0; i < numChars; i++) {
            chars[i] = Character.toUpperCase(scanner.next().charAt(0));
        }

        String content = new String(chars);
        System.out.println("Converted characters: "+content);

        FileWriter fileWriter = new FileWriter("UppercaseCharacters");
        fileWriter.write(content);
        fileWriter.close();

        scanner.close();
    }
    
}
