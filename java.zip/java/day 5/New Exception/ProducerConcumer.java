import java.util.LinkedList;


class SharedResource{

    private static SharedResource sharedResource = new SharedResource();
    public static SharedResource getInstance(){ return sharedResource; }

    private int consumedCount = 0;
    private boolean isConsuming = false;
    public LinkedList<String> sharedLinkedList = new LinkedList<>();

    public synchronized void produce() throws InterruptedException{
        // wait();

        System.out.println("["+consumedCount+"] Producing ");
        for(int i = 0; i < 5; i++) sharedLinkedList.add(String.valueOf(i));

        Thread.sleep(250);

        isConsuming = true;
        System.out.println("["+consumedCount+"] Production Done ");
        notify();
    }

    public synchronized void consume() throws InterruptedException{
        wait(); 
        
        System.out.println("["+consumedCount+"] Consuming ");
        for(int i = 0; i < 5; i++) sharedLinkedList.remove(String.valueOf(i));

        Thread.sleep(250);

        isConsuming = false;
        System.out.println("["+consumedCount+"] Consumption Done ");

        consumedCount++;
        notify();
    }
}

class Producer implements Runnable{
    @Override
    public void run(){
        while(true){
            try{
                SharedResource.getInstance().produce();
            }catch(InterruptedException exception){
                System.out.println(exception.getMessage());
            }
        }
    }

}

class Consumer implements Runnable{
    @Override
    public void run(){
        while(true){
            try{
                SharedResource.getInstance().consume();
            }catch(InterruptedException exception){
                System.out.println(exception.getMessage());
            }
        }
    }

}

class ProducerConcumer {
    public static void main(String[] args) throws InterruptedException{

        Thread t1 = new Thread(new Producer());
        Thread t2 = new Thread(new Consumer());

        t1.start();
        t2.start();
    }
}
