import java.util.ArrayList;

//Define the Base Class
 class Person {
    protected String name;
    protected int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void displayInfo() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}
//Create the Employee Class
 class Employee extends Person {
    protected String employeeID;
    protected String department;

    public Employee(String name, int age, String employeeID, String department) {
        super(name, age); // Call the constructor of the superclass, Person
        this.employeeID = employeeID;
        this.department = department;
    }

    @Override
    public void displayInfo() {
        super.displayInfo(); // Display the info available in Person
        System.out.println("Employee ID: " + employeeID + ", Department: " + department);
    }
}
//Define Specific Employee Types
 class Doctor extends Employee {
    private String specialization;

    public Doctor(String name, int age, String employeeID, String department, String specialization) {
        super(name, age, employeeID, department);
        this.specialization = specialization;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Specialization: " + specialization);
    }
}

 class Nurse extends Employee {
    private int yearsOfExperience;

    public Nurse(String name, int age, String employeeID, String department, int yearsOfExperience) {
        super(name, age, employeeID, department);
        this.yearsOfExperience = yearsOfExperience;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Years of Experience: " + yearsOfExperience);
    }
}
//Define the Patient Class
 class Patient extends Person {
    private String patientID;
    private String ailment;

    public Patient(String name, int age, String patientID, String ailment) {
        super(name, age);
        this.patientID = patientID;
        this.ailment = ailment;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Patient ID: " + patientID + ", Ailment: " + ailment);
    }
}
// Create a Main Class to Demonstrate
 class HospitalManagementSystem {
    public static void main(String[] args) {
        System.out.println("Doctors Available");
        System.out.println("-----------------");
	ArrayList<Doctor> doctors = new ArrayList<>();
	doctors.add(new Doctor("MSD", 45, "D123", "Cardiology", "Cardiologist"));
	doctors.add(new Doctor("MSD", 45, "D123", "Cardiology", "Cardiologist"));
	doctors.add(new Doctor("MSD", 45, "D123", "Cardiology", "Cardiologist"));
	doctors.add(new Doctor("MSD", 45, "D123", "Cardiology", "Cardiologist"));

        System.out.println("Nurse Available");
        
        ArrayList<Nurse> nurse = new ArrayList<>();
        nurse.add(new Nurse("ABD Smith", 32, "N456", "Pediatrics", 5));
        nurse.add(new Nurse("ABD Smith", 32, "N456", "Pediatrics", 5));

        
        Patient patient = new Patient("Bob", 60, "P789", "Heart Disease");

	for(Doctor doc : doctors){
		doc.displayInfo();
	}
        System.out.println("Nurse Available");
        System.out.println("---------------");
        for(Nurse nus: nurse){
        nus.displayInfo();
        }
        
        System.out.println("--------------------------------");
        patient.displayInfo();
    }
}
