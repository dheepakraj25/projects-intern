 class Employee {
    // Employee class properties
    String name;
    int yearOfJoining;
    String address;

    // Constructor to initialize the employee object
    public Employee(String name, int yearOfJoining, String address) {
        this.name = name;
        this.yearOfJoining = yearOfJoining;
        this.address = address;
    }

    // Method to display employee information
    public void displayInformation() {
        System.out.printf("%-20s %-15s %-20s\n", name, yearOfJoining, address);
    }

    public static void main(String[] args) {
        // Header
        System.out.printf("%-20s %-15s %-20s\n", "Name", "Year of joining", "Address");
        System.out.println("--------------------------------------------------------------");

        // Creating employee objects
        Employee employee1 = new Employee("Ashwin", 1994, "64C- WallsStreat");
        Employee employee2 = new Employee("Robert", 2000, "68D- WallsStreat");
        Employee employee3 = new Employee("John", 1999, "26B- WallsStreat");

        // Displaying employee information
        employee1.displayInformation();
        employee2.displayInformation();
        employee3.displayInformation();
    }
}
