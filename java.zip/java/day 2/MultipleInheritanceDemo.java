//Write a program for demonstrating Multiple Inheritance in java.
// Interface for the first parent class
interface Vehicl1 {
    void bike();
}

// Interface for the second parent class
interface Vehicl2 {
    void car();
}

// Child class implementing both Parent1 and Parent2 interfaces
class Ride implements Vehicl1, Vehicl2 {
    @Override
    public void bike() {
        System.out.println("Im rideing in Bike");
    }

    @Override
    public void car() {
        System.out.println("Im rideing in Car");
    }
}

public class MultipleInheritanceDemo {
    public static void main(String[] args) {
        Ride ride = new Ride();
        ride.bike(); 
        ride.car(); 
    }
}
