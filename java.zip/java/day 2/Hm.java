import java.util.ArrayList;
import java.util.Scanner;

// Parent class
class Hospital {
    protected String name;
    protected String address;
    protected ArrayList<Employee> employees;

    public Hospital(String name, String address) {
        this.name = name;
        this.address = address;
        this.employees = new ArrayList<>();
    }

    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    public void displayHospitalInfo() {
        System.out.println("Hospital Name: " + name);
        System.out.println("Address: " + address);
    }

    public void displayEmployees() {
        System.out.println("Employees:");
        for (Employee employee : employees) {
            System.out.println(employee);
        }
    }
}

// Child class
class Employee {
    protected String name;
    protected int age;
    protected String designation;

    public Employee(String name, int age, String designation) {
        this.name = name;
        this.age = age;
        this.designation = designation;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Age: " + age + ", Designation: " + designation;
    }
}

// Subclass of Employee
class Doctor extends Employee {
    protected String specialization;

    public Doctor(String name, int age, String designation, String specialization) {
        super(name, age, designation);
        this.specialization = specialization;
    }

    @Override
    public String toString() {
        return super.toString() + ", Specialization: " + specialization;
    }
}

// Subclass of Employee
class Nurse extends Employee {
    protected String department;

    public Nurse(String name, int age, String designation, String department) {
        super(name, age, designation);
        this.department = department;
    }

    @Override
    public String toString() {
        return super.toString() + ", Department: " + department;
    }
}

 class Hm {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter hospital name: ");
        String hospitalName = scanner.nextLine();
        System.out.println("Enter hospital address: ");
        String hospitalAddress = scanner.nextLine();

        Hospital hospital = new Hospital(hospitalName, hospitalAddress);

        System.out.println("Enter the number of doctors: ");
        int numDoctors = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        for (int i = 0; i < numDoctors; i++) {
            System.out.println("Enter doctor name: ");
            String doctorName = scanner.nextLine();
            System.out.println("Enter doctor age: ");
            int doctorAge = scanner.nextInt();
            scanner.nextLine(); // Consume newline character
            System.out.println("Enter doctor specialization: ");
            String doctorSpecialization = scanner.nextLine();

            Doctor doctor = new Doctor(doctorName, doctorAge, "Doctor", doctorSpecialization);
            hospital.addEmployee(doctor);
        }

        System.out.println("Enter the number of nurses: ");
        int numNurses = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        for (int i = 0; i < numNurses; i++) {
            System.out.println("Enter nurse name: ");
            String nurseName = scanner.nextLine();
            System.out.println("Enter nurse age: ");
            int nurseAge = scanner.nextInt();
            scanner.nextLine(); // Consume newline character
            System.out.println("Enter nurse department: ");
            String nurseDepartment = scanner.nextLine();

            Nurse nurse = new Nurse(nurseName, nurseAge, "Nurse", nurseDepartment);
            hospital.addEmployee(nurse);
        }

        System.out.println("\nHospital Information:");
        hospital.displayHospitalInfo();

        System.out.println("\nEmployees Information:");
        hospital.displayEmployees();

        scanner.close();
    }
}
