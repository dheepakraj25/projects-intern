import java.util.Scanner;

public class PowerCalculation {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the base number: ");
        int base = scanner.nextInt();
        
        System.out.print("Enter the exponent (power): ");
        int exponent = scanner.nextInt();
        
        long result = 1;
        
        // Handling negative exponents
        if (exponent < 0) {
            System.out.println("This program does not handle negative exponents.");
            return;
        }
        
        for (int i = 1; i <= exponent; i++) {
            result *= base;
        }
        
        System.out.println("Result: " + base + " raised to the power of " + exponent + " is " + result);
    }
}
