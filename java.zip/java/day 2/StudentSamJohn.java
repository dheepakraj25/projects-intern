 class StudentSamJohn {
    private String name;
    private int rollNumber;
    private String phoneNumber;
    private String address;

   
    public StudentSamJohn(String name, int rollNumber, String phoneNumber, String address) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }


    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Roll Number: " + rollNumber);
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Address: " + address);
    }

    public static void main(String[] args) {
        
        StudentSamJohn sam = new  StudentSamJohn("Sam", 101, "1234567890", "123 Main St");
        StudentSamJohn john = new  StudentSamJohn("John", 102, "9876543210", "456 Elm St");

        
        System.out.println("Details of Student Sam:");
        sam.displayInfo();
        System.out.println();

        System.out.println("Details of Student John:");
        john.displayInfo();
    }
}
