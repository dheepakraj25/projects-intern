public class QuadraticEquationSolver {

    public static void main(String[] args) {
        double a = 1;
        double b = 5;
        double c = 6;

        solveQuadraticEquation(a, b, c);
    }

    public static void solveQuadraticEquation(double a, double b, double c) {
        double discriminant = b * b - 4 * a * c;
        double sqrtVal = Math.sqrt(Math.abs(discriminant));

        if (a == 0) {
            System.out.println("This is not a quadratic equation.");
        } else if (discriminant > 0) {
            System.out.println("The equation has two real and distinct roots.");
            double root1 = (-b + sqrtVal) / (2 * a);
            double root2 = (-b - sqrtVal) / (2 * a);
            System.out.println("Root 1 = " + root1 + " and Root 2 = " + root2);
        } else if (discriminant == 0) {
            System.out.println("The equation has one real root (a double root).");
            double root = -b / (2 * a);
            System.out.println("Root = " + root);
        } else {
            System.out.println("The equation has two complex roots.");
            double realPart = -b / (2 * a);
            double imaginaryPart = sqrtVal / (2 * a);
            System.out.println("Root 1 = " + realPart + " + " + imaginaryPart + "i");
            System.out.println("Root 2 = " + realPart + " - " + imaginaryPart + "i");
        }
    }
}
