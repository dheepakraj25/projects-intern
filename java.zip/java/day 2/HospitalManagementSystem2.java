import java.util.ArrayList;
import java.util.Scanner;

class Person {
    protected String name;
    protected int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void displayInfo() {
        System.out.println("Name: " + name + ", Age: " + age);
    }
}

class Employee extends Person {
    protected String employeeID;
    protected String department;

    public Employee(String name, int age, String employeeID, String department) {
        super(name, age);
        this.employeeID = employeeID;
        this.department = department;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Employee ID: " + employeeID + ", Department: " + department);
    }
}

class Doctor extends Employee {
    public String specialization;

    public Doctor(String name, int age, String employeeID, String department, String specialization) {
        super(name, age, employeeID, department);
        this.specialization = specialization;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Specialization: " + specialization);
    }
}

class Nurse extends Employee {
    private int yearsOfExperience;

    public Nurse(String name, int age, String employeeID, String department, int yearsOfExperience) {
        super(name, age, employeeID, department);
        this.yearsOfExperience = yearsOfExperience;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Years of Experience: " + yearsOfExperience);
    }
}

class Patient extends Person {
    private String patientID;
    public String ailment;
    private String appointmentDate;
    private Doctor assignedDoctor;

    public Patient(String name, int age, String patientID, String ailment) {
        super(name, age);
        this.patientID = patientID;
        this.ailment = ailment;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public void setAssignedDoctor(Doctor doctor) {
        this.assignedDoctor = doctor;
    }

    public Doctor getAssignedDoctor() {
        return assignedDoctor;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Patient ID: " + patientID + ", Ailment: " + ailment);
        if (appointmentDate != null) {
            System.out.println("Appointment Date: " + appointmentDate);
        }
        if (assignedDoctor != null) {
            System.out.println("Assigned Doctor:");
            assignedDoctor.displayInfo();
        }
    }
}

class Bill {
    private double amount;
    private String description;

    public Bill(double amount, String description) {
        this.amount = amount;
        this.description = description;
    }

    public double getAmount() {
        return amount;
    }

    public void displayInfo() {
        System.out.println("Description: " + description);
        System.out.println("Amount: " + amount);
    }
}

class HospitalManagementSystem2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        ArrayList<Doctor> doctors = new ArrayList<>();
        doctors.add(new Doctor("MSD", 45, "D123", "Cardiology", "Cardiologist"));
        doctors.add(new Doctor("DSP", 28, "D124", "hormones and metabolism", "Endocrinologists"));
        doctors.add(new Doctor("SI", 40, "D125", "skin care", "Dermatologists"));
        doctors.add(new Doctor("MM", 35, "D126", "immune system disorders", "Immunologists"));

        ArrayList<Nurse> nurses = new ArrayList<>();
        nurses.add(new Nurse("ABD Smith", 32, "N456", "Pediatrics", 5));
        nurses.add(new Nurse("DS Smith", 32, "N456", "Pediatrics", 5));

        ArrayList<Patient> patients = new ArrayList<>();
        patients.add(new Patient("Bob", 60, "P789", "Heart Disease"));
        patients.add(new Patient("Tom", 30, "P788", "skin Disease"));
        patients.add(new Patient("Jerry", 40, "P789", "immunity Disease"));

        System.out.println("Doctors Available");
        System.out.println("-----------------");
        for (Doctor doc : doctors) {
            doc.displayInfo();
        }

        System.out.println("Nurses Available");
        System.out.println("---------------");
        for (Nurse nurse : nurses) {
            nurse.displayInfo();
        }

        System.out.println("Patients");
        System.out.println("--------------------------------");
        for (Patient pat : patients) {
            pat.displayInfo();
        }
        System.out.println("--------------------------------");

        // Assign doctors to patients based on ailment
        for (Patient pat : patients) {
            for (Doctor doc : doctors) {
                if (pat.ailment.equalsIgnoreCase(doc.specialization)) {
                    pat.setAssignedDoctor(doc);
                    break;
                }
            }
        }

        // Display patients with assigned doctors
        System.out.println("Patients with Assigned Doctors");
        System.out.println("--------------------------------");
        for (Patient pat : patients) {
            pat.displayInfo();
        }
        System.out.println("--------------------------------");

        scanner.close();
    }
}
