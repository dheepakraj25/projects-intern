//Task 1(Polymorphism)
//1(L1).Write a program for dynamic binding and static binding in Java
class Animal {
    void eat() {
        System.out.println("Animal is eating");
    }
}

class Dog extends Animal {
    void eat() {
        System.out.println("Dog is eating");
    }

    static void example() {
        System.out.println("Dog is playing");
    }
}

public class StaticDynamicBindingExample {
    public static void main(String[] args) {
        Animal a = new Dog();
        a.eat();  
        Dog.example(); 
    }
}
