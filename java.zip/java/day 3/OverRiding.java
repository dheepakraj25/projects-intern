//Can we prevent overriding? if yes code it and explain it
class Parent {
   
    public final void display() {
        System.out.println("This is a final method.");
    }
}

class Child extends Parent {
    
     public void display() {
         System.out.println("This method cannot be overridden.");
     }
}

public class OverRiding {
    public static void main(String[] args) {
        Parent parent = new Parent();
        Child child = new Child();
        
        parent.display(); 
        child.display(); 
    }
}
