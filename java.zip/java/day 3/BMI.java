package calculatorPackage2;
import calculatorPackage.Calculator;

 class BMI {
    public static void main(String[] args) {
        Calculator calculator = new Calculator(75, 1.75); 
        String bmiStatus = calculator.calculateBMI();
        System.out.println("BMI Status: " + bmiStatus);
    }
}