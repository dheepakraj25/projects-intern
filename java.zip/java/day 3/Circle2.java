package p2;
import p1.Circle;

public class Circle2 {
    public static void main(String[] args) {
        // Creating a Circle object from package p1
        Circle circle = new Circle(5.0);
        
        // Using methods of Circle class
        System.out.println("Radius of the circle: " + circle.getRadius());
        System.out.println("Area of the circle: " + circle.calculateArea());
        System.out.println("Perimeter of the circle: " + circle.calculatePerimeter());
    }
}