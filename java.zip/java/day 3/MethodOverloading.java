//Can we prevent overloading? if yes code it and explain it
 class MyClass {
    
    public void myMethod() {
        System.out.println("Method without parameters");
    }

    public  void myMethod(int x) {
        System.out.println("Method with int parameter: " + x);
    }

    public  void myMethod(String str) {
        System.out.println("Method with String parameter: " + str);
    }

    public void myMethod(int x, int y) {
        System.out.println("Method with two int parameters: " + x + ", " + y);
    }
}
 class MethodOverloading {
    public static void main(String[] args) {
        MyClass obj = new MyClass();

        obj.myMethod();
        obj.myMethod(5);
        obj.myMethod("Hello");
        obj.myMethod(3, 7);
    }
}
