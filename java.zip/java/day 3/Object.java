//Create an Instance Initializer block and explain the relation between Instance Inititilizer block with constructo
 class Employee {
    String name;
    int age;
    
    {
        System.out.println("Show Person1 Details.");
        name = "John Doe";
        age = 30;
    }
    
    public Employee() {
        System.out.println("Show Person2 Details.");
        name = "Jane Doe";
        age = 25;
    }
    
    public static void main(String[] args) {
        Employee employee = new Employee();
        System.out.println("Name: " + employee.name);
        System.out.println("Age: " + employee.age);
    }
}