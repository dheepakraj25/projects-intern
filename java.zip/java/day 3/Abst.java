//Create an abstract class 'Parent' with a method 'message'. It has two subclasses each having a method with the same name 'message' that prints "This is first subclass" and "This is second subclass" respectively. 
//Call the methods 'message' by creating an object for each subclass
 abstract class Animal {
    public abstract void message();
}


 class Tiger extends Animal {
    
    @Override
    public void message() {
        System.out.println("Tiger is a Wild Animal");
    }
}

 class Dog extends Animal {
    
    @Override
    public void message() {
        System.out.println("Dog is a pet Animal");
    }
}

 class Abst {
    public static void main(String[] args) {
        Tiger tiger = new Tiger();
        Dog dog = new Dog();

        tiger.message(); 
        dog.message(); 
    }
}