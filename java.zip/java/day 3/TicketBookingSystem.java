//Write a simple ticket booking system using polymorphism in Java
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

abstract class Ticket {
    protected String source;
    protected String destination;
    protected double price;

    public Ticket(String source, String destination, double price) {
        this.source = source;
        this.destination = destination;
        this.price = price;
    }

    public abstract void displayDetails();
}

class TrainTicket extends Ticket {
    private int trainNumber;
    private String coachType;

    public TrainTicket(String source, String destination, double price, int trainNumber, String coachType) {
        super(source, destination, price);
        this.trainNumber = trainNumber;
        this.coachType = coachType;
    }

    @Override
    public void displayDetails() {
        System.out.println("Train Ticket Details:");
        System.out.println("Source: " + source);
        System.out.println("Destination: " + destination);
        System.out.println("Price: $" + price);
        System.out.println("Train Number: " + trainNumber);
        System.out.println("Coach Type: " + coachType);
    }
}

class FlightTicket extends Ticket {
    private String airline;
    private String flightNumber;

    public FlightTicket(String source, String destination, double price, String airline, String flightNumber) {        super(source, destination, price);
        this.airline = airline;
        this.flightNumber = flightNumber;
    }

   @Override
    public void displayDetails() {
        System.out.println("Flight Ticket Details:");
        System.out.println("Source: " + source);
        System.out.println("Destination: " + destination);
        System.out.println("Price: " + price);
        System.out.println("Airline: " + airline);
        System.out.println("Flight Number: " + flightNumber);
    }
}

public class TicketBookingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Ticket> tickets = new ArrayList<>();

        while (true) {
            System.out.println("1. Book Train Ticket");
            System.out.println("2. Book Flight Ticket");
            System.out.println("3. Display All Tickets");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter source: ");
                    String trainSource = scanner.nextLine();
                    System.out.print("Enter destination: ");
                    String trainDestination = scanner.nextLine();
                    System.out.print("Enter price: ");
                    double trainPrice = scanner.nextDouble();
                    System.out.print("Enter train number: ");
                    int trainNumber = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter coach type: ");
                    String coachType = scanner.nextLine();
                    tickets.add(new TrainTicket(trainSource, trainDestination, trainPrice, trainNumber, coachType));
                    break;
                case 2:
                    System.out.print("Enter source: ");
                    String flightSource = scanner.nextLine();
                    System.out.print("Enter destination: ");
                    String flightDestination = scanner.nextLine();
                    System.out.print("Enter price: ");
                    double flightPrice = scanner.nextDouble();
                    scanner.nextLine(); 
                    System.out.print("Enter airline: ");
                    String airline = scanner.nextLine();
                    System.out.print("Enter flight number: ");
                    String flightNumber = scanner.nextLine();
                    tickets.add(new FlightTicket(flightSource, flightDestination, flightPrice, airline, flightNumber));
                    break;
                case 3:
                    for (Ticket ticket : tickets) {
                        ticket.displayDetails();
                        System.out.println();
                    }
                    break;
                case 4:
                    System.out.println("Exiting program...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
}
