/*Write a Java program to create a new string from a given string by swapping the last two characters of the given string. 
The length of the given string must be two or more*/

public class Main {
    public static void main(String[] args) {
        String originalString = "Hello";
        String swappedString = swapLastTwoCharacters(originalString);
        System.out.println("Original String: " + originalString);
        System.out.println("Swapped String: " + swappedString);
    }

    public static String swapLastTwoCharacters(String str) {
        if (str == null || str.length() < 2) {
            return str;
        }
        
        char[] charArray = str.toCharArray();
        int length = charArray.length;
        
     
        char temp = charArray[length - 2];
        charArray[length - 2] = charArray[length - 1];
        charArray[length - 1] = temp;
        
        return new String(charArray);
    }
}
