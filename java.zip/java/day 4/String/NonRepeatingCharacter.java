/*Write a Java program to find the first non repeating character in a string */
public class NonRepeatingCharacter {
    public static char findFirstNonRepeatingChar(String str) {
        int[] charCount = new int[256]; 

       
        for (int i = 0; i < str.length(); i++) {
            charCount[str.charAt(i)]++;
        }

        
        for (int i = 0; i < str.length(); i++) {
            if (charCount[str.charAt(i)] == 1) {
                return str.charAt(i);
            }
        }

        
        return '\0';
    }

    public static void main(String[] args) {
        String input = "hello";
        char firstNonRepeatingChar = findFirstNonRepeatingChar(input);
        if (firstNonRepeatingChar != '\0') {
            System.out.println("First non-repeating character in \"" + input + "\" is: " + firstNonRepeatingChar);
        } else {
            System.out.println("No non-repeating character found in \"" + input + "\"");
        }
    }
}
