/*Write a Java program to replace each substring of a given string that matches the given regular expression with the given replacement.*/
public class StringReplace {
    public static void main(String[] args) {
        String input = "The quick brown fox jumps over the lazy dog";
        String regex = "fox";
        String replacement = "cat";

        String replacedString = replaceSubstring(input, regex, replacement);
        System.out.println("Original String: " + input);
        System.out.println("Replacement: " + replacement);
        System.out.println("Modified String: " + replacedString);
    }

    public static String replaceSubstring(String input, String regex, String replacement) {
        StringBuilder result = new StringBuilder();

        int lastIndex = 0;
        int index = input.indexOf(regex);
        while (index >= 0) {
            result.append(input.substring(lastIndex, index));
            result.append(replacement);
            lastIndex = index + regex.length();
            index = input.indexOf(regex, lastIndex);
        }
        result.append(input.substring(lastIndex));

        return result.toString();
    }
}
