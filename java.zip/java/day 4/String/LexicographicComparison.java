/*Write a Java program to compare two strings lexicographically. 
Two strings are lexicographically equal if they are the same length and contain the same characters in the same positions */

public class LexicographicComparison {
    public static void main(String[] args) {
        String str1 = "hello";
        String str2 = "world";
        
        
        if (str1.length() != str2.length()) {
            System.out.println("Strings are not lexicographically equal.");
            return;
        }
        
        boolean lexicographicallyEqual = true;
        for (int i = 0; i < str1.length(); i++) {
            if (str1.charAt(i) != str2.charAt(i)) {
                lexicographicallyEqual = false;
                break;
            }
        }
        
        if (lexicographicallyEqual) {
            System.out.println("Strings are lexicographically equal.");
        } else {
            System.out.println("Strings are not lexicographically equal.");
        }
    }
}
