/*Write a Java program to compare two strings lexicographically, ignoring case differences*/

public class StringComparison {
    public static void main(String[] args) {
        String str1 = "Hello";
        String str2 = "hello";

        if (compareStringsIgnoreCase(str1, str2) < 0) {
            System.out.println(str1 + " is lexicographically smaller than " + str2);
        } else if (compareStringsIgnoreCase(str1, str2) > 0) {
            System.out.println(str1 + " is lexicographically greater than " + str2);
        } else {
            System.out.println(str1 + " and " + str2 + " are lexicographically equal");
        }
    }

    public static int compareStringsIgnoreCase(String str1, String str2) {
        int len1 = str1.length();
        int len2 = str2.length();
        int len = Math.min(len1, len2);

        for (int i = 0; i < len; i++) {
            char ch1 = Character.toLowerCase(str1.charAt(i));
            char ch2 = Character.toLowerCase(str2.charAt(i));
            if (ch1 != ch2) {
                return ch1 - ch2;
            }
        }

        return len1 - len2;
    }
}
