/* Write a Java program to read two strings, append them together and return the result. 
If the strings are different lengths, remove characters from the beginning of the longer string and make them equal length.*/ 

import java.util.Scanner;

public class MergeStrings {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

       
        System.out.println("Enter the first string:");
        String str1 = scanner.nextLine();
        System.out.println("Enter the second string:");
        String str2 = scanner.nextLine();

        
        String result = mergeStrings(str1, str2);

        
        System.out.println("Merged String: " + result);
    }

    public static String mergeStrings(String str1, String str2) {
        
        int len1 = str1.length();
        int len2 = str2.length();

        if (len1 > len2) {
            str1 = str1.substring(0,len1 - len2);
        } else if (len2 > len1) {
            str2 = str2.substring(len2 - len1);
        }

        return str1 + str2;
    }
}
