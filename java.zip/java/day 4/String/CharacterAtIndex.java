/*Write a Java program to get the character at the given index within the String*/

import java.util.Scanner;

public class CharacterAtIndex {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();
        
        System.out.print("Enter the index: ");
        int index = scanner.nextInt();
        
        char result = getCharacterAtIndex(inputString, index);
        if (result != '\0') {
            System.out.println("Character at index " + index + " is: " + result);
        } else {
            System.out.println("Invalid index.");
        }
        
        scanner.close();
    }
    
    public static char getCharacterAtIndex(String str, int index) {
        if (index >= 0 && index < str.length()) {
            return str.charAt(index);
        } else {
            return '\0'; 
        }
    }
}
