/*Write a Java program to divide a string into n equal parts.*/

public class StringDivider {

    public static String[] divideString(String input, int n) {
        if (input == null || input.isEmpty() || n <= 0) {
            return new String[0]; 
        }

        int length = input.length();
        int partLength = length / n;
        int remainder = length % n;
        String[] parts = new String[n];

        int startIndex = 0;
        for (int i = 0; i < n; i++) {
            int partSize = partLength + (i < remainder ? 1 : 0);
            parts[i] = input.substring(startIndex, startIndex + partSize);
            startIndex += partSize;
        }

        return parts;
    }

    public static void main(String[] args) {
        String input = "This is a sample string to divide into parts";
        int n = 5;

        String[] dividedStrings = divideString(input, n);

        System.out.println("Original string: " + input);
        System.out.println("Divided into " + n + " parts:");
        for (String part : dividedStrings) {
            System.out.println(part);
        }
    }
}
