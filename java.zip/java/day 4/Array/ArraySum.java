/*Write a Java program to find the sum of the two elements of a given array which is equal to a given integer.
Sample array: [1,2,4,5,6]
Target value: 6*/
public class ArraySum {

    public static void main(String[] args) {
        int[] nums = {1, 2, 4, 5, 6};
        int target = 6;
        findTwoSum(nums, target);
    }

    public static void findTwoSum(int[] nums, int target) {
    
        for (int i = 0; i < nums.length - 1; i++) {
            for (int j = i + 1; j < nums.length; j++) {
                
                if (nums[i] + nums[j] == target) {
                    System.out.println("Indices of the two elements: " + i + ", " + j);
                    System.out.println("Elements: " + nums[i] + ", " + nums[j]);
                   
                }
            }
        }
        System.out.println("No two elements found with sum equal to the target value.");
    }
}
