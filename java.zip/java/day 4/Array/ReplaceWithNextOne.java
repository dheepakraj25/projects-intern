/*Write a Java program to replace every element with the next best element (from right side) in a given array of integers.
 There is no element next to the last element, therefore replace it with -1*/
public class ReplaceWithNextOne {
    public static void main(String[] args) {
        int[] arr = {4, 5, 2, 10, 8};

        replaceWithNextBest(arr);

        System.out.println("Modified Array:");
        for (int num : arr) {
            System.out.print(num + " ");
        }
    }

    public static void replaceWithNextBest(int[] arr) {
        int n = arr.length;
        int max_from_right = arr[n - 1];
        arr[n - 1] = -1; 
        for (int i = n - 2; i >= 0; i--) {
            int temp = arr[i];
            arr[i] = max_from_right;
            if (temp > max_from_right)
                max_from_right = temp;
        }
    }
}
