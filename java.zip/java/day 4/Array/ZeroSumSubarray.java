/*Write a Java program to check if a given array contains a subarray with 0 sum
Input :
nums1= { 1, 2, -2, 3, 4, 5, 6 }
nums2 = { 1, 2, 3, 4, 5, 6 }
nums3 = { 1, 2, -3, 4, 5, 6 }
Output:
Does the said array contain a subarray with 0 sum: true
Does the said array contain a subarray with 0 sum: false
Does the said array contain a subarray with 0 sum: true*/

public class ZeroSumSubarray {

    public static void main(String[] args) {
        int[] nums1 = {1, 2, -2, 3, 4, 5, 6};
        int[] nums2 = {1, 2, 3, 4, 5, 6};
        int[] nums3 = {1, 2, -3, 4, 5, 6};

        System.out.println("Does the array contain a subarray with 0 sum: " + hasZeroSumSubarray(nums1));
        System.out.println("Does the array contain a subarray with 0 sum: " + hasZeroSumSubarray(nums2));
        System.out.println("Does the array contain a subarray with 0 sum: " + hasZeroSumSubarray(nums3));
    }
    
    public static boolean hasZeroSumSubarray(int[] nums) {
        int sum = 0;
        for (int i = 0; i < nums.length; i++) {
            sum = 0;
            for (int j = i; j < nums.length; j++) {
                sum += nums[j];
                if (sum == 0)
                    return true;
            }
        }
        return false;
    }
}
