//Write a Java program to sort a numeric array and a string array
import java.util.Arrays;

public class ArraySortExample {
    public static void main(String[] args) {
        
        int[] numeric = {5, 2, 9, 1, 7};
        System.out.println("Original Numeric Array: " + Arrays.toString(numeric));

        
        Arrays.sort(numeric);
        System.out.println("Sorted Numeric Array: " + Arrays.toString(numeric));

        
        String[] string = {"banana", "apple", "orange", "grape", "pineapple"};
        System.out.println("\nOriginal String Array: " + Arrays.toString(string));

        Arrays.sort(string);
        System.out.println("Sorted String Array: " + Arrays.toString(string));
    }
}
