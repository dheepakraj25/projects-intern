/*Write a Java program to check if a sub-array is formed by consecutive integers from a given array of integers.*/

public class ConsecutiveSubarray {
    
    public static void main(String[] args) {
        int[] nums = { 2, 5, 0, 2, 1, 4, 3, 6, 1, 0 };
        findLargestConsecutiveSubarray(nums);
    }
    
    public static void findLargestConsecutiveSubarray(int[] nums) {
        int maxLength = 0;
        int maxStartIndex = 0;
        
        int currentLength = 1;
        int currentStartIndex = 0;
        
        for (int i = 1; i < nums.length; i++) {
            if (nums[i] == nums[i - 1] + 1) {
                currentLength++;
            } else {
                if (currentLength > maxLength) {
                    maxLength = currentLength;
                    maxStartIndex = currentStartIndex;
                }
                currentLength = 1;
                currentStartIndex = i;
            }
        }
        
        if (currentLength > maxLength) {
            maxLength = currentLength;
            maxStartIndex = currentStartIndex;
        }
        
        System.out.print("The largest sub-array is :");
        for (int i = maxStartIndex; i < maxStartIndex + maxLength; i++) {
            System.out.print(nums[i]);
            if (i < maxStartIndex + maxLength - 1) {
                System.out.print(", ");
            }
        }
              
        System.out.print("Elements of the sub-array: ");
        for (int i = maxStartIndex; i < maxStartIndex + maxLength; i++) {
            System.out.print(nums[i] + " ");
        }
        System.out.println();
    }
}
