/* Write a Java program to sort an array of positive integers of a given array. 
In the sorted array the value of the first element should be maximum,
 second value should be minimum value, 
third should be the second maximum, fourth second be second minimum and so on*/
import java.util.Arrays;

public class AlternateSorting {
    public static void main(String[] args) {
        int[] arr = {5, 9, 2, 7, 1, 8, 3, 6, 4}; 

        Arrays.sort(arr);

        int n = arr.length;
        int[] result = new int[n];

        int left = 0, right = n - 1;
        for (int i = 0; i < n; i++) {
            if (i % 2 == 0) {
                result[i] = arr[right--]; 
            } else {
                result[i] = arr[left++]; 
            }
        }

        System.out.println("Sorted array with alternate max and min values:");
        for (int num : result) {
            System.out.print(num + " ");
        }
    }
}
