/*Program to perform various operations on ArrayList.*/
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class ArrayListOperations {
    public static void main(String[] args) {
        
        Collection<String> colors = new ArrayList<>();

       
        colors.add("Red");
        colors.add("Blue");
        colors.add("Green");
        colors.add("Yellow");

        System.out.println("ArrayList: " + colors);

        colors.add("Orange");
        System.out.println("ArrayList after adding 'Orange': " + colors);

        colors.remove("Green");
        System.out.println("ArrayList after removing 'Green': " + colors);

        
        if (colors.contains("Red")) {
            System.out.println("ArrayList contains 'Red'");
        } else {
            System.out.println("ArrayList does not contain 'Red'");
        }

        ArrayList<String> sortedColors = new ArrayList<>(colors);
        Collections.sort(sortedColors);
        System.out.println("Sorted ArrayList: " + sortedColors);
    }
}
