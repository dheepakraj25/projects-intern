/* Prints the size of the ArrayList*/
import java.util.ArrayList;
import java.util.Collection;

public class ArrayListSize {
    public static void main(String[] args) {
        
        ArrayList<Integer> arrayList = new ArrayList<>();

        arrayList.add(10);
        arrayList.add(20);
        arrayList.add(30);
        arrayList.add(40);
        arrayList.add(50);

        printSize(arrayList);
    }

    public static void printSize(Collection<?> collection) {
        System.out.println("Size of the ArrayList: " + collection.size());
    }
}
