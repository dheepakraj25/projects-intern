import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

 class MyMap<K, V> {
    private final Map<K, V> map;

    public MyMap() {
        this.map = new HashMap<>();
    }

    public void put(K key, V value) {
        map.put(key, value);
    }

    public V get(K key) {
        return map.get(key);
    }

    public void remove(K key) {
        map.remove(key);
    }

    public boolean containsKey(K key) {
        return map.containsKey(key);
}

    public boolean containsValue(V value) {
        return map.containsValue(value);
    }

    public int size() {
        return map.size();
    }

    public boolean isEmpty() {
        return map.isEmpty();
    }

    public void clear() {
        map.clear();
    }

    public Collection<V> values() {
        return map.values();
    }

    public Collection<Map.Entry<K, V>> entrySet() {
        return map.entrySet();
    }
public static void main(String[] args) {
    MyMap<String, Integer> map = new MyMap<>();
    map.put("apple", 1);
    map.put("banana", 2);
    map.put("orange", 3);

    System.out.println(map.get("apple")); 
    System.out.println(map.containsKey("banana"));
    System.out.println(map.containsValue(3));
    System.out.println(map.size()); 

    map.remove("orange");
    System.out.println(map.isEmpty()); 

    for (Map.Entry<String, Integer> entry : map.entrySet()) {
        System.out.println(entry.getKey() + ":" + entry.getValue());
    }
   
}
}