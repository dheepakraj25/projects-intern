/*Make a searching, inserting,deleting and updating operation in Linked list*/
import java.util.Collection;
import java.util.LinkedList;
import java.util.ListIterator;

public class LinkedListOperations {
    public static void main(String[] args) {
        
        LinkedList<String> linkedList = new LinkedList<>();

        
        linkedList.add("Apple");
        linkedList.add("Banana");
        linkedList.add("Cherry");

        System.out.println("Original LinkedList: " + linkedList);

       
        String searchElement = "Banana";
        int index = search(linkedList, searchElement);
        if (index != -1) {
            System.out.println(searchElement + " found at index " + index);
        } else {
            System.out.println(searchElement + " not found in the list");
        }

        int insertIndex = 1;
        String insertElement = "Grapes";
        insert(linkedList, insertIndex, insertElement);
        System.out.println("After inserting " + insertElement + " at index " + insertIndex + ": " + linkedList);

        
        String deleteElement = "Banana";
        delete(linkedList, deleteElement);
        System.out.println("After deleting " + deleteElement + ": " + linkedList);

        int updateIndex = 2;
        String updatedElement = "Mango";
        update(linkedList, updateIndex, updatedElement);
        System.out.println("After updating element at index " + updateIndex + " to " + updatedElement + ": " + linkedList);
    }

    private static int search(Collection<String> collection, String element) {
        ListIterator<String> iterator = ((LinkedList<String>) collection).listIterator();
        while (iterator.hasNext()) {
            if (iterator.next().equals(element)) {
                return iterator.previousIndex();
            }
        }
        return -1;
    }

   
    private static void insert(LinkedList<String> linkedList, int index, String element) {
        linkedList.add(index, element);
    }

    private static void delete(LinkedList<String> linkedList, String element) {
        linkedList.remove(element);
    }

    private static void update(LinkedList<String> linkedList, int index, String element) {
        linkedList.set(index, element);
    }
}
