/*write a java program to Reverses the ArrayList A */
import java.util.ArrayList;
import java.util.Collections;

public class ReverseArrayList {
    public static void main(String[] args) {
        
        ArrayList<Integer> arrayList = new ArrayList<>();

        
        arrayList.add(1);
        arrayList.add(2);
        arrayList.add(3);
        arrayList.add(4);
        arrayList.add(5);

        
        System.out.println("Original ArrayList: " + arrayList);

        Collections.reverse(arrayList);

        System.out.println("Reversed ArrayList: " + arrayList);
    }
}
