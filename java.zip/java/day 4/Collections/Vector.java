/*Program to show up the vector class and its methods*/
public class Vector {
    private double x;
    private double y;

    public Vector(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double magnitude() {
        return Math.sqrt(x * x + y * y);
    }

    public static void main(String[] args) {
        Vector v1 = new Vector(3, 4);
        Vector v2 = new Vector(1, 2);

        System.out.println("Vector 1: (" + v1.getX() + ", " + v1.getY() + ")");
        System.out.println("Vector 2: (" + v2.getX() + ", " + v2.getY() + ")");
        System.out.println("Magnitude of Vector 1: " + v1.magnitude());
        System.out.println("Magnitude of Vector 2: " + v2.magnitude());
    }
}
