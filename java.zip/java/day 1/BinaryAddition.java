import java.util.Scanner;

 class BinaryAddition {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter the first binary number: ");
        String binary1 = scanner.next();

        System.out.print("Enter the second binary number: ");
        String binary2 = scanner.next();

        int number1 = Integer.parseInt(binary1, 2);
        int number2 = Integer.parseInt(binary2, 2);

        
        int sum = number1 + number2;

        String binarySum = Integer.toBinaryString(sum);

       
        System.out.println("Sum of " + binary1 + " and " + binary2 + " is " + binarySum);

        
    }
}
