import java.util.Scanner;

 class MethodCallCounter {

   
    private static int methodCallCount = 0;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of times to call the method: ");
        int times = scanner.nextInt();

       
        for (int i = 0; i < times; i++) {
            incrementMethodCallCount();
        }

        System.out.println("The method was called " + methodCallCount + " times.");

        scanner.close();
    }

    public static void incrementMethodCallCount() {
        
        methodCallCount++;
    }
}
