public class DataTypeSizesRanges {

    public static void main(String[] args) {
        // Byte
        System.out.println("Byte:");
        System.out.println("Size: " + Byte.BYTES + " bytes");
        System.out.println("Min: " + Byte.MIN_VALUE);
        System.out.println("Max: " + Byte.MAX_VALUE);
        System.out.println();

        // Short
        System.out.println("Short:");
        System.out.println("Size: " + Short.BYTES + " bytes");
        System.out.println("Min: " + Short.MIN_VALUE);
        System.out.println("Max: " + Short.MAX_VALUE);
        System.out.println();

        // Integer
        System.out.println("Integer:");
        System.out.println("Size: " + Integer.BYTES + " bytes");
        System.out.println("Min: " + Integer.MIN_VALUE);
        System.out.println("Max: " + Integer.MAX_VALUE);
        System.out.println();

        // Long
        System.out.println("Long:");
        System.out.println("Size: " + Long.BYTES + " bytes");
        System.out.println("Min: " + Long.MIN_VALUE);
        System.out.println("Max: " + Long.MAX_VALUE);
        System.out.println();

        // Float
        System.out.println("Float:");
        System.out.println("Size: " + Float.BYTES + " bytes");
        System.out.println("Min: " + Float.MIN_VALUE); // Represents the smallest positive nonzero value of type float
        System.out.println("Max: " + Float.MAX_VALUE);
        System.out.println();

        // Double
        System.out.println("Double:");
        System.out.println("Size: " + Double.BYTES + " bytes");
        System.out.println("Min: " + Double.MIN_VALUE); // Represents the smallest positive nonzero value of type double
        System.out.println("Max: " + Double.MAX_VALUE);
        System.out.println();

        // Character
        System.out.println("Character:");
        System.out.println("Size: " + Character.BYTES + " bytes");
        System.out.println("Min: " + (int) Character.MIN_VALUE);
        System.out.println("Max: " + (int) Character.MAX_VALUE);
        System.out.println();

        // Boolean
        System.out.println("Boolean:");
        System.out.println("Size: not precisely defined (virtual machine dependent)");
        System.out.println("Values: " + Boolean.FALSE + " (false), " + Boolean.TRUE + " (true)");
    }
}
