import java.util.Scanner;

public class Multiplication {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a integer: ");
        
        int integer = scanner.nextInt();

       
        scanner.close();

        
        System.out.println("Multiplication  of " + integer + ":");
        for (int i = 1; i <= 10; i++) {
            System.out.println(integer + " * " + i + " = " + (integer * i));
        }
    }
}
