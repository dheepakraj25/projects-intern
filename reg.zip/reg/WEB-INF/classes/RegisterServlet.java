import jakarta.servlet.http.*;
import jakarta.servlet.*;
import java.io.*;
import java.sql.*;

public class RegisterServlet extends HttpServlet {

    private static final String URL = "jdbc:postgresql://localhost:5432/university";
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "Dheepakr@j25082001";

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String rollNo = request.getParameter("rollNo");
        double fees = Double.parseDouble(request.getParameter("fees"));
        String status = request.getParameter("status");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            Class.forName("org.postgresql.Driver");
            Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            insertStudent(connection, name, rollNo, fees, status);
            connection.close();
            response.sendRedirect("registrationSuccess.jsp");
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            String errorMessage = e.getMessage();
            out.write("<h1 style='text-align: center; color: red;'>Error occurred: " + errorMessage + "</h1>");
        }
    }

    private void insertStudent(Connection connection, String name, String rollNo, double fees, String status) throws SQLException {
        String sql = "INSERT INTO students (name, roll_no, fees, status) VALUES (?, ?, ?, ?)";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, name);
        statement.setString(2, rollNo);
        statement.setDouble(3, fees);
        statement.setString(4, status);
        statement.executeUpdate();
        statement.close();
    }
}
