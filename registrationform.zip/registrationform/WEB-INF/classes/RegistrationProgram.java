import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class RegistrationProgram extends HttpServlet {

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        Connection conn = null;
        PreparedStatement statement = null;
        
        int id = Integer.parseInt(request.getParameter("id"));
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        try {
            Class.forName("org.postgresql.Driver");  
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/servlet","postgres","Dheepakr@j25082001");
            
            String sql = "INSERT INTO users (id, username, email, password) VALUES (?, ?, ?, ?)";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, id);
            statement.setString(2, username);
            statement.setString(3, email);
            statement.setString(4, password);
            
            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                out.println("<html><body>");
                out.println("<h2>Registration Successful</h2>");
                out.println("<p>ID: " + id + "</p>");
                out.println("<p>Username: " + username + "</p>");
                out.println("<p>Email: " + email + "</p>");
                out.println("</body></html>");
            } else {
                out.println("<html><body>");
                out.println("<h2>Registration Failed</h2>");
                out.println("</body></html>");
            }
            
        } catch (ClassNotFoundException e) {
            out.println("Error: PostgreSQL JDBC Driver not found!");
        } catch (SQLException e) {
            out.println("Error: " + e.getMessage());
        } finally {
            
            try {
                if (statement != null) {
                    statement.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                out.println("Error while closing resources: " + e.getMessage());
            }
        }
    }
}
