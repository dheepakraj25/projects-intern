import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class RegistrationProgramDisplay extends HttpServlet {

    private static final int RECORDS_PER_PAGE = 3;

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        int page = 1;
        if (request.getParameter("page") != null) {
            page = Integer.parseInt(request.getParameter("page"));
        }

        Connection conn = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/servlet", "postgres", "Dheepakr@j25082001");

            int offset = (page - 1) * RECORDS_PER_PAGE;

            String sql = "SELECT id, username, email FROM users ORDER BY id LIMIT ? OFFSET ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, RECORDS_PER_PAGE);
            statement.setInt(2, offset);

            resultSet = statement.executeQuery();

            out.println("<html><body>");
            out.println("<h2>User List</h2>");
            out.println("<table border='1'><tr><th>ID</th><th>Username</th><th>Email</th></tr>");

            while (resultSet.next()) {
                out.println("<tr>");
                out.println("<td>" + resultSet.getInt("id") + "</td>");
                out.println("<td>" + resultSet.getString("username") + "</td>");
                out.println("<td>" + resultSet.getString("email") + "</td>");
                out.println("</tr>");
            }

            out.println("</table>");

            out.println("<br/>");
            if (page > 1) {
                out.println("<a href='?page=" + (page - 1) + "'>Previous</a>");
            }
         

            
            if (hasNextPage(conn, page, RECORDS_PER_PAGE)) {
                out.println("<a href='?page=" + (page + 1) + "'>Next</a>");
            }

            out.println("</body></html>");

        } catch (ClassNotFoundException e) {
            out.println("Error: PostgreSQL JDBC Driver not found!");
        } catch (SQLException e) {
            out.println("Error: " + e.getMessage());
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                out.println("Error while closing resources: " + e.getMessage());
            }
        }
    }

    private boolean hasNextPage(Connection conn, int currentPage, int recordsPerPage) throws SQLException {
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            int offset = currentPage * recordsPerPage;
            String sql = "SELECT 1 FROM users LIMIT 1 OFFSET ?";
            statement = conn.prepareStatement(sql);
            statement.setInt(1, offset);
            resultSet = statement.executeQuery();
            return resultSet.next();
        } finally {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
        }
    }
}
