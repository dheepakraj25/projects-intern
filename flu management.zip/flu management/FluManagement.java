import java.io.*;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

class Person implements Serializable {
    public int age;
    public String name;
    public String bloodGroup;
    public String location;
    protected boolean isAlive;
}

class InvalidAgeException extends Exception {
    InvalidAgeException(String message) {
        super(message);
    }
}

class Patient extends Person implements Serializable {
    private static final long serialVersionUID = 1L;

    private static int counter = 0;
    private int id;
    public int getId() {
        return id;
    }

    HashMap<String, Boolean> symptomMap;
    private int affectedPercent;
    private LinkedList<String> treatments = new LinkedList<>();
    public boolean isCured;

    Patient(String name, int age, String bloodGroup, String location, String[] symptoms) {
        this.name = name;
        this.age = age;
        this.bloodGroup = bloodGroup;
        this.id = ++counter;
        this.location = location;
        this.affectedPercent = 100;
        this.symptomMap = new HashMap<>();
        for (String symptom : symptoms) {
            this.symptomMap.put(symptom, true);
        }
        this.isCured = false;
        this.isAlive = true;
    }

    public boolean hasSymptom(String symptom) {
        return this.symptomMap.containsKey(symptom);
    }

    public boolean hadTreatment(String treatment) {
        return this.treatments.contains(treatment);
    }

   public void addTreatment(String treatment, LinkedList<Patient> curedPatients) {
    if (!this.isAlive || this.isCured) return;

    if (treatment.equals("TreatmentFever")) {
        affectedPercent -= 40;
        treatments.add(treatment);
    } else if (treatment.equals("TreatmentCold")) {
        affectedPercent -= 50;
        treatments.add(treatment);
    } else {
        this.affectedPercent += 30;
        if (affectedPercent > 100) {
            this.isAlive = false;
        }
        treatments.add(treatment);
    }

    if (affectedPercent <= 0) {
        this.affectedPercent = 0;
        this.isCured = true;
        curedPatients.add(this); // Add cured patient to the list of cured patients
    }
}

    public String toFormattedString() {
        return String.format("ID: %d, Name: %s, Age: %d, Blood Group: %s, Fever: %s, Cold: %s, Cough: %s, TreatmentFever: %s, TreatmentCold: %s, TreatmentCough: %s",
                id, name, age, bloodGroup,
                (hasSymptom("Fever") ? "yes" : "no"),
                (hasSymptom("Cold") ? "yes" : "no"),
                (hasSymptom("Cough") ? "yes" : "no"),
                (hadTreatment("TreatmentFever") ? "yes" : "no"),
                (hadTreatment("TreatmentCold") ? "yes" : "no"),
                (hadTreatment("TreatmentCough") ? "yes" : "no"));
    }

    public String toCsvString() {
        return id + ", " + name + ", " + age + ", " + bloodGroup + ",  " + hasSymptom("Fever") + ", " + hasSymptom("Cold") + ", " + hasSymptom("Cough") + ", " + treatments.toString() + ", " + affectedPercent;
    }

    // Public method to access treatments
    public LinkedList<String> getTreatments() {
        return this.treatments;
    }
}

class Analysis implements Serializable {
    private static final long serialVersionUID = 1L;

    public static LinkedList<Patient> getOverview(LinkedList<Patient> patients, int type) {
        LinkedList<Patient> result = new LinkedList<>();
        if (type == 1) {
            for (Patient patient : patients) {
                if (patient.isCured) result.add(patient);
            }
        } else if (type == 2) {
            for (Patient patient : patients) {
                if (!patient.isAlive) result.add(patient);
            }
        } else if (type == 3) {
            for (Patient patient : patients) {
                if (!patient.getTreatments().isEmpty()) result.add(patient);
            }
        } else if (type == 4) {
            for (Patient patient : patients) {
                if (patient.getTreatments().isEmpty()) result.add(patient);
            }
        }
        return result;
    }


    public static LinkedList<Patient> getByTreatment(LinkedList<Patient> patients, String... treatments) {
        LinkedList<Patient> result = new LinkedList<>();
        for (Patient patient : patients) {

            boolean isContainFlag = true;
            for (String treatment : treatments) {
                if (!patient.hadTreatment(treatment)) {
                    isContainFlag = false;
                    break;
                }
            }

            if (isContainFlag) {
                result.add(patient);
            }
        }
        return result;
    }

    public static LinkedList<Patient> getBySymptom(LinkedList<Patient> patients, String... symptoms) {
        LinkedList<Patient> result = new LinkedList<>();
        for (Patient patient : patients) {

            boolean isContainFlag = true;
            for (String symptom : symptoms) {
                if (!patient.hasSymptom(symptom)) {
                    isContainFlag = false;
                    break;
                }
            }

            if (isContainFlag) {
                result.add(patient);
            }
        }
        return result;
    }

    public static LinkedList<Patient> getByLocation(LinkedList<Patient> patients, String location) {
        LinkedList<Patient> result = new LinkedList<>();
        for (Patient patient : patients) {
            if (patient.location.equalsIgnoreCase(location)) {
                result.add(patient);
            }
        }
        return result;
    }

    public static int[] groupByAge(LinkedList<Patient> patients, int ageGap) throws InvalidAgeException {
        if (ageGap == 0) {
            throw new InvalidAgeException("Age Cannot Be Less Than 1");
        }

        int[] array = new int[(100 / ageGap)];
        java.util.Arrays.fill(array, 0);

        for (Patient patient : patients) {
            array[(patient.age + 1) / ageGap]++;
        }

        return array;
    }
}

class FluManagement implements Serializable {
   private static final long serialVersionUID = 1L;

    private LinkedList<Patient> patients;
    private LinkedList<String> locations;

    FluManagement() {
        this.patients = new LinkedList<>();
        this.locations = new LinkedList<>();
    }

    public static FluManagement loadPatients() {
        FluManagement fluManagement = null;
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("patients.ser"))) {
            fluManagement = (FluManagement) ois.readObject();
            System.out.println("Patients loaded successfully.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading patients: " + e.getMessage());
        }
        return fluManagement != null ? fluManagement : new FluManagement();
    }

    public void savePatients() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("patients.ser"))) {
            oos.writeObject(this);
            System.out.println("Patients saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving patients: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        FluManagement fluManagement = FluManagement.loadPatients();
        Scanner scanner = new Scanner(System.in);

        int userInput = 0;
        while (userInput != 6) {
            createMenu("Flu Management", "1. Add Patient", "2. Remove Patient", "3. Analysis", "4. Export", "5. Do Treatment", "6. Exit");
            userInput = input(1, 7, scanner);

            switch (userInput) {
                case 1:
                    addPatient(fluManagement, scanner);
                    break;
                case 2:
                    removePatient(fluManagement, scanner);
                    break;
                case 3:
                    analysisMenu(fluManagement, scanner);
                    break;
                case 4:
                    exportPatients(fluManagement);
                    break;
                case 5:
                    doTreatment(fluManagement, scanner);
                    break;
                case 6:
                    System.out.println("Exiting program...");
                    break;
                default:
                    System.out.println("Invalid input. Please enter a number between 1 and 6.");
                    break;
            }
        }
        scanner.close();
    }

    private static void addPatient(FluManagement fluManagement, Scanner scanner) {
        System.out.println("Enter Patient Name:");
        String name = scanner.nextLine();

        System.out.println("Enter Patient Age:");
        int age = Integer.parseInt(scanner.nextLine());

        System.out.println("Enter Blood Group:");
        String bloodGroup = scanner.nextLine();

        System.out.println("Enter Location:");
        String location = scanner.nextLine().toLowerCase();
        fluManagement.locations.add(location);

        System.out.println("Enter Number Of Symptoms:");
        int symptomCount = Integer.parseInt(scanner.nextLine());
        String[] symptoms = new String[symptomCount];

        for (int i = 0; i < symptomCount; i++) {
            System.out.println("Enter Symptom " + (i + 1) + ":");
            symptoms[i] = scanner.nextLine();
        }

        Patient patient = new Patient(name, age, bloodGroup, location, symptoms);
        fluManagement.patients.add(patient);

        System.out.println("Patient Created Successfully\n" + patient);
    }

    private static void removePatient(FluManagement fluManagement, Scanner scanner) {
        System.out.println("Patients to Remove:");
        for (Patient patient : fluManagement.patients) {
            System.out.println("ID: " + patient.getId() + ", Name: " + patient.name);
        }

        System.out.println("Enter Patient ID to Remove:");
        int id = Integer.parseInt(scanner.nextLine());

        Patient patientToRemove = null;
        for (Patient patient : fluManagement.patients) {
            if (patient.getId() == id) {
                patientToRemove = patient;
                break;
            }
        }

        if (patientToRemove != null) {
            fluManagement.patients.remove(patientToRemove);
            System.out.println("Patient removed successfully.");
        } else {
            System.out.println("Patient with ID " + id + " not found.");
        }
    }

    private static void analysisMenu(FluManagement fluManagement, Scanner scanner) {
        int userInput = 0;

        while (userInput != 6) {
            createMenu("Analysis", "1. Group By Symptom", "2. Group By Age", "3. Group By Location", "4. Treatment", "5. Overview", "6. Back");
            userInput = input(1, 6, scanner);

            switch (userInput) {
                case 1:
                    groupBySymptom(fluManagement);
                    break;
                case 2:
                    groupByAge(fluManagement);
                    break;
                case 3:
                    groupByLocation(fluManagement);
                    break;
                case 4:
                    groupByTreatment(fluManagement);
                    break;
                case 5:
                    overview(fluManagement);
                    break;
                case 6:
                    return;
            }
        }
    }

    private static void groupBySymptom(FluManagement fluManagement) {
        int symptomFeverCount = 0, symptomColdCount = 0, symptomCoughCount = 0;
        int FeverColdCount = 0, FeverCoughCount = 0, ColdCoughCount = 0, FeverColdCoughCount = 0;

        for (Patient patient : fluManagement.patients) {
            if (patient.hasSymptom("Fever")) symptomFeverCount++;
            if (patient.hasSymptom("Cold")) symptomColdCount++;
            if (patient.hasSymptom("Cough")) symptomCoughCount++;
            if (patient.hasSymptom("Fever") && patient.hasSymptom("Cold")) FeverColdCount++;
            if (patient.hasSymptom("Fever") && patient.hasSymptom("Cough")) FeverCoughCount++;
            if (patient.hasSymptom("Cold") && patient.hasSymptom("Cough")) ColdCoughCount++;
            if (patient.hasSymptom("Fever") && patient.hasSymptom("Cold") && patient.hasSymptom("Cough")) FeverColdCoughCount++;
        }

        System.out.println("symptomFever : " + symptomFeverCount);
        System.out.println("symptomCold : " + symptomColdCount);
        System.out.println("symptomCough3 : " + symptomCoughCount);
        System.out.println("Fever Cold    : " + FeverColdCount);
        System.out.println("Fever Cough    : " + FeverCoughCount);
        System.out.println("Cold Cough    : " + ColdCoughCount);
        System.out.println("Fever Cold Cough : " + FeverColdCoughCount);
        System.out.println("Total Patient: " + fluManagement.patients.size());
    }

    private static void groupByAge(FluManagement fluManagement) {
        int[] array = new int[6];
        try {
            array = Analysis.groupByAge(fluManagement.patients, 10);
        } catch (InvalidAgeException e) {
            e.printStackTrace();
        }

        for (int i = 0; i < array.length; i++) {
            System.out.println("Age [" + i * 10 + " - " + ((i + 1) * 10) + "] : " + array[i]);
        }
    }

    private static void groupByLocation(FluManagement fluManagement) {
        for (String location : fluManagement.locations) {
            System.out.println(location + ": " + Analysis.getByLocation(fluManagement.patients, location).size());
        }
    }

    private static void groupByTreatment(FluManagement fluManagement) {
        int fevert1Count = 0, coldt2Count = 0, cought3Count = 0;
        int fevert1coldt2Count = 0, fevert1cought3Count = 0, coldt2cought3Count = 0, fevert1coldt2cought3Count = 0;

        for (Patient patient : fluManagement.patients) {
            if (patient.hadTreatment("TreatmentFever")) fevert1Count++;
            if (patient.hadTreatment("TreatmentCold")) coldt2Count++;
            if (patient.hadTreatment("TreatmentCough")) cought3Count++;
            if (patient.hadTreatment("TreatmentFever") && patient.hadTreatment("TreatmentCold")) fevert1coldt2Count++;
            if (patient.hadTreatment("TreatmentFever") && patient.hadTreatment("TreatmentCough")) fevert1cought3Count++;
            if (patient.hadTreatment("TreatmentCold") && patient.hadTreatment("TreatmentCough")) coldt2cought3Count++;
            if (patient.hadTreatment("TreatmentFever") && patient.hadTreatment("TreatmentCold") && patient.hadTreatment("TreatmentCough")) fevert1coldt2cought3Count++;
        }

        System.out.println("TreatmentFever : " + fevert1Count);
        System.out.println("TreatmentCold : " + coldt2Count);
        System.out.println("TreatmentCough : " + cought3Count);
        System.out.println("TreatmentFever TreatmentCold    : " + fevert1coldt2Count);
        System.out.println("TreatmentFever TreatmentCough    : " + fevert1cought3Count);
        System.out.println("TreatmentCold TreatmentCough    : " + coldt2cought3Count);
        System.out.println("TreatmentFever TreatmentCold TreatmentCough : " + fevert1coldt2cought3Count);
        System.out.println("Total Patient: " + fluManagement.patients.size());
    }

    private static void overview(FluManagement fluManagement) {
    System.out.println("Flu Cured Patients:");
    printPatients(Analysis.getOverview(fluManagement.patients, 1));

    System.out.println("Flu Non-Treated Patients:");
    printPatients(Analysis.getOverview(fluManagement.patients, 4));

    System.out.println("Flu Treatment Patients:");
    printPatients(Analysis.getOverview(fluManagement.patients, 3));

    System.out.println("Deceased Patients:");
    printPatients(Analysis.getOverview(fluManagement.patients, 2));
}


    private static void printPatients(LinkedList<Patient> patients) {
        if (patients.isEmpty()) {
            System.out.println("No patients found.");
        } else {
            for (Patient patient : patients) {
                System.out.println(patient.toFormattedString());
            }
        }
    }

    private static void exportPatients(FluManagement fluManagement) {
        try {
            FileOutputStream fileOut = new FileOutputStream("patients.ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(fluManagement);
            out.close();
            fileOut.close();
            System.out.println("Patients exported to patients.ser");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
 private static void doTreatment(FluManagement fluManagement, Scanner scanner) {
    System.out.println("Enter Patient ID:");
    int id = Integer.parseInt(scanner.nextLine());

    Patient patient = null;
    for (Patient p : fluManagement.patients) {
        if (p.getId() == id) {
            patient = p;
            break;
        }
    }

    if (patient != null) {
        if (patient.isCured) {
            System.out.println("Patient is already cured.");
            return;
        }

        if (!patient.isAlive) {
            System.out.println("Patient is deceased.");
            return;
        }

        System.out.println("Available Treatments: ");
        System.out.println("TreatmentFever - Treatment Fever");
        System.out.println("TreatmentCold - Treatment Cold");
        System.out.println("TreatmentCough - Treatment Cough");
        System.out.println("Enter Treatment:");
        String treatment = scanner.nextLine();

        if (treatment.equals("TreatmentFever") || treatment.equals("TreatmentCold") || treatment.equals("TreatmentCough")) {
            patient.addTreatment(treatment, fluManagement.patients); // Pass list of all patients
            System.out.println("Treatment applied successfully.");

            // Check if the patient is cured after treatment
            if (patient.isCured) {
                System.out.println("Patient is cured!");
                fluManagement.patients.remove(patient); // Remove from patient list
                Analysis.getOverview(fluManagement.patients, 1).add(patient); // Add to cured list using Analysis class method
            }
        } else {
            System.out.println("Invalid treatment.");
        }

    } else {
        System.out.println("Patient not found.");
    }
    
    }

    private static void createMenu(String title, String... options) {
        System.out.println(title );
        for (String option : options) {
            System.out.println(option);
        }
    }

    private static int input(int min, int max, Scanner scanner) {
        int num;
        while (true) {
            System.out.print("Enter your choice: ");
            try {
                num = Integer.parseInt(scanner.nextLine());
                if (num >= min && num <= max) {
                    break;
                } else {
                    System.out.println("Please enter a number between " + min + " and " + max + ".");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        return num;
    }
}
