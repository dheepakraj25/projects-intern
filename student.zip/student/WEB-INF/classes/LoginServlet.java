import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        
        if (username != null && password != null && username.equals("dheepak") && password.equals("12345")) {
            
            HttpSession session = request.getSession();
            
            session.setAttribute("username", username); 
           
            response.sendRedirect("studentmark.html");
        } else {
            
            response.sendRedirect("login.html");
        }
    }
}

