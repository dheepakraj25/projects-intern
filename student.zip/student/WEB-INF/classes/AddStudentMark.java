import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class AddStudentMark extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        Connection conn = null;
        PreparedStatement pstmt = null;

        String seatNo = request.getParameter("seatNo");
        String name = request.getParameter("name");
        String className = request.getParameter("class");
        int totalMarks = Integer.parseInt(request.getParameter("totalMarks"));
        double percentage = (totalMarks / 500.0) * 100;

        try {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/servlet","postgres","Dheepakr@j25082001");
            String query = "INSERT INTO students (SeatNo, Name, Class, TotalMarks, Percentage) VALUES (?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, seatNo);
            pstmt.setString(2, name);
            pstmt.setString(3, className);
            pstmt.setInt(4, totalMarks);
            pstmt.setDouble(5, percentage);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                out.println("<html><body>");
                out.println("<h2>Student Details Added Successfully</h2>");
                out.println("<p>Seat No: " + seatNo + "</p>");
                out.println("<p>Name: " + name + "</p>");
                out.println("<p>Class: " + className + "</p>");
                out.println("<p>Total Marks: " + totalMarks + "</p>");
                out.println("<p>Percentage Obtained: " + percentage + "%</p>");
                out.println("</body></html>");
                System.out.println("Student details added successfully");
            } else {
                out.println("<html><body>");
                out.println("<h2>Error: Failed to add student details</h2>");
                out.println("</body></html>");
                System.out.println("Error: Failed to add student details");
            }
        } catch (ClassNotFoundException e) {
            out.println("Error: PostgreSQL JDBC Driver not found!");
            out.println(e.getStackTrace());
        } catch (SQLException e) {
            out.println("Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                out.println("Error while closing resources: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}
