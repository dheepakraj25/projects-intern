#include "File.h"

#include <iostream>
#include <filesystem>
#include <ctime>
#include <string>

using namespace std;
namespace fs = filesystem;

template <typename TP>
time_t to_time_t(TP tp){
    using namespace std::chrono;
    auto sctp = time_point_cast<system_clock::duration>(tp - TP::clock::now() + system_clock::now());
    return system_clock::to_time_t(sctp);
}

JNIEXPORT jstring JNICALL Java_File_getFileName(JNIEnv *env, jobject thisObj, jstring jabsFilePath){
    const char *rawAbsFilePath = env->GetStringUTFChars(jabsFilePath, nullptr);
    string absFilePath(rawAbsFilePath);
    env->ReleaseStringUTFChars(jabsFilePath, rawAbsFilePath);

    fs::path path(absFilePath);
    if( fs::exists(absFilePath) ) {
        return env->NewStringUTF(path.filename().stem().string().c_str());
    }

    return nullptr;
}

JNIEXPORT jstring JNICALL Java_File_getExtension(JNIEnv *env, jobject thisObj, jstring jabsFilePath){
    const char *rawAbsFilePath = env->GetStringUTFChars(jabsFilePath, nullptr);
    string absFilePath(rawAbsFilePath);
    env->ReleaseStringUTFChars(jabsFilePath, rawAbsFilePath);

    fs::path path(absFilePath);
    if( fs::exists(absFilePath) && path.has_extension() ) {
        return env->NewStringUTF(path.extension().string().c_str());
    }

    return nullptr;
}

JNIEXPORT jint JNICALL Java_File_getSize(JNIEnv *env, jobject thisObj, jstring jabsFilePath){
    const char *rawAbsFilePath = env->GetStringUTFChars(jabsFilePath, nullptr);
    string absFilePath(rawAbsFilePath);
    env->ReleaseStringUTFChars(jabsFilePath, rawAbsFilePath);

    fs::path path(absFilePath);
    if( fs::exists(absFilePath) ) {
        return static_cast<jint>(fs::file_size(absFilePath));
    }

    return 0;
}

JNIEXPORT jboolean JNICALL Java_File_isFileSymLink(JNIEnv *env, jobject thisObj, jstring jabsFilePath){
    const char *rawAbsFilePath = env->GetStringUTFChars(jabsFilePath, nullptr);
    string absFilePath(rawAbsFilePath);
    env->ReleaseStringUTFChars(jabsFilePath, rawAbsFilePath);

    fs::path path(absFilePath);
    if( fs::exists(absFilePath) && fs::is_symlink(path) ) {
        return JNI_TRUE;
    }

    return JNI_FALSE;
}

JNIEXPORT jstring JNICALL Java_File_getLastModified(JNIEnv *env, jobject thisObj, jstring jabsFilePath){
    const char *rawAbsFilePath = env->GetStringUTFChars(jabsFilePath, nullptr);
    string absFilePath(rawAbsFilePath);
    env->ReleaseStringUTFChars(jabsFilePath, rawAbsFilePath);

    fs::path path(absFilePath);
    if( fs::exists(absFilePath) ) {
	time_t lastWriteTimeT = to_time_t( fs::last_write_time(path) );
        string lastModified= std::ctime(&lastWriteTimeT);
        return env->NewStringUTF(lastModified.c_str());
    }
	return nullptr;
}

