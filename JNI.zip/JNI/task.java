import java.util.ArrayList;
import java.util.Scanner;
import java.awt.Desktop;
import java.io.IOException;

class File {
    public String absoluteFilePath;
    public String relativeFilePath;

    public boolean isDirectory;
    public String folderPath;

    public String fileName;
    private native String getFileName(String filePath);

    public String extension;
    private native String getExtension(String filePath);

    public int fileSize;
    private native int getSize(String filePath);

    public boolean isSymLink;
    private native boolean isFileSymLink(String filePath);

    public String lastModified;
    private native String getLastModified(String filePath);

    public String toString(int index){
        return String.format("[%02d] %15s    %6s    %05.1fkb    %35s",index,fileName.length()>15?fileName.substring(0,12)+"...":fileName,extension.length()>6?extension.substring(0,4)+"..":extension, (fileSize/1000.0f)>999?(fileSize/100000.0f):(fileSize/1000.0f), relativeFilePath.length()>35?relativeFilePath.substring(0,32)+"...":relativeFilePath);
    }

    File(String absoluteFilePath, String relativeFilePath){
        this.absoluteFilePath = absoluteFilePath;
        this.relativeFilePath = relativeFilePath;

        this.isDirectory = FileManager.isDirectory(absoluteFilePath);

        this.fileName = getFileName(absoluteFilePath);
        this.extension = this.isDirectory?"folder":getExtension(absoluteFilePath);
	this.extension = this.extension==null?"":this.extension;
	if(this.isDirectory) this.folderPath = absoluteFilePath;
	else this.folderPath = absoluteFilePath.substring(0, absoluteFilePath.length() - (this.fileName+this.extension).length() );

        this.fileSize = this.isDirectory?1:getSize(absoluteFilePath);
	this.isSymLink = this.isFileSymLink(absoluteFilePath);
	this.lastModified = this.getLastModified(absoluteFilePath);
	this.lastModified = this.lastModified == null?"":this.lastModified;
    }
}

class FileManager{
    public static native boolean isDirectory(String directory);
    private static native String[] searchFile( String fileName, String startDirectory );

    public static ArrayList<File> search( String fileName, String startDirectory){
        ArrayList<File> result = new ArrayList<>();

        for(String filePath: searchFile(fileName, startDirectory)){
            result.add(new File(filePath,filePath.replace(startDirectory, ".")));
        }

        return result;
    }
}

class Menu{
    public boolean isInit;
    public boolean isSearching;
    public String directory;
    public String fileName;
    public ArrayList<File> files;

    public int input(int startRange, int endRange, Scanner scanner){
        int input = 0;
        while( !(input >= startRange && input <= endRange)){
	    try{
            	input = scanner.nextInt();
	    }catch(Exception exception){scanner.nextLine();input = 0;}
        }

        scanner.nextLine(); //remove the \n scanner bufffer;
        return input;
    }

    public void clearMenu(){
        System.out.print("\033[H\033[2J"); 
        System.out.flush();
    }
    public void renderFileMenu(File file){
    	System.out.println(  "┌"+("─".repeat(78))+"┐\n│   Dir: "+this.directory+(" ".repeat(70-this.directory.length()))+"│\n├"+("─".repeat(78))+"┤" );
	System.out.println(  "  File Name:      "+file.fileName+
			     "\n  File Extension: "+file.extension+
			     "\n  File FullName:  "+(!file.isDirectory?file.fileName+file.extension:file.fileName)+"\n"+
			     "\n  File Size:      "+(!file.isDirectory?(file.fileSize/1000.0f)+"kb":"Unknown")+
			     "\n  File Path:      "+file.absoluteFilePath+
			     "\n  Folder Path:    "+file.folderPath+
			     "\n  File Modified:  "+file.lastModified+
			     "\n  Is File:        "+(!file.isDirectory?"Yes":"No")+
			     "\n  Is Directory:   "+(file.isDirectory?"Yes":"No")+
			     "\n  Is Symlink:     "+(file.isSymLink?"Yes":"No") );
	System.out.println(  "└"+("─".repeat(78))+"┘");
    }
    public void renderMenu(){
        System.out.println(  "┌"+("─".repeat(78))+"┐\n│   Dir: "+this.directory+(" ".repeat(70-this.directory.length()))+"│\n├"+("─".repeat(78))+"┤" );
        if(!this.isInit){
        System.out.println("│"+(" ".repeat(78))+"│\n│                        - Select Any Option Below -                           │\n│"+(" ".repeat(78))+"│\n└"+("─".repeat(78))+"┘");
        }else if(!this.isSearching){
            if(files == null || files.size() == 0){
        System.out.println("│"+(" ".repeat(78))+"│\n│                              0 Search Result!                                │\n│"+(" ".repeat(78))+"│\n├"+("─".repeat(78))+"┤\n│   Searched For: "+this.fileName+(" ".repeat(61-this.fileName.length()))+"│\n└"+("─".repeat(78))+"┘");
            }else{
	    int index = 5;
            for(File file: files){
                System.out.println(file.toString(index));
		index++;
            }
            System.out.println("├"+("─".repeat(78))+"┤\n│  Searched For: "+this.fileName+(" ".repeat(62-this.fileName.length()))+"│\n└"+("─".repeat(78))+"┘");
            }
        }else{
        System.out.println("│"+(" ".repeat(78))+"│\n│                             Searching For Files                              │\n│"+(" ".repeat(78))+"│\n├"+("─".repeat(78))+"┤\n│   Searching For: "+this.fileName+(" ".repeat(60-this.fileName.length()))+"│\n└"+("─".repeat(78))+"┘");
        }
    }

    public void drawMenu(){
        clearMenu();
        renderMenu();
    }

    Menu(){
        this.isSearching = false;
        this.directory = "";
        this.fileName = "";
        this.files = new ArrayList<>();
        this.isInit = false;
    }
}

public class task{

    static{ 
        System.loadLibrary("FileManager"); 
        System.loadLibrary("File");
    }

    public static void main(String[] args) throws IOException{
        Menu menu = new Menu();
        Scanner scanner = new Scanner(System.in);
        menu.directory = "C:\\work\\tasks\\Day 09\\setB";

        int userInput = 0;
        while(userInput != 4){

            menu.drawMenu();
            System.out.println("[1] Search File  |  [2] Change Directory  |  [3] Reset  |  [4] Exit");
            userInput = menu.input(1, 4+menu.files.size(), scanner);

            if(userInput == 1){
                menu.drawMenu();
                System.out.print("Search For: ");
                menu.fileName = scanner.nextLine();
                if(!menu.isInit) menu.isInit = true;

                menu.isSearching = true;
                menu.drawMenu();
		System.out.println("It May Take A While! ...");

                if(FileManager.isDirectory(menu.directory)){
                    menu.files = FileManager.search(menu.fileName.toLowerCase(),menu.directory);
                    menu.drawMenu();
                }else{
                    System.out.println("Invalid Directory Is SET! Change And TryAgain!");
                    scanner.nextLine();
                }

                menu.isSearching = false;
            }else if(userInput == 2){
                String tmpDir = "invalid";
                while(!FileManager.isDirectory(tmpDir)){
                    menu.drawMenu();
                    System.out.print("Set Directory:");
                    tmpDir = scanner.nextLine();
                }
                menu.directory = tmpDir;
            }else if(userInput == 3){
		menu = new Menu();
		menu.directory = "C:\\work\\tasks\\Day 09\\setB";
	    }else if(userInput != 4){
		while(true){
	    	    menu.clearMenu();
		    menu.renderFileMenu(menu.files.get(userInput-5));
		
		    if(menu.files.get(userInput-5).isDirectory) System.out.println("[1] Open Folder  |  [3] Go Back");
		    else System.out.println("[1] Open File  |  [2] Open Folder  |  [3] Go Back");
		    int tmpUserInput = menu.input(1, 3, scanner);

		    try{
    		        if(tmpUserInput == 1) Desktop.getDesktop().open(new java.io.File(menu.files.get(userInput-5).absoluteFilePath));
		        else if(tmpUserInput == 2) Desktop.getDesktop().open(new java.io.File(menu.files.get(userInput-5).folderPath));
		        else break;
		    }catch(Exception exception){
		    	System.out.println("Unable To Open The File/Folder! [Enter] To Continue..\n"+exception.getMessage());
			scanner.nextLine();
			break;
		    }
		}
	    }

        }
    }
}