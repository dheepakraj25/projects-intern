#include <iostream>
#include <vector>
#include <string>
#include <windows.h>
#include <jni.h>
#include <sys/stat.h>

using namespace std;

// Function prototypes
void searchFileRecursive(const char *fileName, const char *directory, std::vector<std::string> &results);
std::string getFileDetailsString(const char *filePath

// JNI function implementations
extern "C" {

JNIEXPORT jboolean JNICALL Java_FileManager_isDirectory(JNIEnv *env, jclass cls, jstring directory) {
    const char *dir = env->GetStringUTFChars(directory, 0);

    DWORD attr = GetFileAttributesA(dir);
    bool isDir = (attr != INVALID_FILE_ATTRIBUTES && (attr & FILE_ATTRIBUTE_DIRECTORY));

    env->ReleaseStringUTFChars(directory, dir);

    return isDir ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jobjectArray JNICALL Java_FileManager_searchFile(JNIEnv *env, jclass cls, jstring fileName, jstring startDirectory) {
    const char *file = env->GetStringUTFChars(fileName, 0);
    const char *startDir = env->GetStringUTFChars(startDirectory, 0);

    vector<string> results;
    searchFileRecursive(file, startDir, results);

    env->ReleaseStringUTFChars(fileName, file);
    env->ReleaseStringUTFChars(startDirectory, startDir);

    jclass stringClass = env->FindClass("java/lang/String");
    jobjectArray resultArray = env->NewObjectArray(results.size(), stringClass, NULL);

    for (int i = 0; i < results.size(); ++i) {
        env->SetObjectArrayElement(resultArray, i, env->NewStringUTF(results[i].c_str()));
    }

    return resultArray;
}

JNIEXPORT jstring JNICALL Java_FileManager_getFileDetails(JNIEnv *env, jclass cls, jstring filePath) {
    const char *file = env->GetStringUTFChars(filePath, 0);

    string details = getFileDetailsString(file);

    env->ReleaseStringUTFChars(filePath, file);

    return env->NewStringUTF(details.c_str());
}

} // extern "C"

// Function definitions
void searchFileRecursive(const char *fileName, const char *directory, vector<string> &results) {
    string searchPath = directory;
    searchPath += "\\*";

    WIN32_FIND_DATAA findData;
    HANDLE hFind = FindFirstFileA(searchPath.c_str(), &findData);

    if (hFind != INVALID_HANDLE_VALUE) {
        do {
            if (findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                if (strcmp(findData.cFileName, ".") != 0 && strcmp(findData.cFileName, "..") != 0) {
                    string subdir = directory;
                    subdir += "\\";
                    subdir += findData.cFileName;
                    searchFileRecursive(fileName, subdir.c_str(), results);
                }
            } else {
                if (strcmp(findData.cFileName, fileName) == 0) {
                    string filePath = directory;
                    filePath += "\\";
                    filePath += findData.cFileName;
                    results.push_back(filePath);
                }
            }
        } while (FindNextFileA(hFind, &findData) != 0);
        FindClose(hFind);
    }
}

string getFileDetailsString(const char *filePath) {
    struct stat fileStat;
    if (stat(filePath, &fileStat) != 0) {
        return "";
    }

    string details = "File Size: " + to_string(fileStat.st_size) + " bytes\n";
    details += "Last Modified: ";
    char buffer[80];
    struct tm *timeinfo;
    timeinfo = localtime(&fileStat.st_mtime);
    strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", timeinfo);
    details += string(buffer);
    details += "\n";

    return details;
}