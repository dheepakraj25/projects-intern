import java.sql.*;  

class Incubation
{  
    public static void main(String args[]){  
 	
	try{  
 
	     Class.forName("org.postgresql.Driver");  
 
		Connection con=DriverManager.getConnection("jdbc:postgresql://localhost:5432/employee","postgres","Dheepakr@j25082001");  
   
		Statement stmt=con.createStatement();  

		ResultSet rs=stmt.executeQuery("select * from incubation;");  
	
	    while(rs.next())  
 	
		System.out.println(rs.getInt("id")+"  "+rs.getString("emp_name"));  

		con.close();  
	
	   }catch(Exception e){ System.out.println(e);}  

       }  
}  