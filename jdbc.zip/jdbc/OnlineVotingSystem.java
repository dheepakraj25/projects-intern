import java.sql.*;
import java.util.Scanner;

public class OnlineVotingSystem {
    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;
    private Scanner scanner;

    public OnlineVotingSystem() {
        try {
	    Class.forName("org.postgresql.Driver"); 
            connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/employee", "postgres", "Dheepakr@j25082001");
            statement = connection.createStatement();
            scanner = new Scanner(System.in);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void voteForParty(int voterId, int partyId) {
        try {
            String checkQuery = "SELECT voter_id FROM parties WHERE voter_id = " + voterId;
            resultSet = statement.executeQuery(checkQuery);
            if (resultSet.next()) {
                System.out.println("You have already voted. Multiple votes are not allowed.");
                return;
            }
            String updateQuery = "UPDATE parties SET vote_count = vote_count + 1, voter_id = " + voterId + " WHERE party_id = " + partyId;
            statement.executeUpdate(updateQuery);
            System.out.println("Vote cast successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void displayParties() {
        try {
            String query = "SELECT * FROM parties";
            resultSet = statement.executeQuery(query);

            System.out.println("Available parties:");
            while (resultSet.next()) {
                int partyId = resultSet.getInt("party_id");
                String partyName = resultSet.getString("party_name");
                System.out.println(partyId + ". " + partyName);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void vote() {
        System.out.println("Enter your voter ID:");
        int voterId = scanner.nextInt();
        System.out.println("Enter the party ID to vote:");
        int partyId = scanner.nextInt();
        voteForParty(voterId, partyId);
    }
    public int countVotes() {
        int totalVotes = 0;
        try {
            String query = "SELECT SUM(vote_count) AS total_votes FROM parties";
            resultSet = statement.executeQuery(query);
            if (resultSet.next()) {
                totalVotes = resultSet.getInt("total_votes");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return totalVotes;
    }
    public void displayResults() {
        try {
            String query = "SELECT party_name, vote_count FROM parties ORDER BY vote_count DESC";
            resultSet = statement.executeQuery(query);
            
            String winner = "";
            String runnerUp = "";

            while (resultSet.next()) {
                String partyName = resultSet.getString("party_name");
                int voteCount = resultSet.getInt("vote_count");
                
                if (winner.isEmpty()) {
                    winner = partyName + " (" + voteCount + " votes)";
                } else if (runnerUp.isEmpty()) {
                    runnerUp = partyName + " (" + voteCount + " votes)";
                    break; 
                }
            }

            if (!winner.isEmpty()) {
                System.out.println("Winner: " + winner);
            } else {
                System.out.println("No votes cast yet.");
            }

            if (!runnerUp.isEmpty()) {
                System.out.println("Runner-up: " + runnerUp);
            }


            System.out.println("Total votes: " + countVotes());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void startVotingSystem() {
        boolean exit = false;
        while (!exit) {
            System.out.println("Menu:");
            System.out.println("1. Vote");
            System.out.println("2. Count Votes (Election Counsellor)");
            System.out.println("3. Show Results and Exit");
            System.out.println("Enter your choice:");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    displayParties();
                    vote();
                    break;
                case 2:
                    System.out.println("Counting votes...");
                    System.out.println("Total votes: " + countVotes());
                    break;
                case 3:
                    System.out.println("Displaying results...");
                    displayResults();
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    public static void main(String[] args) {
        OnlineVotingSystem votingSystem = new OnlineVotingSystem();
        votingSystem.startVotingSystem();
    }
}
