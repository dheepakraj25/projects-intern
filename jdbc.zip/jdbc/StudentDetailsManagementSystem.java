import java.sql.*;
import java.util.Scanner;

public class StudentDetailsManagementSystem {
    static final String JDBC_DRIVER = "org.postgresql.Driver";
    static final String DB_URL = "jdbc:postgresql://localhost:5432/employee";
    static final String USER =  "postgres";
    static final String PASS = "Dheepakr@j25082001";

    static Connection conn = null;
    static Statement stmt = null;
    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        try {
            Class.forName(JDBC_DRIVER);
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            stmt = conn.createStatement();

            createTable();
            boolean exit = false;
            while (!exit) {
                System.out.println("\nStudent Details Management System");
                System.out.println("1. Insert Student");
                System.out.println("2. Read Student");
                System.out.println("3. Update Student");
                System.out.println("4. Delete Student");
                System.out.println("5. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); 

                switch (choice) {
                    case 1:
                        insertStudent();
                        break;
                    case 2:
                        readStudent();
                        break;
                    case 3:
                        updateStudent();
                        break;
                    case 4:
                        deleteStudent();
                        break;
                    case 5:
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (SQLException se) {
            se.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (stmt != null) stmt.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
            try {
                if (conn != null) conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
            if (scanner != null) scanner.close();
        }
    }

    private static void createTable() throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS students (" +
                     "regno BIGINT PRIMARY KEY," +
                     "name VARCHAR(100)," +
                     "dob DATE," +
                     "address VARCHAR(255)," +
                     "email VARCHAR(100) UNIQUE," +
                     "cgpa FLOAT" +
                     ")";
        stmt.executeUpdate(sql);
    }

    private static void insertStudent() throws SQLException {
        System.out.println("Enter student details:");
        System.out.print("Reg No: ");
        long regno = scanner.nextLong();
        scanner.nextLine(); 

        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("Date of Birth (YYYY-MM-DD): ");
        String dob = scanner.nextLine();

        System.out.print("Address: ");
        String address = scanner.nextLine();

        System.out.print("Email: ");
        String email = scanner.nextLine();

        System.out.print("CGPA: ");
        float cgpa = scanner.nextFloat();
        scanner.nextLine(); 

        String sql = "INSERT INTO students (regno, name, dob, address, email, cgpa) " +
                     "VALUES (" + regno + ", '" + name + "', '" + dob + "', '" + address + "', '" + email + "', " + cgpa + ")";
        stmt.executeUpdate(sql);
        System.out.println("Student inserted successfully.");
    }

    private static void readStudent() throws SQLException {
        System.out.println("Enter student regno to read details:");
        int regno = scanner.nextInt();
        scanner.nextLine(); 

        String sql = "SELECT * FROM students WHERE regno = " + regno;
        ResultSet rs = stmt.executeQuery(sql);

        if (rs.next()) {
            System.out.println("Regno: " + rs.getInt("regno"));
            System.out.println("Name: " + rs.getString("name"));
            System.out.println("DOB: " + rs.getDate("dob"));
            System.out.println("Address: " + rs.getString("address"));
            System.out.println("Email: " + rs.getString("email"));
            System.out.println("CGPA: " + rs.getFloat("cgpa"));
        } else {
            System.out.println("Student not found.");
        }
    }

    private static void updateStudent() throws SQLException {
        System.out.println("Enter student regno to update details:");
        int regno = scanner.nextInt();
        scanner.nextLine(); 

        System.out.println("Enter updated student details:");
        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("Date of Birth (YYYY-MM-DD): ");
        String dob = scanner.nextLine();

        System.out.print("Address: ");
        String address = scanner.nextLine();

        System.out.print("Email: ");
        String email = scanner.nextLine();

        System.out.print("CGPA: ");
        float cgpa = scanner.nextFloat();
        scanner.nextLine(); 

        String sql = "UPDATE students SET name = '" + name + "', dob = '" + dob + "', address = '" + address + "', " +
                     "email = '" + email + "', cgpa = " + cgpa + " WHERE regno = " + regno;
        int rowsUpdated = stmt.executeUpdate(sql);
        if (rowsUpdated > 0) {
            System.out.println("Student details updated successfully.");
        } else {
            System.out.println("Student not found.");
        }
    }

    private static void deleteStudent() throws SQLException {
        System.out.println("Enter student regno to delete:");
        int regno = scanner.nextInt();
        scanner.nextLine(); 

        String sql = "DELETE FROM students WHERE regno = " + regno;
        int rowsDeleted = stmt.executeUpdate(sql);
        if (rowsDeleted > 0) {
            System.out.println("Student deleted successfully.");
        } else {
            System.out.println("Student not found.");
        }
    }
}
