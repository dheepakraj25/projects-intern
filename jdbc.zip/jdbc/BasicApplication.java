import java.sql.*;

public class BasicApplication {

    
    private static final String url = "jdbc:postgresql://localhost:5432/employee";
    private static final String user = "postgresql";
    private static final String password = "Dheepakr@j25082001";

    
    private static Connection connection;
    private static Statement statement;
    private static ResultSet resultSet;

    public static void main(String[] args) {
        try {
            
            connection = DriverManager.getConnection(url, user, password);
            statement = connection.createStatement();

            
            displayMenu();

           
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    private static void displayMenu() throws SQLException {
        boolean exit = false;
        while (!exit) {
            System.out.println("\nSelect operation:");
            System.out.println("1. Create");
            System.out.println("2. Read");
            System.out.println("3. Update");
            System.out.println("4. Delete");
            System.out.println("5. Exit");

            
            int choice = getUserChoice();

            switch (choice) {
                case 1:
                    createRecord();
                    break;
                case 2:
                    readRecord();
                    break;
                case 3:
                    updateRecord();
                    break;
                case 4:
                    deleteRecord();
                    break;
                case 5:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 5.");
            }
        }
    }

    
    private static int getUserChoice() {
        int choice = 0;
        try {
            System.out.print("Enter your choice: ");
            Scanner scanner = new Scanner(System.in);
            choice = scanner.nextInt();
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a number.");
        }
        return choice;
    }

    
    private static void createRecord() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter age: ");
        int age = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter address: ");
        String address = scanner.nextLine();
        String query = "INSERT INTO employee (name, age, address) VALUES (?, ?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, name);
        preparedStatement.setInt(2, age);
        preparedStatement.setString(3, address);
        preparedStatement.executeUpdate();
        System.out.println("Record created successfully.");
    }

   
    private static void readRecord() throws SQLException {
        String query = "SELECT * FROM employee";
        resultSet = statement.executeQuery(query);
        while (resultSet.next()) {
            System.out.println("ID: " + resultSet.getInt("id") + ", Name: " + resultSet.getString("name") +
                    ", Age: " + resultSet.getInt("age") + ", Address: " + resultSet.getString("address"));
        }
    }

   
    private static void updateRecord() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter ID of record to update: ");
        int id = scanner.nextInt();
        System.out.print("Enter new name: ");
        String newName = scanner.next();
        System.out.print("Enter new age: ");
        int newAge = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new address: ");
        String newAddress = scanner.nextLine();
        String query = "UPDATE employee SET name = ?, age = ?, address = ? WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, newName);
        preparedStatement.setInt(2, newAge);
        preparedStatement.setString(3, newAddress);
        preparedStatement.setInt(4, id);
        preparedStatement.executeUpdate();
        System.out.println("Record updated successfully.");
    }

   
    private static void deleteRecord() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter ID of record to delete: ");
        int id = scanner.nextInt();
        String query = "DELETE FROM employee WHERE id = ?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setInt(1, id);
        preparedStatement.executeUpdate();
        System.out.println("Record deleted successfully.");
    }
}
