import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

public class DeleteEmployeeServlet extends HttpServlet {

    private static final String URL = "jdbc:postgresql://localhost:5432/servlet";
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "Dheepakr@j25082001";

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));

        res.setContentType("text/html");
        try {
            Class.forName("org.postgresql.Driver");
            try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
                deleteEmployee(connection, id);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            res.getWriter().write("<h1>Error occurred: " + e.getMessage() + "</h1>");
        }

        res.getWriter().write("<h1>Delete successful</h1>");
    }

    public void deleteEmployee(Connection connection, int id) throws SQLException {
        String sql = "DELETE FROM employees WHERE emp_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        }
    }
}
