import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

public class AddEmployeeServlet extends HttpServlet {

    private static final String URL = "jdbc:postgresql://localhost:5432/servlet";
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "Dheepakr@j25082001";

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String name = req.getParameter("name");
        int id = Integer.parseInt(req.getParameter("id"));
        String phone = req.getParameter("phone");
        String email = req.getParameter("email");
        String role = req.getParameter("role");

        res.setContentType("text/html");
        try {
            Class.forName("org.postgresql.Driver");
            try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
                createTable(connection);
                insertEmployee(connection, name, id, phone, email, role);

                Employee employee = getEmployee(connection, id);
                if (employee != null) {
                    PrintWriter out = res.getWriter();
                    out.println("<h1>Employee Added Successfully</h1>");
                    out.println("<h2>Employee Details:</h2>");
                    out.println("<p>ID: " + employee.getId() + "</p>");
                    out.println("<p>Name: " + employee.getName() + "</p>");
                    out.println("<p>Email: " + employee.getEmail() + "</p>");
                    out.println("<p>Phone Number: " + employee.getPhoneNumber() + "</p>");
                    out.println("<p>Role: " + employee.getRole() + "</p>");
                } else {
                    res.getWriter().write("<h1>Employee not found after insertion</h1>");
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            res.getWriter().write("<h1>Error occurred: " + e.getMessage() + "</h1>");
        }
    }

    private void createTable(Connection connection) throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS employees (" +
                "emp_id SERIAL PRIMARY KEY, " +
                "emp_name VARCHAR(100), " +
                "emp_email VARCHAR(200), " +
                "emp_phone_number VARCHAR(15), " +
                "emp_role VARCHAR(30)" +
                ")";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.executeUpdate();
        }
    }

    public void insertEmployee(Connection connection, String name, int id, String phone, String email, String role) throws SQLException {
        String sql = "INSERT INTO employees (emp_id, emp_name, emp_email, emp_phone_number, emp_role) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, id);
            preparedStatement.setString(2, name);
            preparedStatement.setString(3, email);
            preparedStatement.setString(4, phone);
            preparedStatement.setString(5, role);
            preparedStatement.executeUpdate();
        }
    }

    public Employee getEmployee(Connection connection, int id) throws SQLException {
        String sql = "SELECT * FROM employees WHERE emp_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, id);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    Employee employee = new Employee();
                    employee.setId(resultSet.getInt("emp_id"));
                    employee.setName(resultSet.getString("emp_name"));
                    employee.setEmail(resultSet.getString("emp_email"));
                    employee.setPhoneNumber(resultSet.getString("emp_phone_number"));
                    employee.setRole(resultSet.getString("emp_role"));
                    return employee;
                }
            }
        }
        return null;
    }
}
