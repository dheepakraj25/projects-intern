import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

public class UpdateEmployeeServlet extends HttpServlet {

    private static final String URL = "jdbc:postgresql://localhost:5432/servlet";
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "Dheepakr@j25082001";

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        String name = req.getParameter("name");
        String phone = req.getParameter("phone");
        String email = req.getParameter("email");
        String role = req.getParameter("role");

        res.setContentType("text/html");
        try {
            Class.forName("org.postgresql.Driver");
            try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
                updateEmployee(connection, id, name, phone, email, role);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            res.getWriter().write("<h1>Error occurred: " + e.getMessage() + "</h1>");
        }

        res.getWriter().write("<h1>Update successful</h1>");
    }

    public void updateEmployee(Connection connection, int id, String name, String phone, String email, String role) throws SQLException {
        String sql = "UPDATE employees SET emp_name = ?, emp_email = ?, emp_phone_number = ?, emp_role = ? WHERE emp_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, phone);
            preparedStatement.setString(4, role);
            preparedStatement.setInt(5, id);
            preparedStatement.executeUpdate();
        }
    }
}
