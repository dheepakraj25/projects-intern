import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

public class GetEmployeeServlet extends HttpServlet {

    private static final String URL = "jdbc:postgresql://localhost:5432/servlet";
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "";

    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        res.setContentType("text/html");

        try {
            Class.forName("org.postgresql.Driver");
            try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
                Employee employee = getEmployee(connection, id);
                if (employee != null) {
                    PrintWriter out = res.getWriter();
                    out.println("<h1>Employee Details</h1>");
                    out.println("<p>ID: " + employee.getId() + "</p>");
                    out.println("<p>Name: " + employee.getName() + "</p>");
                    out.println("<p>Email: " + employee.getEmail() + "</p>");
                    out.println("<p>Phone Number: " + employee.getPhoneNumber() + "</p>");
                    out.println("<p>Role: " + employee.getRole() + "</p>");
                } else {
                    res.getWriter().write("<h1>Employee not found</h1>");
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            res.getWriter().write("<h1>Error occurred: " + e.getMessage() + "</h1>");
        }
    }

    public Employee getEmployee(Connection connection, int id) throws SQLException {
        String sql = "SELECT * FROM employees WHERE emp_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, id);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    Employee employee = new Employee();
                    employee.setId(resultSet.getInt("emp_id"));
                    employee.setName(resultSet.getString("emp_name"));
                    employee.setEmail(resultSet.getString("emp_email"));
                    employee.setPhoneNumber(resultSet.getString("emp_phone_number"));
                    employee.setRole(resultSet.getString("emp_role"));
                    return employee;
                }
            }
        }
        return null;
    }
}
