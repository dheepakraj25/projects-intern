import java.io.*;
import jakarta .servlet.*;
import jakarta.servlet.http.*;

public class DisplayProgram extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        response.setContentType("text/html");
 
        PrintWriter out = response.getWriter();

        out.println("<h1>PROGRAMMING</h1>");
       
    }
}
