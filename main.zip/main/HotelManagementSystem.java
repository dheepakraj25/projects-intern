import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.io.Serializable;

class Room implements Serializable {
    private String roomNumber;
    private String type;
    private double pricePerStaying;
    private boolean booked;
    private boolean clean;

    public Room(String roomNumber, String type, double pricePerStaying) {
        this.roomNumber = roomNumber;
        this.type = type;
        this.pricePerStaying = pricePerStaying;
        this.booked = false;
        this.clean = true; 
    }

   
    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPricePerStaying() {
        return pricePerStaying;
    }

    public void setPricePerStaying(double pricePerStaying) {
        this.pricePerStaying = pricePerStaying;
    }

    public boolean isBooked() {
        return booked;
    }

    public void setBooked(boolean booked) {
        this.booked = booked;
    }

    public boolean isClean() {
        return clean;
    }

    public void setClean(boolean clean) {
        this.clean = clean;
    }
}

 class Customer implements Serializable {
    private String id;
    private String name;
    private String mobileNumber;
    private String idProof;
    private String idProofNumber; 
    private Map<String, Integer> bookedRooms;

    public Customer(String id, String name, String mobileNumber, String idProof, String idProofNumber) {
        this.id = id;
        this.name = name;
        this.mobileNumber = mobileNumber;
        this.idProof = idProof;
        this.idProofNumber = idProofNumber;
        this.bookedRooms = new HashMap<>();
    }

    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getIdProof() {
        return idProof;
    }

    public void setIdProof(String idProof) {
        this.idProof = idProof;
    }

    public Map<String, Integer> getBookedRooms() {
        return bookedRooms;
    }

    public void setBookedRooms(Map<String, Integer> bookedRooms) {
        this.bookedRooms = bookedRooms;
    }

    public String getIdProofNumber() {
        return idProofNumber;
    }

    public void setIdProofNumber(String idProofNumber) {
        this.idProofNumber = idProofNumber;
    }
}
class Receptionist implements Serializable {
    private String id;
    private String name;
    private String idProof;

    public Receptionist(String id, String name, String idProof) {
        this.id = id;
        this.name = name;
        this.idProof = idProof;
    }

    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIdProof() {
        return idProof;
    }

    public void setIdProof(String idProof) {
        this.idProof = idProof;
    }
}

class Bill implements Serializable {
    private String customerId;
    private String roomNumber;
    private double totalCost;
    private String paymentType;
    private String receptionistId;

    public Bill(String customerId, String roomNumber, double totalCost, String paymentType, String receptionistId) {
        this.customerId = customerId;
        this.roomNumber = roomNumber;
        this.totalCost = totalCost;
        this.paymentType = paymentType;
        this.receptionistId = receptionistId;
    }

   
    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getReceptionistId() {
        return receptionistId;
    }

    public void setReceptionistId(String receptionistId) {
        this.receptionistId = receptionistId;
    }
}

public class HotelManagementSystem {
  private static ArrayList<Room> rooms = new ArrayList<>();
  private static ArrayList<Customer> customers = new ArrayList<>();
  private static ArrayList<Receptionist> receptionists = new ArrayList<>();

    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        loadDataFromFiles();
        boolean exit = false;
        while (!exit) {
            displayMenu();
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    manageRooms();
                    break;
                case 2:
                    manageCustomers();
                    break;
                case 3:
                    manageReceptionists();
                    break;
                case 4:
                    bookRoom();
                    break;
                case 5:
                    payBill();
                    break;
                case 6:
                    markRoomForCleaning();
                    break;
                case 7:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please choose again.");
            }
        }
        saveDataToFiles();
    }

    private static void displayMenu() {
        System.out.println("Choose an option:");
        System.out.println("1. Manage Rooms");
        System.out.println("2. Manage Customers");
        System.out.println("3. Manage Receptionists");
        System.out.println("4. Book a Room");
        System.out.println("5. Pay Bill");
        System.out.println("6. Mark Room for Cleaning");
        System.out.println("7. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void manageRooms() {
        System.out.println("Choose an option:");
        System.out.println("1. Add Room");
        System.out.println("2. View All Rooms");
        System.out.println("3. Update Room");
        System.out.println("4. Delete Room");
        System.out.println("5. Back to Main Menu");
        System.out.print("Enter your choice: ");

        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                addRoom();
                break;
            case 2:
                viewAllRooms();
                break;
            case 3:
                updateRoom();
                break;
            case 4:
                deleteRoom();
                break;
            case 5:
                break;
            default:
                System.out.println("Invalid choice. Please choose again.");
        }
    }

    private static void addRoom() {
        System.out.println("Enter room number:");
        String roomNumber = scanner.next();

        System.out.println("Enter room type:");
        String type = scanner.next();

        System.out.println("Enter price per staying:");
        double pricePerStaying = scanner.nextDouble();

        Room room = new Room(roomNumber, type, pricePerStaying);
        rooms.add(room);
        System.out.println("Room added successfully.");
    }

    private static void viewAllRooms() {
        if (rooms.isEmpty()) {
            System.out.println("No rooms available.");
        } else {
            System.out.println("All Rooms:");
            for (Room room : rooms) {
                System.out.println("Room Number: " + room.getRoomNumber());
                System.out.println("Type: " + room.getType());
                System.out.println("Price per Staying: " + room.getPricePerStaying());
                System.out.println("---------------------------");
            }
        }
    }

    private static void updateRoom() {
        System.out.println("Enter room number to update:");
        String roomNumber = scanner.next();

        Room roomToUpdate = findRoomByNumber(roomNumber);
        if (roomToUpdate == null) {
            System.out.println("Room not found.");
            return;
        }

        System.out.println("Choose what to update:");
        System.out.println("1. Room Number");
        System.out.println("2. Room Type");
        System.out.println("3. Price Per Staying");
        System.out.print("Enter your choice: ");

        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                System.out.println("Enter new room number:");
                String newRoomNumber = scanner.next();
                roomToUpdate.setRoomNumber(newRoomNumber);
                System.out.println("Room number updated successfully.");
                break;
            case 2:
                System.out.println("Enter new room type:");
                String newType = scanner.next();
                roomToUpdate.setType(newType);
                System.out.println("Room type updated successfully.");
                break;
            case 3:
                System.out.println("Enter new price per staying:");
                double newPrice = scanner.nextDouble();
                roomToUpdate.setPricePerStaying(newPrice);
                System.out.println("Price per staying updated successfully.");
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private static void deleteRoom() {
        System.out.println("Enter room number to delete:");
        String roomNumber = scanner.next();

        Room roomToDelete = findRoomByNumber(roomNumber);
        if (roomToDelete == null) {
            System.out.println("Room not found.");
            return;
        }

        rooms.remove(roomToDelete);
        System.out.println("Room deleted successfully.");
    }

    private static Room findRoomByNumber(String roomNumber) {
        for (Room room : rooms) {
            if (room.getRoomNumber().equals(roomNumber)) {
                return room;
            }
        }
        return null; 
    }

    private static void manageCustomers() {
        System.out.println("Choose an option:");
        System.out.println("1. Add Customer");
        System.out.println("2. View All Customers");
        System.out.println("3. Update Customer");
        System.out.println("4. Delete Customer");
        System.out.println("5. Back to Main Menu");
        System.out.print("Enter your choice: ");

        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                addCustomer();
                break;
            case 2:
                viewAllCustomers();
                break;
            case 3:
                updateCustomer();
                break;
            case 4:
                deleteCustomer();
                break;
            case 5:
                break;
            default:
                System.out.println("Invalid choice. Please choose again.");
        }
    }

   private static void addCustomer() {
    System.out.println("Enter customer ID:");
    String id = scanner.next();

    System.out.println("Enter customer name:");
    String name = scanner.next();

    Pattern pattern = Pattern.compile("\\d{10}");
    Matcher matcher;
    String phoneNumber;
    do {
        System.out.println("Enter customer mobile number:");
        phoneNumber = scanner.next();
        matcher = pattern.matcher(phoneNumber);
        if (!matcher.matches()) {
            System.out.println("Invalid phone number format. Please enter a 10-digit phone number.");
        }
    } while (!matcher.matches());

    System.out.println("Enter customer ID proof:");
    String idProof = scanner.next();

    System.out.println("Enter customer ID proof number:");
    String idProofNumber = scanner.next();

    Customer customer = new Customer(id, name, phoneNumber, idProof, idProofNumber); 
    customers.add(customer);
    System.out.println("Customer added successfully.");
}


   private static void viewAllCustomers() {
    if (customers.isEmpty()) {
        System.out.println("No customers available.");
    } else {
        System.out.println("All Customers:");
        for (Customer customer : customers) {
            System.out.println("ID: " + customer.getId());
            System.out.println("Name: " + customer.getName());
            System.out.println("Mobile Number: " + customer.getMobileNumber());
            System.out.println("ID Proof: " + customer.getIdProof());
            System.out.println("ID Proof Number: " + customer.getIdProofNumber());
            System.out.println("---------------------------");
        }
    }
}


    private static void updateCustomer() {
        System.out.println("Enter customer ID to update:");
        String customerId = scanner.next();

        Customer customerToUpdate = findCustomerById(customerId);
        if (customerToUpdate == null) {
            System.out.println("Customer not found.");
            return;
        }

        System.out.println("Choose what to update:");
        System.out.println("1. Customer Name");
        System.out.println("2. Customer Mobile Number");
        System.out.println("3. Customer ID Proof");
        System.out.print("Enter your choice: ");

        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                System.out.println("Enter new customer name:");
                String newName = scanner.next();
                customerToUpdate.setName(newName);
                System.out.println("Customer name updated successfully.");
                break;
            case 2:
                Pattern pattern = Pattern.compile("\\d{10}");
                Matcher matcher;
                String phoneNumber;
                do {
                    System.out.println("Enter new customer mobile number:");
                    phoneNumber = scanner.next();
                    matcher = pattern.matcher(phoneNumber);
                    if (!matcher.matches()) {
                        System.out.println("Invalid phone number format. Please enter a 10-digit phone number.");
                    }
                } while (!matcher.matches());
                customerToUpdate.setMobileNumber(phoneNumber);
                System.out.println("Customer mobile number updated successfully.");
                break;
            case 3:
                System.out.println("Enter new customer ID proof:");
                String newIdProof = scanner.next();
                customerToUpdate.setIdProof(newIdProof);
                System.out.println("Customer ID proof updated successfully.");
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private static void deleteCustomer() {
        System.out.println("Enter customer ID to delete:");
        String customerId = scanner.next();

        Customer customerToDelete = findCustomerById(customerId);
        if (customerToDelete == null) {
            System.out.println("Customer not found.");
            return;
        }

        customers.remove(customerToDelete);
        System.out.println("Customer deleted successfully.");
    }

    private static Customer findCustomerById(String customerId) {
        for (Customer customer : customers) {
            if (customer.getId().equals(customerId)) {
                return customer;
            }
        }
        return null; // Customer not found
    }

    private static void manageReceptionists() {
        System.out.println("Choose an option:");
        System.out.println("1. Add Receptionist");
        System.out.println("2. View All Receptionists");
        System.out.println("3. Update Receptionist");
        System.out.println("4. Delete Receptionist");
        System.out.println("5. Back to Main Menu");
        System.out.print("Enter your choice: ");

        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                addReceptionist();
                break;
            case 2:
                viewAllReceptionists();
                break;
            case 3:
                updateReceptionist();
                break;
            case 4:
                deleteReceptionist();
                break;
            case 5:
                break;
            default:
                System.out.println("Invalid choice. Please choose again.");
        }
    }

    private static void addReceptionist() {
        System.out.println("Enter receptionist ID:");
        String id = scanner.next();

        System.out.println("Enter receptionist name:");
        String name = scanner.next();

        System.out.println("Enter receptionist ID proof:");
        String idProof = scanner.next();

        Receptionist receptionist = new Receptionist(id, name, idProof);
        receptionists.add(receptionist);
        System.out.println("Receptionist added successfully.");
    }

    private static void viewAllReceptionists() {
        if (receptionists.isEmpty()) {
            System.out.println("No receptionists available.");
        } else {
            System.out.println("All Receptionists:");
            for (Receptionist receptionist : receptionists) {
                System.out.println("ID: " + receptionist.getId());
                System.out.println("Name: " + receptionist.getName());
                System.out.println("---------------------------");
            }
        }
    }

    private static void updateReceptionist() {
        System.out.println("Enter receptionist ID to update:");
        String receptionistId = scanner.next();

        Receptionist receptionistToUpdate = findReceptionistById(receptionistId);
        if (receptionistToUpdate == null) {
            System.out.println("Receptionist not found.");
            return;
        }

        System.out.println("Choose what to update:");
        System.out.println("1. Receptionist Name");
        System.out.println("2. Receptionist ID Proof");
        System.out.print("Enter your choice: ");

        int choice = scanner.nextInt();
        switch (choice) {
            case 1:
                System.out.println("Enter new receptionist name:");
                String newName = scanner.next();
                receptionistToUpdate.setName(newName);
                System.out.println("Receptionist name updated successfully.");
                break;
            case 2:
                System.out.println("Enter new receptionist ID proof:");
                String newIdProof = scanner.next();
                receptionistToUpdate.setIdProof(newIdProof);
                System.out.println("Receptionist ID proof updated successfully.");
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private static void deleteReceptionist() {
        System.out.println("Enter receptionist ID to delete:");
        String receptionistId = scanner.next();

        Receptionist receptionistToDelete = findReceptionistById(receptionistId);
        if (receptionistToDelete == null) {
            System.out.println("Receptionist not found.");
            return;
        }

        receptionists.remove(receptionistToDelete);
        System.out.println("Receptionist deleted successfully.");
    }

    private static Receptionist findReceptionistById(String receptionistId) {
        for (Receptionist receptionist : receptionists) {
            if (receptionist.getId().equals(receptionistId)) {
                return receptionist;
            }
        }
        return null; 
    }

private static void bookRoom() {
    System.out.println("Enter customer ID:");
    String customerId = scanner.next();

    Customer customer = findCustomerById(customerId);
    if (customer == null) {
        System.out.println("Customer not found.");
        return;
    }

    System.out.println("Enter customer mobile number:");
    String mobileNumber = scanner.next();
    customer.setMobileNumber(mobileNumber);

    System.out.println("Please provide your ID proof (e.g., Passport, ID card):");
    String idProof = scanner.next();

    System.out.println("Please provide your ID proof number:");
    String idProofNumber = scanner.next();

    if (!idProofNumber.equals(customer.getIdProofNumber())) {
        System.out.println("Your ID proof does not match. Booking cannot be completed.");
        return;
    }

    customer.setIdProof(idProof);
    customer.setIdProofNumber(idProofNumber);

    boolean continueBooking = false;
    do {
        System.out.println("Available Rooms:");
        boolean roomsAvailable = false;
        for (Room room : rooms) {
            if (!room.isBooked()) {
                System.out.println("Room Number: " + room.getRoomNumber());
                System.out.println("Type: " + room.getType());
                System.out.println("Price per Night: $" + room.getPricePerStaying());
                System.out.println("---------------------------");
                roomsAvailable = true;
            }
        }
        if (!roomsAvailable) {
            System.out.println("Sorry, no rooms are currently available for booking.");
            return;
        }

        System.out.println("Enter room number:");
        String roomNumber = scanner.next();

        Room selectedRoom = findRoomByNumber(roomNumber);
        if (selectedRoom == null) {
            System.out.println("Invalid room number. Please choose a valid room.");
            continue;
        }

        if (selectedRoom.isBooked()) {
            System.out.println("Room " + roomNumber + " is not available. It is already booked.");
            System.out.println("Do you want to book another room? (Y/N)");
            String anotherBooking = scanner.next();
            continueBooking = anotherBooking.equalsIgnoreCase("Y");
            continue; 
        }

        System.out.println("Enter number of nights:");
        int nights = scanner.nextInt();

        double totalCost = selectedRoom.getPricePerStaying() * nights;
        System.out.println("Total Cost: $" + totalCost);

        System.out.println("Room Details:");
        System.out.println("Room Number: " + selectedRoom.getRoomNumber());
        System.out.println("Type: " + selectedRoom.getType());
        System.out.println("Price per Night: $" + selectedRoom.getPricePerStaying());
        System.out.println("---------------------------");

        System.out.println("Confirm booking? (Y/N)");
        String confirmation = scanner.next();
        if (confirmation.equalsIgnoreCase("Y")) {
            selectedRoom.setBooked(true);
            customer.getBookedRooms().put(selectedRoom.getRoomNumber(), nights); 
            System.out.println("Room booked successfully.");
        }

        System.out.println("Do you want to book another room? (Y/N)");
        String anotherBooking = scanner.next();
        continueBooking = anotherBooking.equalsIgnoreCase("Y");
    } while (continueBooking);
}



private static void payBill() {
    System.out.println("Enter customer ID:");
    String customerId = scanner.next();

    Customer customer = findCustomerById(customerId);
    if (customer == null) {
        System.out.println("Customer not found.");
        return;
    }

    if (customer.getBookedRooms().isEmpty()) {
        System.out.println("No rooms booked for this customer.");
        return;
    }

    System.out.println("Choose a room to pay bill for:");
    for (Map.Entry<String, Integer> entry : customer.getBookedRooms().entrySet()) {
        String roomNumber = entry.getKey();
        int nights = entry.getValue();
        Room room = findRoomByNumber(roomNumber);
        double totalCost = room.getPricePerStaying() * nights;
        System.out.println(roomNumber + " - " + room.getType() + " - $" + totalCost);
    }

    System.out.println("Enter room number to pay bill:");
    String roomNumber = scanner.next();

    Room room = findRoomByNumber(roomNumber);
    if (room == null || !room.isBooked()) {
        System.out.println("Room not found or not booked.");
        return;
    }

    int nights = customer.getBookedRooms().get(roomNumber);
    double totalCost = room.getPricePerStaying() * nights;
    System.out.println("Number of Nights: " + nights); // Added line to print number of nights
    System.out.println("Total cost to be paid: $" + totalCost);

    System.out.println("Choose payment type (Cash/Card):");
    String paymentType = scanner.next();

    System.out.println("Enter receptionist ID:");
    String receptionistId = scanner.next();

    Bill bill = new Bill(customerId, roomNumber, totalCost, paymentType, receptionistId);
    
    System.out.println("Bill paid successfully.");

   
    System.out.println("------ Bill Details ------");
    System.out.println("Receptionist ID: " + receptionistId);
    System.out.println("Customer Name: " + customer.getName());
    System.out.println("Room Number: " + roomNumber);
    System.out.println("Room Type: " + room.getType());
    System.out.println("Price per Night: $" + room.getPricePerStaying());
    System.out.println("Number of Nights: " + nights); // Added line to print number of nights
    System.out.println("Total Cost: $" + totalCost);
    System.out.println("---------------------------");
}



    private static void markRoomForCleaning() {
        System.out.println("Enter room number to mark for cleaning:");
        String roomNumber = scanner.next();

        Room room = findRoomByNumber(roomNumber);
        if (room == null) {
            System.out.println("Room not found.");
            return;
        }

        room.setClean(true);
        System.out.println("Room " + roomNumber + " marked for cleaning.");
    }

   @SuppressWarnings("unchecked")
     private static void loadDataFromFiles() {
     
       try (FileInputStream roomFileIn = new FileInputStream("rooms.ser");
       ObjectInputStream roomObjectIn = new ObjectInputStream(roomFileIn)) {
       Object obj = roomObjectIn.readObject();
       if (obj instanceof ArrayList<?>) {
         rooms = (ArrayList<Room>) obj;
      } else {
        System.out.println("Invalid data format for rooms.");
     }
      System.out.println("Rooms loaded successfully.");
    }catch (IOException | ClassNotFoundException | ClassCastException e) {
    System.out.println("Error loading rooms data: " + e.getMessage());
   }

   
   try (FileInputStream customerFileIn = new FileInputStream("customers.ser");
      ObjectInputStream customerObjectIn = new ObjectInputStream(customerFileIn)) {
      Object obj = customerObjectIn.readObject();
       if (obj instanceof ArrayList<?>) {
        customers = (ArrayList<Customer>) obj;
    } else {
        System.out.println("Invalid data format for customers.");
    }
    System.out.println("Customers loaded successfully.");
   } catch (IOException | ClassNotFoundException | ClassCastException e) {
    System.out.println("Error loading customers data: " + e.getMessage());
 }


   try (FileInputStream receptionistFileIn = new FileInputStream("receptionists.ser");
     ObjectInputStream receptionistObjectIn = new ObjectInputStream(receptionistFileIn)) {
      Object obj = receptionistObjectIn.readObject();
      if (obj instanceof ArrayList<?>) {
         receptionists = (ArrayList<Receptionist>) obj;
     } else {
         System.out.println("Invalid data format for receptionists.");
     }
    System.out.println("Receptionists loaded successfully.");
  } catch (IOException | ClassNotFoundException | ClassCastException e) {
     System.out.println("Error loading receptionists data: " + e.getMessage());
  }

 }



   private static void saveDataToFiles() {
    try {
        FileOutputStream roomFileOut = new FileOutputStream("rooms.ser");
        ObjectOutputStream roomObjectOut = new ObjectOutputStream(roomFileOut);
        roomObjectOut.writeObject(rooms);
        roomObjectOut.close();
        roomFileOut.close();
        System.out.println("Rooms saved successfully.");
    } catch (IOException e) {
        System.out.println("Error saving rooms data: " + e.getMessage());
    }

    
    try {
        FileOutputStream customerFileOut = new FileOutputStream("customers.ser");
        ObjectOutputStream customerObjectOut = new ObjectOutputStream(customerFileOut);
        customerObjectOut.writeObject(customers);
        customerObjectOut.close();
        customerFileOut.close();
        System.out.println("Customers saved successfully.");
    } catch (IOException e) {
        System.out.println("Error saving customers data: " + e.getMessage());
    }

    
    try {
        FileOutputStream receptionistFileOut = new FileOutputStream("receptionists.ser");
        ObjectOutputStream receptionistObjectOut = new ObjectOutputStream(receptionistFileOut);
        receptionistObjectOut.writeObject(receptionists);
        receptionistObjectOut.close();
        receptionistFileOut.close();
        System.out.println("Receptionists saved successfully.");
    } catch (IOException e) {
        System.out.println("Error saving receptionists data: " + e.getMessage());
    }
 }

}
