import java.io.*;
import jakarta .servlet.*;
import jakarta.servlet.http.*;


public class SalaryCalculator extends HttpServlet {
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
        double hourlyRate = Double.parseDouble(request.getParameter("hourlyRate"));
        int hoursWorked = Integer.parseInt(request.getParameter("hoursWorked"));
        
        
        double salary = hourlyRate * hoursWorked;
        
       
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
      
       out.println("<h2>Salary Calculator Result</h2>");
        out.println("<p>Hourly Rate: " + hourlyRate + "</p>");
        out.println("<p>Hours Worked: " + hoursWorked + "</p>");
        out.println("<p>Salary: " + salary + "</p>");
        
    }
}