package com.example.model;

public class User {
    private int id;
    private String name;
    private String rollNo;
    private double fees;
    private String status;

    
    public User() {
    }

    public User(int id, String name, String rollNo, double fees, String status) {
        this.id = id;
        this.name = name;
        this.rollNo = rollNo;
        this.fees = fees;
        this.status = status;
    }

    
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getRollNo() {
        return rollNo;
    }

    public double getFees() {
        return fees;
    }

    public String getStatus() {
        return status;
    }

    
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public void setFees(double fees) {
        this.fees = fees;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
