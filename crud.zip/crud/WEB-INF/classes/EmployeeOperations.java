import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

public class EmployeeOperations extends HttpServlet {

    private static final String URL = "jdbc:postgresql://localhost:5432/servlet";
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "Dheepakr@j25082001";

    public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        String operation = req.getParameter("operation");
        if ("add".equals(operation)) {
            addEmployee(req, res);
        } else if ("update".equals(operation)) {
            updateEmployee(req, res);
        } else if ("delete".equals(operation)) {
            deleteEmployee(req, res);
        } else {
            res.getWriter().write("<h1>Invalid operation</h1>");
        }
    }

    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        res.setContentType("text/html");

        try {
            Class.forName("org.postgresql.Driver");
            try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
                Employee employee = getEmployee(connection, id);
                if (employee != null) {
                    PrintWriter out = res.getWriter();
                    out.println("<h1>Employee Details</h1>");
                    out.println("<p>ID: " + employee.getId() + "</p>");
                    out.println("<p>Name: " + employee.getName() + "</p>");
                    out.println("<p>Email: " + employee.getEmail() + "</p>");
                    out.println("<p>Phone Number: " + employee.getPhoneNumber() + "</p>");
                    out.println("<p>Role: " + employee.getRole() + "</p>");
                } else {
                    res.getWriter().write("<h1>Employee not found</h1>");
                }
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            res.getWriter().write("<h1>Error occurred: " + e.getMessage() + "</h1>");
        }
    }

    public void addEmployee(HttpServletRequest req, HttpServletResponse res) throws IOException {
        String name = req.getParameter("name");
        int id = Integer.parseInt(req.getParameter("id"));
        String phone = req.getParameter("phone");
        String email = req.getParameter("email");
        String role = req.getParameter("role");

        res.setContentType("text/html");
        try {
            Class.forName("org.postgresql.Driver");
            try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
                createTable(connection);
                insertEmployee(connection, name, id, phone, email, role);

                
                Employee employee = new Employee(id, name, email, phone, role);

                PrintWriter out = res.getWriter();
                out.println("<h1>Employee Added Successfully</h1>");
                out.println("<h2>Employee Details:</h2>");
                out.println("<p>ID: " + employee.getId() + "</p>");
                out.println("<p>Name: " + employee.getName() + "</p>");
                out.println("<p>Email: " + employee.getEmail() + "</p>");
                out.println("<p>Phone Number: " + employee.getPhoneNumber() + "</p>");
                out.println("<p>Role: " + employee.getRole() + "</p>");
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            res.getWriter().write("<h1>Error occurred: " + e.getMessage() + "</h1>");
        }
    }

    public void updateEmployee(HttpServletRequest req, HttpServletResponse res) throws IOException {
        int id = Integer.parseInt(req.getParameter("id"));
        String name = req.getParameter("name");
        String phone = req.getParameter("phone");
        String email = req.getParameter("email");
        String role = req.getParameter("role");

        res.setContentType("text/html");
        try {
            Class.forName("org.postgresql.Driver");
            try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
                updateEmployee(connection, id, name, phone, email, role);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            res.getWriter().write("<h1>Error occurred: " + e.getMessage() + "</h1>");
        }

        res.getWriter().write("<h1>Update successful</h1>");
    }

    public void deleteEmployee(HttpServletRequest req, HttpServletResponse res) throws IOException {
        int id = Integer.parseInt(req.getParameter("id"));

        res.setContentType("text/html");
        try {
            Class.forName("org.postgresql.Driver");
            try (Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
                deleteEmployee(connection, id);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            res.getWriter().write("<h1>Error occurred: " + e.getMessage() + "</h1>");
        }

        res.getWriter().write("<h1>Delete successful</h1>");
    }

   private void createTable(Connection connection) throws SQLException {
    String sql = "CREATE TABLE IF NOT EXISTS employees (" +
            "emp_id INT PRIMARY KEY, " +
            "emp_name VARCHAR(100), " +
            "emp_email VARCHAR(200), " +
            "emp_phone_number VARCHAR(15), " +
            "emp_role VARCHAR(30)" +
            ")";
    try (PreparedStatement statement = connection.prepareStatement(sql)) {
        statement.executeUpdate();
    }
 }


    public void insertEmployee(Connection connection, String name, int id, String phone, String email, String role) throws SQLException {
        String sql = "INSERT INTO employees (emp_id, emp_name, emp_email, emp_phone_number, emp_role) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, id);
            preparedStatement.setString(2, name);
            preparedStatement.setString(3, email);
            preparedStatement.setString(4, phone);
            preparedStatement.setString(5, role);
            preparedStatement.executeUpdate();
        }
    }

    public void updateEmployee(Connection connection, int id, String name, String phone, String email, String role) throws SQLException {
        String sql = "UPDATE employees SET emp_name = ?, emp_email = ?, emp_phone_number = ?, emp_role = ? WHERE emp_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, phone);
            preparedStatement.setString(4, role);
            preparedStatement.setInt(5, id);
            preparedStatement.executeUpdate();
        }
    }

    public void deleteEmployee(Connection connection, int id) throws SQLException {
        String sql = "DELETE FROM employees WHERE emp_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        }
    }

    public Employee getEmployee(Connection connection, int id) throws SQLException {
        String sql = "SELECT * FROM employees WHERE emp_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, id);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    Employee employee = new Employee(id, resultSet.getString("emp_name"), resultSet.getString("emp_email"), resultSet.getString("emp_phone_number"), resultSet.getString("emp_role"));
                    return employee;
                }
            }
        }
        return null;
    }

    public static class Employee {
        private int id;
        private String name;
        private String email;
        private String phoneNumber;
        private String role;

        public Employee(int id, String name, String email, String phoneNumber, String role) {
            this.id = id;
            this.name = name;
            this.email = email;
            this.phoneNumber = phoneNumber;
            this.role = role;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getEmail() {
            return email;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public String getRole() {
            return role;
        }
    }
}
